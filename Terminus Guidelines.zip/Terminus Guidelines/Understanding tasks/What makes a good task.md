What Makes a Good Task

Terminal-Bench 2.1 asked agents to perform a difficult terminal or software task. Terminal-Bench 3.0 asks something different: understand a specialized domain, manipulate the right system or artifact inside it, and prove the result satisfies interacting hidden invariants.

This is not simply "harder." The difficulty moves from isolated technical execution toward vertically integrated engineering. A strong Terminus 3 task usually follows this chain:

svgCopy
specialized evidence
        ↓
domain-specific inference
        ↓
algorithm/system manipulation
        ↓
native artifact or live state
        ↓
hidden, structural, performance, and safety verification

Six Properties of Strong Tasks

1. The specification must be inferred. The correct model of the problem is not handed over as a checklist. The agent has to work out what the requirements mean in the domain before implementing anything — reconstructing structure from instrument output, deriving geometry from an engineering drawing, inferring rules from examples.

2. Output semantics matter, not appearance. Require a native, structurally valid artifact: an editable parametric feature tree rather than a baked mesh, a checkable proof without admits, synthesizable RTL, correctly mutated live database state. Producing something that merely looks similar must not pass.

3. Correctness is multidimensional. Rather than one dominant axis, combine several that must hold simultaneously — functional correctness, performance, determinism, safety, provenance, state consistency, structure, generalization to hidden instances.

4. Constraints interact. The point is not that constraints are numerous, but that they affect one another: a navigation error changes fuel burn, which changes feasible routing, which changes crosswind exposure. Interacting dependencies are far more demanding than a list of independent assertions.

5. State is part of the problem. Strong tasks often are not "edit files and run pytest." They involve operating databases under live traffic, stream processors, ERP workflows, model-serving runtimes, or multi-service systems — understanding current state, sequencing operations correctly, recovering from partial progress, and validating the result from a clean process.

6. Hidden checks probe understanding. Verify semantic equivalence across variations and metamorphic properties, not just more examples. A solution should not be able to pass by satisfying its author's happy path — and exercise every documented behavior on its hard instance, not a degenerate one. A rule tested only on the easy case (an ordering rule tested only where timestamps are distinct, say) is not really tested. A rule whose only discriminating case lives in mixed held-out data, while the visible suite would still pass if that rule were wrong, is not really tested either.

From TB-Style to Terminus 3-Style
	
Compile and repair a package	Repair a runtime while preserving batching, caching, streaming, numerical, and performance semantics
Recover a fixed database file	Maintain recovery ordering guarantees, or perform a zero-downtime live cutover
Solve an explicitly specified scheduling problem	Operate dispatch or ERP state under capacity, lineage, safety, and workflow constraints
Read a value from an image and compute output	Infer geometry from a drawing and construct an editable parametric model
Implement an algorithm	Produce a behaviorally compatible, performance-qualified reimplementation under hidden workloads
Process a scientific dataset	Infer the scientific interpretation, implement the analysis, and emit convention-correct, provenance-preserving results
What Still Disqualifies a Task

A task must reject a wrong solution, not merely accept a right one. Before you submit, run a deliberately wrong, incomplete, or lazy solution against your own verifier. If it passes, the task is disqualified — the difficulty isn't being enforced. One mutant that breaks several rules at once (including the shipped buggy code) is not enough: for each named domain rule, confirm a case exists that would fail if that rule alone were wrong. Confirming that the correct solution passes proves nothing about whether a wrong one fails, and the latter is the only question the verifier exists to answer.

Ambiguity, non-determinism, unstated requirements, and hidden knowledge the agent could not possibly obtain. Difficulty must come from the problem, never from the description. Hidden test inputs are fine; hidden requirements are not — a held-out fixture may introduce a new input, but the instruction and that input must determine the output.

A task is also disqualified if the agent can shortcut it — reaching the answer, or satisfying the checks without doing the work. Both disqualify. Concretely:

The answer is reachable. Held-out inputs staged in the same directory as their expected outputs (the program copies the sibling), a sealed directory the graded process can still read, or the agent's own prior output left at a predictable path to replay. Ground truth derived from agent-writable paths (/app, a mutable corpus, agent-delivered trees) counts too — the agent can edit the truth, not just read it. So does an answer key the verifier then execs agent code against (rebuild-from-source): separate mode protects the verifier from the agent environment, not from that process.
The checks are hollow. They assert a proxy a wrong answer also satisfies — a count, a first element, a field's presence but not its value, or an expected result reconstructed from an input the agent controls. They grade a delivered binary without rebuilding it from source (a hardcoded binary passes). Or they grade two artifacts the agent controls both sides of — a simulated and a synthesized build, a library and its consumer — without proving they agree. Staging copies that follow symlinks into protected fixtures, or grading the wrong optimization objective / tie-break when the spec defines one, are the same class of failure.
A documented behavior is never exercised. A required command or mode the tests reference but never run can be broken or hardcoded and still pass. A named rule that only fails when bundled with other violations, or that is enforced only inside mixed held-out data, is the same miss.
The contract drifts. Instructions state one numeric tolerance; tests enforce a tighter one. Or the spec names an objective the verifier never distinguishes from a weaker feasible plan.

See Writing Tests for how to close each.

---------------------------------------------------------

Example Tasks

Five reference tasks spanning four categories, followed by anti-examples showing what to avoid. These are calibration points for scope and rigor — not templates to copy.

Reference Tasks
Repair a broken statistical monitor
TOMLsvgCopy
artifacts = ["/app/drift_monitor", "/app/data"]

[metadata]
category = "ML"
subcategory = "Inference"
tags = ["python", "numpy", "scipy", "drift-detection", "ml-monitoring", "statistics"]
expert_time_estimate_hours = 5


An embedding-drift monitor compares incoming windows against a reference baseline using several statistical tests, then emits alerts through a debouncer. It is broken in more than one place: stable distributions trigger alerts they shouldn't, real drift goes undetected, and alert state flickers in ways that don't track the data.

Why it works. The visible symptom is in the alert layer, but the defects reach into the statistical and distance utilities underneath. An agent that patches only what it can see fails. Correctness spans statistical validity, alert stability, and behavior across distinct scenario inputs at once.

Fix a shared submission pipeline
TOMLsvgCopy
[metadata]
category = "Software"
subcategory = "Frontend"
tags = ["react", "typescript", "forms", "validation", "crm"]
expert_time_estimate_hours = 5


A React/TypeScript intake app has a broken submission workflow spanning form handling, validation, normalization, deterministic timestamping, ledger reconciliation, and export. The normative specs live in the repository as JSON, and both the UI and a CLI entry point must run through the same pipeline — not parallel implementations.

Why it works. The contract is specified in machine-readable files the agent must read rather than prose it can skim. The shared-entry-point requirement rules out fixing each surface independently, and outputs are structured artifacts checked for exact shape.

Debug event-time stream processing
TOMLsvgCopy
artifacts = ["/app/app/"]

[metadata]
category = "Software"
subcategory = "Systems"
tags = ["stream-processing", "session-windows", "watermarks", "event-time", "aggregation"]
expert_time_estimate_hours = 8


A session-window processor groups timestamped events by inactivity gap, fires aggregates when sessions complete, and garbage-collects old state. Three symptoms are reported: recently active sessions go missing when late events arrive, merged sessions emit results inconsistent with full event history, and output stalls when sources produce data at different rates.

Why it works. Intended semantics are documented in a design file, so the agent must reconcile observed behavior against a specification rather than guess. The three symptoms share root causes in watermark and state handling — fixing them independently produces regressions. Certain files are explicitly read-only, so the contract cannot be redefined.

Reconstruct an intrusion from captured evidence
TOMLsvgCopy
[metadata]
category = "Security"
subcategory = "Forensics"
tags = ["forensics", "reverse-engineering", "cryptography", "network-analysis", "custom-protocol"]
expert_time_estimate_hours = 3


Captured network data from a suspected exfiltration is provided. One internal host generated suspicious outbound activity and exchanged a binary session with external infrastructure. The agent identifies the host, recovers a domain-generation sequence, decodes the session, and decrypts the stolen data — writing findings to a structured JSON file with named fields.

Why it works. Nothing states what the protocol is; it must be inferred from artifacts. Each stage gates the next — the wrong host yields the wrong seed, which yields the wrong key. The output schema is exact, so a correct narrative in the wrong format still fails.

Repair write-ahead-log recovery ordering
TOMLsvgCopy
artifacts = ["/app/"]

[metadata]
category = "Software"
subcategory = "Databases"
tags = ["python", "wal", "recovery", "concurrency", "storage-engine"]
expert_time_estimate_hours = 6


A WAL-backed storage engine must be repaired so recovery replays entries in the correct order and reports accurate statistics. The verifier imports named functions, so specific module APIs must remain available. Application modules are barred from a list of imports and constructs, and from writing to disk.

Why it works. The task fixes the interface precisely, so the agent cannot escape by restructuring around the problem. The prohibitions block whole classes of shortcut. Recovery ordering is exactly the kind of property that looks right in the happy path and breaks under the sequences a rigorous verifier exercises.

What These Have in Common
Requirements are inferred from specs, design docs, or evidence — not handed over as a checklist.
Outputs are structured artifacts judged on exact shape and semantics.
Multiple defects or constraints interact, so partial fixes regress.
Constraints are enforced, not suggested: read-only files, banned imports, required APIs.
Every one involves far more than a single command's worth of work — chaining, intermediate state, and reacting to what came before.
Anti-Examples: Tasks to Avoid
❌ Too Easy

**File: **instruction.md

MARKDOWNsvgCopy
Write a function that reverses a string.


Problem: One-liner in most languages, agents solve instantly.

❌ Too Vague

**File: **instruction.md

MARKDOWNsvgCopy
Build a web scraper.


Problem: No specific requirements, impossible to verify.

❌ Requires Secrets or Unverifiable External State

**File: **instruction.md

MARKDOWNsvgCopy
Query the Twitter API to get today's trending topics.


Problem: Two issues — it needs private API credentials/secrets (which can't be bundled or committed), and its output is nondeterministic (trending topics change constantly), so no stable verifier can grade it. Needing internet by itself is not a problem — a task that genuinely requires the network is acceptable with [agent].network_mode = "public". The real issues here are the secret credentials and the unverifiable, ever-changing result.

❌ Ambiguous Success Criteria

**File: **instruction.md

MARKDOWNsvgCopy
Make this code better.


Problem: "Better" is subjective without specific metrics.
Add all of these to the documents.