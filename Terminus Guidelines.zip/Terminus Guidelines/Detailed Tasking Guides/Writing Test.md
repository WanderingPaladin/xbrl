Writing Tests

The tests/test_outputs.py file contains pytest tests that verify task completion. Good tests are the foundation of a quality task.

All verifier tests must be written in Python and run with pytest, regardless of the task's implementation language. For non-Python tasks, write Python tests that exercise the CLI, service, files, or processes under test. tests/test.sh is a bash entry point, but it should invoke the Python pytest suite rather than delegating to another language-specific test framework.

Writing a Hardware/CAD task? Geometry has failure modes this page does not cover — see CAD Task Guidelines in addition to everything here.
Quality panel. Before you submit, walk the five-axis checklists in the Quality Panel Judge Guide: contract, reference solution, protected ground truth, verifier soundness, and deterministic execution. Axis verdicts of Minor or Major block, except on protected_ground_truth, where only Major blocks. Findings explicitly marked Advisory do not block. See the worked examples for concrete defects, fixes, and verification steps.
How Verification Works

In Terminus 3 the verifier runs in a separate container the agent cannot see or reach:

The agent works in the task environment until it stops or times out.
Harbor collects the paths declared in artifacts from the agent's final environment.
A separate verifier container, built from tests/Dockerfile, starts up.
The collected artifacts are placed into that container.
tests/test.sh runs and writes a reward.
The verifier never runs inside the agent's environment, and it only ever sees the artifacts you declared.

Declaring Artifacts

TOML

Copy
artifacts = ["/app/output.json", "/app/results/"]
⚠️ artifacts is a top-level key in task.toml. Nesting it under [verifier] does not raise an error — the value is silently dropped and your verifier receives nothing.
Parent directories must already exist in the verifier image. Harbor uploads declared artifacts into the verifier, and the upload fails if the landing directory is missing:

DOCKERFILE

Copy
RUN mkdir -p /app/results
A missing landing directory produces failures that look like broken tests. Check this first when a verifier fails inexplicably.

Verifier Dependencies

Everything the verifier needs — pytest, plugins, browser drivers, wheels, npm packages — must be baked into tests/Dockerfile. Nothing may be installed or downloaded at trial time.

Getting Started

Video Tutorial

Creating Tests for Your Task



What You'll Learn

Structure of test_outputs.py
Writing effective test cases
Matching tests to task requirements
Common testing patterns
Basic Structure

PYTHON

Copy
"""Tests for the data processing task."""
import pytest
import json
from pathlib import Path


def test_output_file_exists():
    """Verify the output file was created."""
    assert Path("/output/result.json").exists()


def test_output_format():
    """Verify the output has correct JSON structure."""
    with open("/output/result.json") as f:
        data = json.load(f)
    
    assert "status" in data
    assert "items" in data
    assert isinstance(data["items"], list)


def test_correct_count():
    """Verify the item count is correct."""
    with open("/output/result.json") as f:
        data = json.load(f)
    
    assert len(data["items"]) == 42
Key Principles

1. Test Behavior, Not Implementation

Run the code and check results. Don't parse source code looking for patterns.

Good:

PYTHON

Copy
def test_function_handles_empty_input():
    """Empty input should return empty list."""
    from app.main import process
    result = process("")
    assert result == []
Bad:

PYTHON

Copy
def test_has_empty_check():
    """Check if code has empty input handling."""
    source = open("/app/main.py").read()
    assert "if not" in source  # Brittle!
2. Informative Docstrings

Every test must have a docstring explaining what behavior it checks. This is validated by CI.

PYTHON

Copy
def test_api_returns_json():
    """API endpoint should return valid JSON with Content-Type header."""
    response = requests.get("http://localhost:8080/api/data")
    assert response.headers["Content-Type"] == "application/json"
    assert response.json()  # Parseable JSON
3. Match Task Requirements

Tests need to fully cover all aspects of the prompt (instruction.md). This includes:

✅ All explicit requirements from the prompt
✅ Implicitly expected behavior
✅ Critical edge cases
✅ Every documented command/mode is invoked by at least one test
Every requirement in the prompt must map to a test. If it is implied or stated in the prompt but not covered by tests, that is a miss.

A documented command or mode must be run, not just referenced. If the contract names a subcommand, flag, or behavior mode, a test has to invoke it. A requirement that only appears in the prompt and is never exercised is not covered.

Each named domain rule needs an isolating case. A single wrong solution that violates several rules at once — including the shipped buggy environment — only proves the verifier is not a no-op. For every rule the instruction names, there must be a fixture whose expected outcome would change if that rule alone were inverted. Do not require a full second implementation per rule; the fixture just has to make that rule bite.

Held-out data must not be the only pin. Held-out cases exist to check generalization to unseen inputs. They must not be the only place a stated rule is enforced. If the visible suite would still pass when that rule is wrong, the rule is not tested — even when instruction.md names it and a mixed held-out set happens to fail.

Hidden test inputs are fine; hidden requirements are not. A held-out fixture may introduce a new input, but the instruction and that input must contain everything needed to determine the correct output. A hidden corpus must not be the only source of an unstated mapping, threshold, label, or other fact that decides which behavior passes.

Fine: a hidden test uses a new input (for example a new CSV), and the documented algorithm or rule lets the submitted program compute the answer from that input.
Unfair: passing depends on a mapping, threshold, label, convention, or ground-truth fact absent from both the instructions and the input the program receives. Example: a hidden test for whether code X17 maps to category premium when that mapping exists only in the hidden corpus.
PYTHON

Copy
# BAD: the contract documents a `verify` subcommand, but the suite only ever runs `engrave`,
# so a solution that hardcodes or breaks `verify` still passes.

# GOOD: exercise every documented command
def test_verify_subcommand_rejects_tampered_input():
    """The documented `verify` command must reject a corrupted artifact."""
    r = run_agent_cli("verify", "/app/tampered.json")
    assert r.returncode != 0
"Return empty list for empty input"	test_empty_input_returns_empty_list
"Output to /data/result.csv"	test_output_file_exists
"Include header row"	test_csv_has_header
Here's a very simplified example for demonstrative purposes only. If the prompt is:

Write a Python function called divide that takes two numbers and returns the result as a float.
Explicit tests:

PYTHON

Copy
def test_function_exists():
    """A function called 'divide' exists"""

def test_takes_two_numbers():
    """It accepts two numbers as input"""

def test_divides_correctly():
    """It returns the correct division result"""

def test_returns_float():
    """The return type is a float"""
Implicit test / edge case:

PYTHON

Copy
def test_division_by_zero():
    """It handles division by zero"""
The prompt never mentions division by zero, but any reasonable person reading "a function that divides two numbers" would expect it to handle that case.

4. Cover Edge Cases

Make the fixture that carries a rule its hard case. When one test decides whether a rule is implemented, the input must actually stress that rule — otherwise a solution that skips the rule passes. The same applies across the suite: a rule that only fails when bundled with other violations, or that is enforced only inside a mixed held-out set, is not really tested.

PYTHON

Copy
# BAD: an ordering rule (timestamp, then sequence, then file-position) is only tested on a
# fixture whose events all have DISTINCT timestamps. A timestamp-only implementation passes and
# never faces the sequence tie the rule exists for.

# GOOD: the ordering fixture contains simultaneous events, so sequence has to break the tie
def test_ordering_breaks_ties_by_sequence():
    """Events with equal timestamps must be ordered by sequence, not file position."""
    out = run_agent_cli("reconcile", "/app/simultaneous_events.json")
    assert [e["id"] for e in out["ordered"]] == ["a", "b", "c"]
Test the boundaries, not just the happy path:

PYTHON

Copy
def test_empty_input():
    """Empty input is handled gracefully."""
    assert process("") == []

def test_single_item():
    """Single item input works correctly."""
    assert process("a") == ["a"]

def test_large_input():
    """Large input is handled efficiently."""
    result = process("x" * 10000)
    assert len(result) == 10000

def test_special_characters():
    """Special characters are preserved."""
    assert process("héllo 世界") == ["héllo", "世界"]
tests/test.sh and tests/Dockerfile

tests/test.sh is the verifier entrypoint. It runs the Python pytest suite and writes the reward file. Do not replace pytest with another test framework such as JUnit, Jest, or go test — use Python pytest tests to drive and validate those systems when needed.

What is settled for Terminus 3:

tests/Dockerfile builds the verifier image and must bake in all verifier dependencies.
tests/test.sh must not install packages or fetch anything from the network at runtime — no uvx, pip install, npm install, curl, wget, or git clone.
The reward is written to /logs/verifier/reward.txt (1 pass, 0 fail).
pytest is run with --ctrf /logs/verifier/ctrf.json to emit a structured test report.
Pin verifier tooling to exact versions.
tests/Dockerfile

DOCKERFILE

Copy
FROM python:3.12-slim-bookworm@sha256:<digest>

# Pin every verifier dependency to an exact version — nothing is installed at trial time.
RUN pip install --no-cache-dir pytest==9.1.1 pytest-json-ctrf==0.5.2

# Separate-mode verifiers do not receive an upload of tests/, so the image must own
# /tests itself. The build context is your task's tests/ directory.
COPY . /tests/

# Artifact landing directories must exist before Harbor uploads declared artifacts.
RUN mkdir -p /app
Every FROM in tests/Dockerfile must be digest-pinned and on a sanctioned base image, exactly as in environment/Dockerfile. This is reported as a warning, not a hard failure — it will not block your submission, but a reviewer can still send the task back for it. Floating tags break reproducibility when the dataset is re-validated later, so pin them.

tests/test.sh

BASH

Copy
#!/bin/bash
set -uo pipefail

mkdir -p /logs/verifier

python -m pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA
rc=$?

if [ "$rc" -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
Three things about this script are deliberate:

No set -e. With -e, a failing pytest aborts the script before the reward file is written. The trial then has no reward file, and a real test failure is reclassified as an infrastructure error. Capture the exit code instead. This applies to tests/test.sh specifically — fail-fast is still fine in setup and solution scripts.
End on the fi. No trailing exit. The script's status then reflects whether the reward was recorded: zero when the write succeeded, non-zero when it failed — which correctly surfaces as an infrastructure error. Note that pytest's rc is captured in a variable and never propagated, so a failing test exits zero either way; a trailing exit 0 adds nothing except masking a failed write.
--ctrf /logs/verifier/ctrf.json is required for any pytest-based verifier, and is enforced by an automated check.
This shape matches the published task skeleton. If you find a difference, the skeleton wins — and please flag it.
Preserve Interpreter Permissions

If your verifier temporarily changes interpreter permissions, its cleanup must leave those interpreters usable. Harbor still needs to collect verifier logs and rewards after the tests finish.

On images where /bin resolves to /usr/bin, /bin/bash and /usr/bin/bash name the same executable. Saving a mode and disabling execution for each path in turn can save 000 for the second path. Restoring those entries in order then leaves Bash non-executable, even when the tests wrote a reward successfully.

Handle the targets before changing any permissions:

Resolve every path unconditionally with Path.resolve(). Checking only path.is_symlink() misses symlinks in parent directories such as /bin.
Deduplicate the resolved targets, then record every target's original permission mode before making any changes.
Put both the permission changes and the test work inside a try/finally scope so cleanup runs if setup or execution fails.
Restore each target's saved mode once. Attempt all restorations even if one fails, and report any restoration error. Do not replace the saved modes with a hardcoded 0755.
Repair the verifier source and run the complete Oracle evaluation in the target image, confirming that reward and log collection finish. The platform preflight verifier_interpreter_permissions flags this known pattern but does not repair submitted packages.

Common Patterns

Testing File Output

PYTHON

Copy
def test_csv_output():
    """Verify CSV output format and content."""
    import csv
    
    with open("/output/data.csv") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    assert len(rows) > 0
    assert "id" in rows[0]
    assert "name" in rows[0]
Testing API Endpoints

PYTHON

Copy
import requests

def test_health_endpoint():
    """Health check endpoint returns 200."""
    response = requests.get("http://localhost:8080/health")
    assert response.status_code == 200

def test_api_error_handling():
    """Invalid requests return 400."""
    response = requests.post(
        "http://localhost:8080/api/data",
        json={"invalid": "data"}
    )
    assert response.status_code == 400
Testing Database State

PYTHON

Copy
import sqlite3

def test_database_populated():
    """Database contains expected records."""
    conn = sqlite3.connect("/app/data.db")
    cursor = conn.execute("SELECT COUNT(*) FROM users")
    count = cursor.fetchone()[0]
    conn.close()
    
    assert count == 100
Testing Command Output

PYTHON

Copy
import subprocess

def test_cli_help():
    """CLI shows help message."""
    result = subprocess.run(
        ["python", "/app/cli.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0
    assert "Usage:" in result.stdout
What a Good Verifier Legitimately Does

A rigorous verifier often contains substantial logic — that is expected and fine. The following are legitimate and encouraged, not violations:

Run the agent's own program. Build and run the agent's binary/CLI, then grade its output. Build it from the submitted source — do not grade a binary the agent delivered without rebuilding it. If the contract separately requires a delivered binary, package, report, or file, validate that artifact too and confirm it corresponds to the submitted source; a separate rebuild does not prove the required artifact is correct (see Grading a Delivered Binary Without Rebuilding).
Parse the agent's output to check semantics (e.g., interpreting the config, policy, or files the agent produced).
Precomputed golden fixtures or hashes for exact-match or byte-exact tasks (numerical, ML, reporting). Hardcoding the expected result is fine and often required — this is the same rule as Matching at the Wrong Specificity, seen from the other side: when the instruction pins the output exactly, an exact comparison is what verifies it.
Spec-derived invariants — compute an expected property from the task's spec/config and check the output against it (e.g., a floor, budget, or cost ceiling).
Held-out ground truth, baked into the verifier image (tests/Dockerfile). Separate mode keeps goldens out of the agent container. It does not hide them from agent code the verifier executes (rebuild-from-source, then run the agent's program). Drop to an unprivileged uid before exec'ing that program and probe that it cannot read the goldens. Sealing a key into memory and unlinking it can be an extra step — it is not a substitute for that boundary, and it is not a substitute for separate mode (which Terminus requires via the explicit [verifier].environment_mode = "separate" key).
Do not hand the candidate a path whose sibling is the answer. If a held-out input is passed to the agent's program by directory path, its expected output must not live in that same directory (or anywhere reachable from that path) — the program can read the sibling instead of computing. Seal held-out inputs and their goldens in separate trees, and never pass a path inside the fixture tree.
Do not leave the agent's own prior output at a predictable path before its graded run. Moving delivered artifacts to a fixed location (e.g. /app/out.delivered) and then running the candidate lets the candidate copy them back instead of recomputing.
Perturbation / holdout re-runs — re-run the agent's program on meaningfully varied or held-out inputs and assert the output changes. Vary the sizes, values, ordering, paths, formats, or business conditions the stated domain makes relevant; this does not require combinatorial coverage of behavior the contract never promises. This is the recommended way to prove the solution is computed, not hardcoded.
The line to hold is narrow: don't put a callable end-to-end solver in tests/ that maps task inputs to the complete expected artifact (that belongs in solution/), and don't hardcode a value the instruction says the agent must read from a config file. Everything above stays fair game.

Anti-Patterns to Avoid

Reimplementing the Solution in Tests

Keep the end-to-end solution in solution/ (never present in the agent's environment). A test file must not contain a callable function that maps task inputs to the complete expected artifact — if it does, the reference implementation can leak (e.g., a partner harness that bundles tests/, or a misconfigured image) and it becomes a maintenance/contamination liability.

PYTHON

Copy
# BAD: tests/ contains a reusable solver that produces the expected artifact
def compute_expected(inputs):
    ...                                   # the whole task, reimplemented
    return full_expected_output

# GOOD: run the agent's program and grade its output against invariants or a golden fixture
def test_output():
    out = run_agent_binary("data")        # the agent's own program
    assert out["worst_case"] >= FLOOR     # spec-derived invariant
Rule of thumb: if deleting solution/ would still let the test compute the expected answer itself, the test is doing the solving. Running the agent's binary, parsing its output, golden fixtures, and invariants are all fine (see What a Good Verifier Legitimately Does).

Hardcoded Config Inputs (config-driven tasks only)

This applies only when the instruction says the agent must read a config/input file that can vary. Then the verifier should read those values from the same config at runtime, so an agent that ignores the config and hardcodes the parameters can't pass.

PYTHON

Copy
# BAD (config-driven task): verifier re-declares a value the task says to read from config
assert model.features == ["age", "income", "score"]   # copied from config.json

# GOOD: read the config the task is supposed to honor
cfg = json.load(open("/app/config.json"))
assert model.features == cfg["features"]
Not a ban on hardcoded values. Hardcoding the expected result — exact numeric/ML targets (with tolerance), byte-exact outputs, format constants — is fine and often required. For config-driven tasks, confirm the dependency by mutating the config and re-running (the output must change).

Matching at the Wrong Specificity

Assert at the specificity the instruction states. If the instruction pins an exact output — a format, a filename, a byte-exact artifact — then == or a byte comparison is required, and a looser check fails to verify what the task asked for. If the instruction is silent on format, assert semantics only and never ==, because you would be grading formatting the task never specified.

The word that decides it is undocumented: a check is brittle when it pins something the instruction never stated, not because it uses ==.

The required path and filename are part of that contract. A correct implementation must not fail because instruction.md names /app/report.json while the verifier reads /app/output/report.json, or because the verifier expects a different filename. Check both directions: every path the verifier grades is disclosed, and every required output path in the instruction is the artifact the verifier actually reads.

PYTHON

Copy
# BAD: the instruction never specifies the log wording, so `==` grades undocumented formatting
def test_output():
    output = open("/output/log.txt").read()
    assert output == "Processing complete\n"

# BAD: too loose in the other direction — an agent that echoes the word anywhere passes
def test_output():
    output = open("/output/log.txt").read()
    assert "complete" in output.lower()

# GOOD: the instruction specifies the report schema, so assert the parsed values
def test_run_reports_completion():
    """The documented status field must report completion, with the processed count."""
    report = json.loads(Path("/app/output/report.json").read_text())
    assert report["status"] == "complete"
    assert report["records_processed"] == 1432
When the instruction does pin the output exactly, == is the correct check — see What a Good Verifier Legitimately Does for golden fixtures and byte-exact comparison.

Checking a Proxy Instead of the Value

Counts, endpoints, sums, existence, first-element, or "the schema declares this field" all let corrupted or fabricated output pass. Assert the actual content.

PYTHON

Copy
# BAD: only the NUMBER of records is checked; the values are reconstructed from the agent's own
# input trace, so a program that fabricates responses passes.
def test_beats():
    assert len(read_beats()) == expected_count

# BAD: the report schema requires total_attested and laws, but no test asserts them, so a
# report that omits or falsifies them passes.

# GOOD: assert the real values, from a source the agent does not control
def test_beats_carry_correct_data():
    """Each DRAM read beat must return the value written to that address."""
    beats = read_beats()
    assert [b["data"] for b in beats] == GOLDEN_BEAT_DATA   # sealed golden, not derived from input

def test_report_has_required_fields_with_correct_values():
    """total_attested/total_matched/name/laws must be present and correct."""
    rep = json.load(open("/app/output/report.json"))
    assert rep["total_attested"] == 42 and rep["laws"] == GOLDEN_LAWS
Watch for: checking only the first element of a sequence; validating a field's presence but not its value; recomputing the "expected" answer from an input the agent could truncate or replace.

Grading a Delivered Binary Without Rebuilding

If the verifier runs a prebuilt artifact the agent delivered, without rebuilding it from the submitted source and without varying the input, a hardcoded binary that emits the fixed answer passes — it never has to implement anything.

PYTHON

Copy
# BAD: run whatever binary the agent delivered, against the same fixed input every time.

# GOOD: rebuild from the submitted source, and vary the input so a hardcoded output can't pass
def test_decoder_actually_decodes_a_fresh_registry():
    """A rebuilt decoder must handle a registry it has never seen."""
    rebuild_from_source("/app/src")                 # not the delivered binary
    out = run_agent_cli("decode", make_random_registry())
    assert out == expected_for(that_registry)
This is what Perturbation / holdout re-runs is for — use it, and rebuild rather than trusting the delivered binary.

Rebuilding is not permission to ignore the deliverable. If the instruction requires the agent to leave a binary, package, report, or other built artifact, the verifier must validate that required artifact as well as the clean rebuild and confirm they correspond. Testing only a separately rebuilt copy allows a stale, fabricated, or independently prepared deliverable to pass.

No Equivalence Between Artifacts the Agent Controls Both Sides Of

When correctness depends on two representations agreeing — a simulated build and a synthesized one, or a library and the consumer that exercises it — and the agent controls both, grade the equivalence, not each side alone. Otherwise the agent satisfies each with different code.

PYTHON

Copy
# BAD: simulation and synthesis are separate tool invocations with no cross-check, so functional
# code is shown to the simulator and a dummy module to the synthesizer, and both pass.
# BAD: an "API preserved" test runs an agent-built consumer the agent can rewrite alongside the library.

# GOOD: drive both from the same source and assert identical behavior, or run a consumer the
# verifier owns (not one the agent can edit).
Deriving Ground Truth from Agent-Writable Paths

Goldens, corpus metadata, sizing truth, or default held-out fixtures must not come from paths the agent can edit. If the verifier reads expected bytes, row counts, or structural properties from /app, a mutable corpus, or an agent-delivered tree, the agent can replace the truth and pass with the wrong answer.

PYTHON

Copy
# BAD: sizing limits are inferred from filenames in /app/corpus — the agent can swap file contents
# while keeping the same names and pass every size check.
peak = max(os.path.getsize(p) for p in glob("/app/corpus/*"))

# BAD: the held-out case is built at grade time from agent-visible inputs under /app.
held_out_input = read_json("/app/config/held_out.json")

# GOOD: goldens and held-out inputs live in the verifier image (baked into tests/Dockerfile).
GOLDEN = (Path(__file__).parent / "fixtures" / "held_out.golden").read_bytes()
See also Dockerfile Best Practices → Separate Agent-Visible Runtime from Verifier-Only Assets.

Symlink and Copy Staging Leaks

Manually copying or re-owning agent-controlled trees before grading is a smell. copytree follows symlinks by default — an agent symlink can make protected verifier fixtures look like agent output. The fix is architectural, not a copy flag.

PYTHON

Copy
# BAD: staging an agent-controlled tree by hand. copytree follows symlinks by default, so a
# symlink to /tests/fixtures/expected.json lands in staging as the golden's contents.
shutil.copytree("/app/submission", "/tmp/staging")
GOOD: Put the verifier in its own container. Terminus requires the explicit [verifier].environment_mode = "separate" key in task.toml (Harbor also treats a [verifier.environment] table as separate; with neither it defaults to shared — Terminus CI rejects both the implicit-only form and that shared default). Keep goldens and held-out fixtures in the verifier image — baked into tests/Dockerfile. They never exist in the agent's container. They do exist in the verifier, and if you rebuild and run the agent's program there, that process can read them unless you drop uid before the exec and confirm it cannot. Declare explicit artifact paths in top-level artifacts; let the harness copy those into the verifier — don't stage agent directories yourself.

Instruction Tolerance Must Match Verifier Tolerance

When instruction.md states a numeric error band — "within 1e-4", "±0.01", "relative error below 1%" — the tests must enforce that same band, not a tighter one the agent was never told about. A conforming implementation that satisfies the written spec should not fail because the verifier demands extra precision.

PYTHON

Copy
# BAD: instruction says "match within 1e-3"; test asserts 1e-9.
assert abs(got - expected) < 1e-9

# GOOD: use the tolerance from the instruction (or a single stricter value also stated there).
assert abs(got - expected) <= 1e-3
If the verifier needs a tighter band for stability, state it in the instruction.

Optimization Objectives and Tie-Breaks Must Be Tested

When the spec defines an objective — minimize peak memory, then job count; minimize cost subject to a SLA; preserve lexicographic order on ties — the verifier must reject a solution that satisfies feasibility but optimizes the wrong quantity or ignores the tie-break. Checking only that some valid plan exists, or only the first term in a multi-part objective, lets a materially wrong optimizer pass.

PYTHON

Copy
# BAD: spec says "minimize peak batch size, then number of batches"; test only checks every
# item is assigned and under the cap — a plan with twice as many batches as necessary passes.

# GOOD: construct or load a case where two feasible plans differ on the primary objective (or on
# the tie-break when the primary ties) and assert the agent's output matches the better one.
assert plan.peak_size <= ALT_PLAN.peak_size
assert plan.batch_count <= ALT_PLAN.batch_count if plan.peak_size == ALT_PLAN.peak_size else True
Spot-check the oracle on such a case too — a reference that hardcodes one heuristic may encode the wrong objective into the tests.

Stated Lifecycle and Resilience Behavior Must Be Tested

If the instruction promises restart or crash recovery, idempotency, invalid-input handling, concurrency, existing-output behavior, or reset semantics, exercise that behavior directly. A happy-path run cannot establish a lifecycle promise.

Choose cases that isolate the stated guarantee: interrupt before and after the durability boundary, invoke twice, start from an existing output, submit malformed input, overlap operations, or reuse state across cycles as the contract requires. Do not add lifecycle requirements to a task whose contract does not claim them.

Agent Code Must Not Redefine What Gets Graded

Do not import, load, or execute agent-controlled modules before the verifier has fixed the meaning of the assertions that follow. In DSL or proof tasks, agent-exported notations, macros, or hooks can make equality and range checks vacuous. For subprocess checks, assert the exit code (and stderr when relevant), not a stdout prefix the agent can print without running the real tool.

PYTHON

Copy
# BAD: import Solution before parsing pinned obligation types — agent notations can rewrite "=".
import submitted_solution  # agent module loaded first
assert parse_obligations(submitted_solution) == EXPECTED

# BAD: pass if stdout contains "result" regardless of simulator exit code.
assert "result" in proc.stdout

# GOOD: parse expected types from sealed fixtures first; load agent code in an isolated step;
# compare against fixed expectations. Require proc.returncode == 0.
Hardcoded Random Values

PYTHON

Copy
# BAD: Assumes specific random output
def test_random():
    result = generate_random()
    assert result == 42

# GOOD: Check properties
def test_random():
    result = generate_random()
    assert 1 <= result <= 100
Order-Dependent Tests

PYTHON

Copy
# BAD: Tests depend on execution order
def test_1_setup():
    global data
    data = load_data()

def test_2_process():
    process(data)  # Fails if test_1 didn't run first

# GOOD: Each test is independent
def test_process():
    data = load_data()
    result = process(data)
    assert result is not None
CI Validation

Your tests will be validated by:

behavior_in_tests	All task requirements have tests
behavior_in_task_description	All tested behavior is in instruction.md
informative_test_docstrings	Each test has a docstring
ruff	Code passes linting
