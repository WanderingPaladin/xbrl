Dockerfile & Image Best Practices

This is the canonical requirements and reference page for Dockerfile and image quality. Use Creating Docker Environment for starter Dockerfiles, compose shapes, and local build commands; use this page when you need to understand or fix Dockerfile CI checks.

All Terminal-Bench task images must be:

Reproducible	The same source builds to the same image over time and across systems
Cacheable	Common layers are shared across tasks
Lazy-pull friendly	Startup-critical files are accessible without pulling the full image
Auditable	Images are digest-pinned, signed, labeled, and free of any secrets
Complete	Images contain all required dependencies — tasks must not depend on fetching dependencies at run time. [environment].network_mode is "public" on every task so the build can run; [agent] and [verifier] are set per task
Siloed	The image must not leak task solutions or tests
Resourced	Tasks must define CPU, memory, and storage needs in task.toml
CI Enforcement Summary

Four Dockerfile checks block by default:

check_pinned_images	Every FROM image must be digest-pinned with @sha256:<digest>
check_sanctioned_base_images	The final runtime base image must be sanctioned or explicitly exempt
check_build_context_size	environment/ must be at most 100 MiB total, with no file over 50 MiB
check_modal_dockerfile_compat	COPY --chown= uses numeric user/group IDs; COPY --from= image refs are digest-only (no :tag@sha256)
The remaining Dockerfile checks warn by default, but warning checks can still emit structural errors when required files such as environment/ or environment/Dockerfile are missing.

Cloud Image Builder Syntax

Local Docker accepts two patterns that the Terminus 3 cloud image builder rejects. Preflight scans every Dockerfile in the submission (environment/Dockerfile, tests/Dockerfile, and any others) and fails immediately with the line to change — you do not wait for a long eval to crash.

These rules do not change FROM pins. FROM image:tag@sha256:<digest> is still required. Stage names such as COPY --from=builder are still fine. RUN chown is unchanged.

1. COPY --chown= must use numeric IDs. Named users (root, appuser) are not resolved.

DOCKERFILE

Copy
# Bad
COPY --chown=root:root script.sh /app/script.sh
COPY --chown=appuser:appuser src/ /app/src/

# Good
COPY --chown=0:0 script.sh /app/script.sh
COPY --chown=1000:1000 src/ /app/src/
2. COPY --from= image refs must be digest-only. If the source is an image (not a build stage), drop the :tag and keep @sha256:<digest>.

DOCKERFILE

Copy
# Bad — tag and digest together
COPY --from=golang:1.24-bookworm@sha256:<digest> /usr/local/go /usr/local/go

# Good — digest only
COPY --from=golang@sha256:<digest> /usr/local/go /usr/local/go

# Good — stage name (not an image ref)
COPY --from=builder /build/target/release/my-tool /usr/local/bin/my-tool
1. Pin Base Images by Digest

Every FROM line must use an immutable digest. Never use floating tags such as latest. Tags may be included for readability, but the digest is the source of truth. CI will fail any Dockerfile with a FROM line lacking @sha256. Update digests deliberately, in reviewable commits.

DOCKERFILE

Copy
# Bad
FROM public.ecr.aws/docker/library/python:3.13-slim-bookworm

# Good
FROM public.ecr.aws/docker/library/python:3.13-slim-bookworm@sha256:...
2. Use Sanctioned Runtime Base Images

Prefer the canonical Terminal-Bench base images below over ad hoc public images for the final runtime stage. Builder stages may use task-appropriate toolchain images, but the final stage is what agents and verifiers run in and is checked by CI.

Why a canonical list: Tasks across the dataset have been fragmenting onto many slightly different base images (different tags, different registries, different patch versions) for no real reason. Reusing a small set of canonical images dramatically improves cache hit rates, reduces verifier startup time, and keeps the dataset's runtime surface area manageable.

Canonical base images

Use the exact digest-pinned reference from this list whenever possible. The list intentionally collapses minor version variants into one canonical entry per family (e.g., the Go entry covers all Go 1.21–1.26 majors plus alpine/bullseye/bookworm variants — use the canonical row).

Language runtimes
public.ecr.aws/docker/library/python:3.13-slim-bookworm@sha256:01f42367a0a94ad4bc17111776fd66e3500c1d87c15bbd6055b7371d39c124fb	Python	All Python 3.10/3.11/3.12/3.13 majors + patch + slim/non-slim
public.ecr.aws/docker/library/node:22-bookworm-slim@sha256:f3a68cf41a855d227d1b0ab832bed9749469ef38cf4f58182fb8c893bc462383	Node.js	All Node 18/20/22/24 majors + slim/non-slim
public.ecr.aws/docker/library/golang:1.24-bookworm@sha256:1a6d4452c65dea36aac2e2d606b01b4a029ec90cc1ae53890540ce6173ea77ac	Go	All Go 1.21–1.26 majors + alpine/bullseye/bookworm
public.ecr.aws/docker/library/rust:1.85-slim@sha256:9f841bbe9e7d8e37ceb96ed907265a3a0df7f44e3737d0b100e7907a679acb36	Rust	All Rust 1.75–1.95 + slim/non-slim + bullseye
public.ecr.aws/docker/library/eclipse-temurin:21-jdk-jammy@sha256:25d1276565738d3c805e632a4542c3a7598866ef967f4def6544c15de3a74b14	Java (JDK)	All Java 17/21 jdk-jammy/noble variants
public.ecr.aws/docker/library/gcc:13-bookworm@sha256:930f2ebe239275fa67226654cb79273ea34eee672ae61c8a39f689c37fb7ac5c	C / C++ (GCC)	All GCC 12/13/14/15 variants
public.ecr.aws/docker/library/ruby:3.3-slim-bookworm@sha256:e76733e94b3a5893e4a141024ef3a583dc10781dc24becebf74f9c9f9a33e3df	Ruby	All Ruby 3.2/3.3/3.4 + slim/non-slim
Build tools and SDKs
public.ecr.aws/docker/library/maven:3.9.9-eclipse-temurin-21@sha256:3a4ab3276a087bf276f79cae96b1af04f53731bec53fb2e651aca79e4b10211e	Maven	All Maven + temurin-17/21 variants
Distro bases (for minimal or custom images)
public.ecr.aws/docker/library/debian:bookworm-slim@sha256:4724b8cc51e33e398f0e2e15e18d5ec2851ff0c2280647e1310bc1642182655d	Debian	All Debian bookworm/bullseye/12.x slim variants
public.ecr.aws/docker/library/ubuntu:24.04@sha256:0d39fcc8335d6d74d5502f6df2d30119ff4790ebbb60b364818d5112d9e3e932	Ubuntu	All Ubuntu 22.04/24.04/jammy variants
Using a non-canonical base image

Tasks may use a base image not on this list if there's a genuine reason — for example, a runtime the canonical list doesn't cover, a hardware-specific image, or a stack that requires a niche distro. The acceptance gate works as follows:

Canonical (from the tables above)	Not required	✅ Passes
Non-canonical	Present and credible (as a Dockerfile comment)	✅ Passes; surfaced to reviewers for judgment
Non-canonical	Empty / missing / boilerplate	❌ Blocked
Examples of acceptable justifications:

"The canonical Java image is JDK-only; this task requires a full JRE-plus-system-libraries setup."
"Targeting a new language not yet in the canonical list (e.g., Zig, Crystal)."
"Stress-testing behavior specific to a Red Hat-derived distribution that Debian-derived canonical images don't reproduce."
A reviewer can reject a non-canonical base if the justification is missing, vague, or matches an existing canonical entry (i.e., the canonical image would have worked fine).

What a good base-image family provides

Shell utilities required by the harness (tmux, asciinema)
Observability tooling, if required
Standard CA certificates and locale configuration
Common verifier/runtime bootstrap tools
A pinned package-manager baseline
3. Make Builds Reproducible

Pin all dependencies and avoid nondeterministic build steps.

Pin language dependencies with lockfiles:

Python	requirements.txt with exact versions, uv.lock, poetry.lock
Node	package-lock.json, pnpm-lock.yaml, yarn.lock
Rust	Cargo.lock
Go	go.mod and go.sum
JVM	Pinned Maven/Gradle dependency locks where possible
Pin downloaded binaries by version and checksum. Avoid curl | sh unless the artifact is version-pinned and checksum-verified:

DOCKERFILE

Copy
# Bad
RUN curl -LsSf https://astral.sh/uv/install.sh | sh

# Good
ARG UV_VERSION=0.6.14
ARG UV_SHA256=...
RUN curl -fsSL "https://github.com/astral-sh/uv/releases/download/${UV_VERSION}/uv-x86_64-unknown-linux-gnu.tar.gz" -o /tmp/uv.tar.gz \
    && echo "${UV_SHA256}  /tmp/uv.tar.gz" | sha256sum -c - \
    && tar -xzf /tmp/uv.tar.gz -C /usr/local/bin --strip-components=1 \
    && rm /tmp/uv.tar.gz
Also avoid build steps that embed:

Wall-clock time
Random paths or hostnames
Usernames
Nondeterministic generated output
Set deterministic build environment variables where applicable (e.g., SOURCE_DATE_EPOCH). Use BuildKit/buildx for consistent builds.

4. Structure Layers from Least Volatile to Most Volatile

Order Dockerfile operations so task edits only invalidate top layers.

Requirements:

Put base OS and runtime dependencies before task-specific source
Copy manifest files before copying source files
Install dependencies before copying frequently edited files
Do not use COPY . /app unless the task directory is minimal and .dockerignore is strict
Avoid squashing all content into one layer
Aim for a moderate number of purposeful layers
Preferred pattern:

DOCKERFILE

Copy
FROM <base>@sha256:...

# 1. OS/system packages
RUN apt-get update \
    && apt-get install -y --no-install-recommends ... \
    && rm -rf /var/lib/apt/lists/*

# 2. Runtime/package-manager setup
COPY requirements.txt /tmp/requirements.txt
RUN pip install --no-cache-dir -r /tmp/requirements.txt

# 3. Project manifests
COPY pyproject.toml uv.lock /app/

# 4. Dependency fetch/install
RUN ...

# 5. Source and task files
COPY src/ /app/src/
COPY data/ /app/data/

# 6. Task-specific build step, if needed
RUN ...

WORKDIR /app
5. Consolidate apt Usage Correctly

Use one apt transaction per stage and volatility class.

Requirements:

Do not run apt-get upgrade
Do not leave /var/lib/apt/lists/* in the image
Do not install recommended packages unless required
Do not install build tools in the runtime stage unless the task requires them
Prefer moving common apt packages into sanctioned base images
DOCKERFILE

Copy
# Bad
RUN apt-get update && apt-get install -y git
RUN apt-get update && apt-get install -y tmux asciinema
RUN apt-get update && apt-get install -y python3 python3-pip

# Good
RUN apt-get update \
    && apt-get install -y --no-install-recommends \
        asciinema \
        ca-certificates \
        git \
        python3 \
        python3-pip \
        tmux \
    && rm -rf /var/lib/apt/lists/*
6. Keep Build Tools Out of Runtime Images

Use multi-stage builds whenever the Dockerfile compiles or bundles artifacts. If the task requires the agent to compile or build code, toolchains in the final image are fine.

Use multi-stage builds for: cargo build, go build, mvn package, gradle build, npm ci && npm run build, dotnet publish, C/C++ builds with make/cmake, or similar.

DOCKERFILE

Copy
FROM public.ecr.aws/docker/library/rust:1.85-slim@sha256:... AS builder
WORKDIR /build
COPY Cargo.toml Cargo.lock ./
COPY src/ src/
RUN cargo build --release --locked

FROM public.ecr.aws/docker/library/debian:bookworm-slim@sha256:...
RUN apt-get update \
    && apt-get install -y --no-install-recommends ca-certificates \
    && rm -rf /var/lib/apt/lists/*
COPY --from=builder /build/target/release/my-tool /usr/local/bin/my-tool
WORKDIR /app
When COPY --from= points at an image rather than a stage name, use a digest-only ref — not image:tag@sha256:…. See Cloud Image Builder Syntax.

7. Images Must Contain All Dependencies

Images must contain everything the task needs at build time. [environment].network_mode is "public" on every task so the build and harness install can run — that is not licence to fetch dependencies at trial time. Network access is for the task's own work, not for installing tooling. The requirements below apply in full to tasks whose agent runs offline.

Requirements:

tmux and asciinema must be installed — the agent runtime requires both to start a session. Missing them breaks tasks that run without network access, since nothing can fetch them at runtime; a task with network access may still obtain them and appear to work. Install them explicitly either way.
All package downloads happen at image build time
test.sh must not use curl, wget, pip install, npm install, cargo fetch, mvn dependency:get, or similar networked operations
Python wheels, npm packages, Maven artifacts, Cargo registry state, reference binaries, and fixtures must be preloaded during build
For tasks with [agent].network_mode = "no-network", the Oracle agent must pass with network access disabled
Agents must be able to complete the task without any missing assets or dependencies
Internet access (network_mode)

Network access is set per phase, and each setting must accurately match what that phase genuinely needs.

[environment].network_mode must be "public" on every task. The image is built and the agent harness installed during this phase, and both need the network. Closing it here fails the task before the agent runs — this is not an author choice.
[agent].network_mode — "public" or "no-network". Use "no-network" when the task should be solved offline, for example when network access would let the agent retrieve the answer rather than do the work.
[verifier].network_mode — "public" or "no-network". Normally "no-network": verifier dependencies belong in tests/Dockerfile, not fetched at grade time.
An offline task keeps [environment] public and closes [agent]. Making the environment "no-network" does not produce an offline task — it produces a task that cannot build.

Independently of these settings, all of your task's own dependencies must still be baked into the image at build time, and test.sh must never fetch from the network at trial time. A "public" phase exists for the task's work — not as a substitute for a complete image.

8. Separate Agent-Visible Runtime from Verifier-Only Assets

Solution files, hidden tests, and privileged assets must never be accessible to the agent.

Requirements (agent environment):

Do not copy solution/ into the runtime image
Do not copy hidden tests into agent-visible locations
Do not store expected outputs in writable agent paths
Do not let the verifier derive ground truth from files the agent can modify
Place reference binaries or fixtures in controlled verifier-only locations
Public fixtures used by the task may be copied into the image; hidden verifier assets must stay isolated
The verifier image needs its own pass. Terminus tasks must run the verifier in separate mode so goldens baked into tests/Dockerfile never exist in the agent container.

Harbor resolves verifier mode from the combination of keys, not from one required spelling:

[verifier].environment_mode = "separate", or a [verifier.environment] table, resolves to separate.
With neither, Harbor defaults to shared — the verifier runs in the agent environment.
environment_mode = "shared" together with a [verifier.environment] table is invalid.
Terminus-specific (not Harbor): CI requires the explicit [verifier].environment_mode = "separate" key, and artifacts must be a top-level key. The implicit Harbor form ([verifier.environment] with no environment_mode) is valid separate mode in Harbor; Terminus rejects it. Omitting both would be Harbor's shared default; Terminus rejects that too. Set the explicit key so accepted tasks always run separate. See CI Checks Reference.

Separate mode protects the verifier from the agent environment, not from code that the verifier itself executes. If a test rebuilds and runs agent-supplied code inside the verifier, do not assume verifier-only assets are inaccessible to that process. Goldens, held-out fixtures, and test_outputs.py itself live in that container. Drop to an unprivileged uid before that exec, confirm that uid cannot read verifier-only assets or /logs/verifier (including reward.txt), and probe it in a test. A single USER for the whole verify phase cannot express this split: the verifier must read the goldens while the agent's program must not. Do not prescribe a COPY mode or a chmod octal — cloud COPY --chown= uses numeric IDs and builder-assigned modes; build the boundary in the image and the runner.

9. Use .dockerignore and Narrow COPY

All non-trivial tasks must include a .dockerignore file.

Requirements:

Keep environment/ at or below 100 MiB total
Keep each individual file in environment/ at or below 50 MiB
Prefer COPY file file or COPY src/ src/ over COPY . .
Do not copy local caches, virtualenvs, build outputs, .git, editor files, or credentials
Recommended .dockerignore template:


Copy
.git
.gitignore
**/__pycache__/
**/*.pyc
**/.pytest_cache/
**/.mypy_cache/
**/.ruff_cache/
**/node_modules/
**/target/
**/dist/
**/build/
**/.venv/
**/venv/
.env
*.log
solution/
tests/
10. Store Files as Files, Not Heredocs or Opaque Archives

Source code should be visible as source files on disk, not embedded in the Dockerfile.

DOCKERFILE

Copy
# Bad
RUN cat > /app/foo.py <<'EOF'
print('hello world')
EOF

# Good
COPY hello_world.py /app/hello_world.py
Extract archives at build time so snapshotters can lazy-load individual files:

DOCKERFILE

Copy
# Bad
COPY fixtures.tar.gz /tmp/fixtures.tar.gz

# Good
COPY fixtures.tar.gz /tmp/fixtures.tar.gz
RUN mkdir -p /app/fixtures \
    && tar -xzf /tmp/fixtures.tar.gz -C /app/fixtures \
    && rm /tmp/fixtures.tar.gz
11. Use Metadata-Preserving COPY Options

Only change permissions for files that actually need it. Do not recursively rewrite metadata across /app.

DOCKERFILE

Copy
# Bad
RUN chmod -R 755 /app
RUN chown -R appuser:appuser /app

# Good — COPY --chown= must be numeric IDs (named users fail cloud builds)
COPY --chmod=0755 run.sh /usr/local/bin/run-task
COPY --chown=1000:1000 src/ /app/src/
12. General Image Hygiene

Unless required by the task, images must not contain:

.git, .env, credentials or tokens, SSH keys
Package-manager or compiler caches
Unused build tools or test fixtures
Local editor files or vendor documentation unrelated to the task
Large unused datasets or hidden solution files
Perform cleanup in the same layer that creates files:

DOCKERFILE

Copy
# Bad
RUN apt-get update
RUN apt-get install -y build-essential
RUN rm -rf /var/lib/apt/lists/*

# Good
RUN apt-get update \
    && apt-get install -y --no-install-recommends build-essential \
    && rm -rf /var/lib/apt/lists/*
13. Optimise for Lazy Pull and Hot-Path Locality

Put startup-critical files in earlier, smaller layers. Put cold optional assets in later layers.

Startup-critical files for Terminal tasks typically include:

Shell entrypoints
Task instructions
Small runtime scripts
Dependency metadata
Small fixtures needed by the first command
Requirements:

Keep large optional datasets out of the image where possible; mount or fetch them at runtime when the task design and platform allow it
Avoid compressing many runtime files into a single archive
If using eStargz or Nydus, ensure the image converts cleanly and provide a prioritized file list for startup-critical paths
14. Declare Task Resources Explicitly

task.toml must include an [environment] section with realistic resource definitions. Use peak resources observed from real agent runs. The Oracle must always pass with the defined limits.

Requirements:

CPU, memory, and storage must reflect actual task needs
Do not over- or under-request resources
Build timeout must account for compilation-heavy tasks but remain bounded
Agent and verifier timeouts must be realistic
TOML

Copy
[agent]
timeout_sec = 900

[verifier]
timeout_sec = 420

[environment]
build_timeout_sec = 600.0
docker_flags = []
cpus = 1
memory_mb = 2048
storage_mb = 10240
gpus = 0
gpu_types = []
network_mode = "public"     # required on every task
Note — gpus, gpu_types, and docker_flags are optional. These are valid Harbor resource fields, not requirements. Terminus 3 tasks must not require GPU, so gpus and gpu_types may be omitted or left blank — a task is equally valid with or without them. gpu_types only matters when a task actually requests GPUs (gpus > 0); for a typical non-GPU task, gpu_types = [] adds nothing. The minimal form below is just as acceptable as the full block above:

TOML

Copy
[environment]
build_timeout_sec = 600.0
cpus = 1
memory_mb = 2048
storage_mb = 10240
network_mode = "public"     # required on every task
15. Publish Images with Audit Metadata

Include OpenContainers labels to support downstream auditing:

DOCKERFILE

Copy
LABEL org.opencontainers.image.source="..."
LABEL org.opencontainers.image.revision="..."
LABEL org.opencontainers.image.created="..."
LABEL org.opencontainers.image.version="..."
LABEL org.opencontainers.image.licenses="..."