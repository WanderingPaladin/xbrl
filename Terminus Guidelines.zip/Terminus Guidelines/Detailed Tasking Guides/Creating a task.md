Creating a Task

Note: These videos were recorded for Terminus 2nd Edition. The workflow still applies, but the task structure has changed — see What's New and Task Components.
Learn how to create a new task from scratch using the task skeleton template.

Getting Started

To create a new task, you'll start with the task skeleton template and customize it for your specific task.

Step 1: Download the Task Skeleton

Download the task skeleton — there is a single skeleton for this edition. It ships as a complete working task with every field you must fill in marked REPLACE.

Step 2: Extract and Rename

Extract the ZIP file to your desired location
Rename the unzipped folder to match your task name
Naming conventions:

Use kebab-case (lowercase, hyphens)
Be descriptive but concise
Examples: parse-json-logs, debug-python-import, configure-nginx-ssl
Good task names:

✅ parse-json-logs
✅ debug-python-import
✅ configure-nginx-ssl
Bad task names:

❌ task1
❌ my-task
❌ test
Task Structure

After extracting and renaming, you'll have a folder structure like this:

Task layout:


Copy
your-task-name/
├── task.toml           # Task configuration and metadata
├── instruction.md      # Task instructions (markdown)
├── environment/        # Environment definition folder
│   ├── Dockerfile      # OR docker-compose.yaml
│   └── data/           # Bundled inputs
├── solution/           # Oracle solution
│   └── solve.sh        # Solution script + dependencies
└── tests/              # Verifier (runs in a separate container)
    ├── Dockerfile      # Verifier image
    ├── test.sh         # Verifier entrypoint
    └── test_outputs.py # Python pytest assertions
Next Steps

After downloading and renaming your task skeleton:

Edit instruction.md — Write clear, unambiguous task instructions

Guide: Writing task instructions
Configure task.toml — Set up metadata and configuration

Guide: Task Components
Set up environment — Configure Docker in the environment/ folder

Guide: Creating Docker environment
Write the solution — Create solution/solve.sh

Guide: Writing oracle solution
Create tests — Write tests/test.sh and Python pytest files

Guide: Writing tests
Test locally — Run the oracle agent to verify your task works

Guide: Oracle agent
