CI Checks Reference

Automated checks run against every submission. Errors block acceptance; warnings should be fixed unless a reviewer approves an exception.

Run the local CLI checks before submitting:

BASH

Copy
stb harbor check <task-folder>
Check list evolving. Terminus 3 uses the Terminal-Bench 3.0 check suite. The list below covers the checks that apply to Terminus 3 submissions; individual checks may be added or adjusted as the edition progresses.
The quality panel is a separate five-axis review that gates the difficulty measurement before human review. It is not one of the stb harbor check items below. Axis verdicts of Minor or Major block, except on protected_ground_truth, where only Major blocks. Findings explicitly marked Advisory do not block. See the Quality Panel Judge Guide.

Manifest & Metadata

Required fields present — task.toml must contain every required field. See Task Components.

Verifier configured for separate mode — Terminus requires the explicit [verifier].environment_mode = "separate" key, and artifacts must be a top-level key. Harbor itself also resolves to separate when a [verifier.environment] table is present (even without environment_mode), and defaults to shared when neither is set; environment_mode = "shared" plus [verifier.environment] is invalid in Harbor. Terminus CI does not accept the implicit Harbor form or the shared default — that restriction is Terminus-specific, not Harbor. Without the check, Harbor would grade in the agent environment.

⚠️ Silent failure: nesting artifacts under [verifier] does not error — the value is silently dropped and your verifier receives nothing. Keep it top-level.
Timeout ceiling — [agent].timeout_sec and [verifier].timeout_sec must not exceed 18000 seconds (5 hours). The agent-timeout minimum of 1800 seconds is a reviewer criterion rather than a CI error.

Task folder name length — the folder name is capped at a maximum number of hyphen-separated tokens. Long slugs become unwieldy in CLI output, logs, and artifact paths.

Instructions

Absolute paths — instructions must reference absolute paths (/app/output.json), never paths relative to an assumed working directory.

Referenced files are described — every file your tests read or write must be mentioned in instruction.md. If a test checks /app/output/results.json, the instruction has to tell the agent to produce it. This catches tasks with implicit expectations the agent cannot know about.

Human-authored content — instruction.md and solve.sh are screened for AI-generated text, and a submission fails if the probability of AI generation exceeds a threshold. Write your own prompts. See Instruction Prompt Styling.

Environment & Dockerfile

Pinned pip installs — every pip / uv pip / uvx --with install must pin an exact version with ==. Unpinned installs let runtime versions drift after the task was authored.

Unpinned apt installs — the opposite applies to apt: use apt install <package> without =version.

No platform pinning — Dockerfiles must not pin a CPU architecture via FROM --platform=.... Tasks should be portable across architectures.

No bare nproc — inside a container, nproc reports the host CPU count, not your configured limit. Scripts in Dockerfile, test.sh, or solve.sh that call it can request far more parallelism than the task is allocated.

Dockerfile references resolve — files your Dockerfile copies or references must exist in the build context.

Dockerfile hygiene — additional non-fatal warnings flag common issues. See Dockerfile Requirements.

Cloud image builder syntax — blocking preflight (check_modal_dockerfile_compat) on every Dockerfile in the submission. Local Docker often accepts these; the cloud builder does not:

COPY --chown= must use numeric user/group IDs (0:0, 1000:1000), not names such as root or appuser.
COPY --from= image refs must be digest-only (golang@sha256:<digest>), not image:tag@sha256:<digest>. Stage names (COPY --from=builder) are fine. FROM image:tag@sha256:<digest> is unchanged.
The check reports the exact line and the replacement. See Dockerfile Requirements → Cloud Image Builder Syntax.

No host bind mounts in compose — multi-container environments must not use host bind mounts as volume sources. Containers that need to share state must do so another way.

Verifier & Tests

Tests and solution absent from the agent image — tests/ and solution/ must never be copied into the environment image.

Verifier tooling baked in — in separate-verifier mode, test tooling must be installed in tests/Dockerfile. Installing pytest at trial time inside test.sh fails.

Pinned test tooling — verifier dependencies must be pinned to exact versions.

CTRF reporting — pytest-based verifiers must run with --ctrf /logs/verifier/ctrf.json. Enforced by the ctrf_reporting check.

Digest-pinned verifier base — every FROM in tests/Dockerfile must be digest-pinned and on a sanctioned base, the same rule as environment/Dockerfile. Currently reported as a warning rather than a hard failure.

No trial-time network fetches — tests/test.sh must not fetch external resources. Bootstrap patterns like curl … | sh, wget … | sh, and bash <(curl …) are flagged. Everything the verifier needs belongs in its image.

test.sh sanity — the verifier entrypoint is checked for structural problems, including system-wide or global side effects.

Verifier Interpreter Permissions (Platform Preflight)

Blocking platform check. verifier_interpreter_permissions runs in platform submission preflight, before Oracle. It inspects every Python file under tests/. stb harbor check does not run this deterministic check.

The check flags a known cleanup bug: a verifier saves and changes permissions for both /bin/bash and /usr/bin/bash, then restores the saved modes in the same order. On images where /bin resolves to /usr/bin, both paths refer to one executable. The second saved mode can already be 000, so cleanup leaves Bash non-executable and verifier-log collection fails with Permission denied.

A match is a blocking ERROR with the verifier filename, line and repair guidance. Resolve and deduplicate the targets before saving or changing their modes, then restore each original mode once. See Writing Tests → Preserve Interpreter Permissions.

The matcher is only that dual-path restoration pattern (both Bash paths in a list or tuple, saved and restored in order, no Path.resolve() deduplication). Other permission changes are not a finding. The check does not repair your files. A source file that cannot be read or parsed produces an incomplete-check warning for that file; the rest of the scan continues. After repairing the verifier, validate a complete Oracle run, including reward and log collection.

Internet Access

[environment].network_mode must be "public" on every task — the build and harness install need it. Set [agent] and [verifier] to "public" or "no-network" as the task requires:

TOML

Copy
network_mode = "public"       # required

[agent]
network_mode = "no-network"   # or "public"

[verifier]
network_mode = "no-network"   # or "public"
Regardless of the setting, verifier tooling must be baked into tests/Dockerfile — test.sh may never fetch at trial time.

Acting on Failures

Errors first — these block acceptance.
Then warnings — fix unless a reviewer has approved an exception.
Re-run stb harbor check until clean. Platform-only preflights such as verifier_interpreter_permissions are not in that CLI — fix those from the platform report, then re-submit.
Then measure difficulty.