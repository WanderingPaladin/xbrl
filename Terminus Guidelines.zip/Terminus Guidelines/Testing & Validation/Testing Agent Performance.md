Testing Agent Performance

Test your task against real AI agents to validate difficulty and ensure your task challenges frontier models appropriately.

Prerequisites

Get your API key: Use the Snorkel CLI tool to self-generate and self-replenish your API key. If you run into limits or issues, post on the project Slack channel (#terminus-3-submissions) for assistance

Note: You'll need the stb CLI installed to run agents locally. See Quick Start or CLI User Guide for installation instructions.
Credentials

Agent runs use the AI credentials managed by the stb CLI — you do not need to set OPENAI_API_KEY / OPENAI_BASE_URL manually. Just make sure you're logged in with current credentials:

BASH

Copy
stb login
stb keys refresh   # if credentials are missing or expired
Each key carries a $10 budget and expires after 30 days. There is no way to check how much of it you have spent, so plan your runs conservatively — see Using Your API Key Efficiently in the CLI User Guide.

Available Models

GPT-5.6	-m @openai/gpt-5.6
Claude Opus 5	-m @anthropic/claude-opus-5
Keep the @provider/ prefix. Dropping it on the GPT string fails with INVALID_MODEL_NOT_ALLOWED.

Running Agents

Run these via the Snorkel CLI (stb). Replace <path-to-task> with your task directory.

GPT-5.6

BASH

Copy
stb harbor run -m @openai/gpt-5.6 -p <path-to-task>
Claude Opus 5

BASH

Copy
stb harbor run -m @anthropic/claude-opus-5 -p <path-to-task>
Interpreting Results

Pass

The agent successfully completed the task. Run each agent 4 times to establish a reliable pass rate.

Fail - Good

The agent failed for a legitimate reason:

Didn't understand the complexity
Made reasoning errors
Missed edge cases
This is what we want! The task is challenging.

Fail - Bad

The agent failed due to task issues:

Unclear instructions
Ambiguous requirements
Environment problems
This means your task needs revision.

Determining Difficulty

Run each agent 4 times per model — the same count the platform uses. Difficulty is the mean pass@1 across both models:

Frontier	< 20%
Advanced	20% – < 50%
Core	50% – < 80%
Base	80% – < 100%
There is no best-model / worst-model gate, and tasks above 80% are not rejected — that is the Base tier. See Difficulty Guidelines.

Example Testing


Copy
Run 1 (GPT-5.6): FAIL
Run 2 (GPT-5.6): PASS
Run 3 (GPT-5.6): FAIL
Run 4 (GPT-5.6): PASS
Run 1 (Claude): FAIL
Run 2 (Claude): FAIL
Run 3 (Claude): PASS
Run 4 (Claude): FAIL

GPT-5.6: 2/4 = 50%
Claude:  1/4 = 25%

Accuracy = mean of both = 37.5% → Advanced
Analyzing Failures

When an agent fails:

Watch the terminal recording — See what the agent tried
Check the analysis — Review identified issues
Read the debug pane — Understand why it failed
Ask yourself:

Did the agent fail for a good reason (task difficulty)?
Or a bad reason (unclear instructions)?
Good Failure Reasons

Agent made reasoning errors
Agent missed subtle requirements
Agent didn't have domain knowledge
Multi-step complexity confused agent
Bad Failure Reasons

Instructions were ambiguous
Environment had issues
Tests were too strict
Required information was missing
Adjusting Difficulty

Task Too Easy?

Require the agent to infer the contract from domain evidence rather than stating it
Demand a semantically valid native artifact, not something that merely looks right
Add a second correctness axis that interacts with the first
Verify against hidden variations rather than a single example
Include hidden requirements — things the agent has to discover from the environment, a spec file, or the conventions of the domain
Hidden requirements are not the same as under-specification, and the difference matters. A hidden requirement means the goal is clear but not everything needed to satisfy it is spelled out in the instruction — the agent has to read the config, notice the constraint in the spec, or infer the convention. Under-specification means the goal itself is unclear, so the agent cannot tell what success looks like. The first is good task design; the second is a broken task. It is a genuinely tricky balance.

Obscure trivia is out. Difficulty should come from reasoning, not from knowing a fact the agent could not derive.

Task Too Hard?

Usually there is nothing to fix. A low pass rate is the point — Frontier is a wanted tier, and a task should not be softened just because agents fail it.

Intervene only when the task is hard for the wrong reasons: ambiguous goals, non-determinism, environment defects, or information the agent could not possibly obtain. Those are bugs rather than difficulty, and fixing them is not making the task easier — it is making it valid.

Do not add hints to raise the pass rate. See Instruction Prompt Styling and Difficulty Guidelines.