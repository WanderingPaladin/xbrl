#!/usr/bin/env python3
"""terminus_precheck.py - static pre-check for a Terminus 3 task submission.

Usage
    python3 terminus_precheck.py <submission.zip | task-folder> [--rubric FILE] [--json OUT] [--quiet]

What it does
    Reads every file in the package (it never executes submission code) and reports
    mechanical findings keyed to the criterion IDs used in the reviewer prompt
    (S = structure, M = task.toml, I = instruction, E = environment, O = oracle,
    V = verifier, R = rubric).

    FAIL  very likely violates a checklist criterion or a blocking CI/preflight check
    WARN  possible problem - read the cited lines and judge
    INFO  context the reviewer should look at
    PASS  the check ran and found nothing

    Every FAIL/WARN is a LEAD, not a verdict. Confirm it in the cited file before it
    goes into a review. A task only reaches peer review after CI passes, so anything CI
    enforces should also be confirmed against the CI report before you flag it.

Requires Python 3.11+ (tomllib) and the standard library only (PyYAML is used if present).
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import posixpath
import re
import shlex
import shutil
import sys
import tempfile
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:  # pragma: no cover
    try:
        import tomli as tomllib  # type: ignore
    except ModuleNotFoundError:
        tomllib = None

try:
    import yaml  # optional
except Exception:  # pragma: no cover
    yaml = None

VERSION = "1.0 (2026-09-24)"

# --------------------------------------------------------------------------- reference data
# Canonical Terminal-Bench base images (Dockerfile Requirements, section 2).
CANONICAL_IMAGES = {
    "01f42367a0a94ad4bc17111776fd66e3500c1d87c15bbd6055b7371d39c124fb": "python:3.13-slim-bookworm (Python)",
    "f3a68cf41a855d227d1b0ab832bed9749469ef38cf4f58182fb8c893bc462383": "node:22-bookworm-slim (Node.js)",
    "1a6d4452c65dea36aac2e2d606b01b4a029ec90cc1ae53890540ce6173ea77ac": "golang:1.24-bookworm (Go)",
    "9f841bbe9e7d8e37ceb96ed907265a3a0df7f44e3737d0b100e7907a679acb36": "rust:1.85-slim (Rust)",
    "25d1276565738d3c805e632a4542c3a7598866ef967f4def6544c15de3a74b14": "eclipse-temurin:21-jdk-jammy (Java JDK)",
    "930f2ebe239275fa67226654cb79273ea34eee672ae61c8a39f689c37fb7ac5c": "gcc:13-bookworm (C/C++)",
    "e76733e94b3a5893e4a141024ef3a583dc10781dc24becebf74f9c9f9a33e3df": "ruby:3.3-slim-bookworm (Ruby)",
    "3a4ab3276a087bf276f79cae96b1af04f53731bec53fb2e651aca79e4b10211e": "maven:3.9.9-eclipse-temurin-21 (Maven)",
    "4724b8cc51e33e398f0e2e15e18d5ec2851ff0c2280647e1310bc1642182655d": "debian:bookworm-slim (Debian)",
    "0d39fcc8335d6d74d5502f6df2d30119ff4790ebbb60b364818d5112d9e3e932": "ubuntu:24.04 (Ubuntu)",
}
CANONICAL_FAMILIES = {"python", "node", "golang", "rust", "eclipse-temurin", "gcc", "ruby",
                      "maven", "debian", "ubuntu"}

TAXONOMY = {
    "Science": {"Biology", "Chemistry", "Physics", "Earth", "Robotics", "Math", "Linguistics"},
    "Software": {"Algorithms", "Systems", "Databases", "Data engineering", "Frontend", "Languages"},
    "ML": {"Training", "Inference", "Evaluation", "Kernels"},
    "Operations": {"Finance", "Logistics", "Supply chain", "Claims", "Compliance", "Marketing"},
    "Security": {"Cryptography", "Reverse engineering", "Forensics", "AppSec"},
    "Hardware": {"CAD", "RTL"},
    "Media": {"Music", "Design"},
}
TIERS = {"frontier", "advanced", "core", "base"}
RETIRED_TIERS = {"easy", "medium", "hard"}
TARGET_LANGUAGES = {"python", "c", "c++", "cpp", "javascript", "typescript", "java", "go", "golang",
                    "rust", "c#", "csharp"}

REQUIRED_FILES = ["task.toml", "instruction.md", "environment/Dockerfile", "solution/solve.sh",
                  "tests/Dockerfile", "tests/test.sh", "tests/test_outputs.py"]
META_FIELDS = ["author_name", "author_email", "category", "subcategory", "tags", "languages",
               "difficulty", "expert_time_estimate_hours", "difficulty_explanation",
               "solution_explanation", "verification_explanation", "relevant_experience"]
PROSE_FIELDS = ["difficulty_explanation", "solution_explanation", "verification_explanation",
                "relevant_experience"]
SKELETON_TAGS = {"replace", "3-to-6", "descriptive", "keywords"}

# Harbor-reserved paths that the AGENT image must not create/modify/mount.
RESERVED_RE = re.compile(r"(?<![\w./-])(/tests|/solution|/oracle|/logs/verifier|/logs/artifacts)(?![\w.-])")

SCAFFOLD_FILES = {"claude.md", "claude.local.md", "agents.md", "gemini.md", "skills.md", "skill.md",
                  ".cursorrules", ".windsurfrules", ".clinerules", "copilot-instructions.md"}
SCAFFOLD_DIRS = {".cursor", ".claude", ".codex", ".windsurf", ".aider", ".continue", ".gemini", ".clinerules"}

ARCHIVE_EXT = (".zip", ".tar", ".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2", ".tbz2", ".7z", ".rar",
               ".gz", ".bz2", ".xz", ".zst")
CODE_EXT = (".py", ".js", ".ts", ".tsx", ".jsx", ".c", ".cc", ".cpp", ".h", ".hpp", ".go", ".rs", ".java",
            ".cs", ".rb", ".sh", ".sql", ".v", ".sv", ".vhd", ".scala", ".kt", ".swift", ".lean", ".coq")

# Normalised (CRLF->LF) sha256 of every file in the official default-template skeleton.
TEMPLATE_HASHES = {
    "environment/.dockerignore": "6e8c4eb961e85e1afa59193e8481784f2c54f6b0d53706dfceeb677d298b40bf",
    "environment/Dockerfile": "a6bf9fb151da2931678d71c1d0d50582d6f4c2238e67bc2a379b281bb1befa79",
    "environment/app/data/alpha.txt": "1448d86390bea26d7d5e9f85e35b7b51fe2eb215ad7eed2f0ea87712bffbb57f",
    "environment/app/data/beta.txt": "a948904f2f0f479b8f8197694b30184b0d2ed1c1cd2a1ec0fb85d299a192a447",
    "environment/app/data/gamma.txt": "37bbce1230bbac4c5f5222dbeba2cd0c83b075331ff9b47ca8069724fa76ed92",
    "environment/app/src/summarize.py": "6f50b39b3672eaa13014537769b8c7a9cdab1f516fb1b8d8f5dae564ce8b85c0",
    "instruction.md": "0bc90c215cbbdc5e95becbbc35b69493e2fb457877ad6517f7aa088d2fa384b3",
    "solution/solve.sh": "90becec17a187254dd7a4721dfab74c4ecfbdd4c3b01e12e26c696ff790fdd96",
    "solution/src/summarize.py": "f92883d8500e7ca804717da595d0ddc3bfc623fe72ecbcfd8e85d489d92fb3a2",
    "task.toml": "8bdaef43d5c1554e88e1cf0fa2427bd77a5f6ed786a9a3b55ec42dc64957f7ad",
    "tests/Dockerfile": "59f4686512196d3c52744e39898ec5ab56eaa2f0f6d2554cf32a4d5dab4fd509",
    "tests/holdout/h1/one.txt": "0fedab7a6bcdee67c26091670c1aba184dacda6b69a321611f1dd53910e917c9",
    "tests/holdout/h1/two.txt": "e2f5e5f03e610a675f57cc0a03360a77e6d1f72e000601d00167908a5e11efb1",
    "tests/test.sh": "9648a083f1cabf0b83cc86257f96bbe70166f685015787f028a63177cdbc423e",
    "tests/test_outputs.py": "09157e9d0dbd1b19378f57c8a6f96718a9cdb3c2c6cc7dd4977e5c7f97861b02",
}
# Skeleton files that are fine to keep unchanged (they are the canonical shape).
TEMPLATE_OK_UNCHANGED = {"tests/test.sh", "tests/Dockerfile", "environment/.dockerignore"}

NET_CMD_RE = re.compile(
    r"\b(pip3?\s+install|python3?\s+-m\s+pip\s+install|uv\s+pip\s+install|uv\s+add|uv\s+sync|uvx|pipx\s+install|"
    r"npm\s+(install|i|ci|add)|yarn\s+(add|install)|pnpm\s+(add|install|i)|npx\s|apt-get\s+(install|update)|"
    r"apt\s+(install|update)|curl\s|wget\s|git\s+clone|go\s+(get|install)|cargo\s+(install|fetch)|"
    r"gem\s+install|mvn\s+dependency:get|conda\s+install)")

LEVELS = ("FAIL", "WARN", "INFO", "PASS")


# --------------------------------------------------------------------------- reporting
@dataclass
class Finding:
    level: str
    cid: str
    msg: str
    where: str = ""


class Report:
    def __init__(self) -> None:
        self.sections: list[tuple[str, list[Finding]]] = []
        self._cur: list[Finding] = []

    def section(self, title: str) -> None:
        self._cur = []
        self.sections.append((title, self._cur))

    def add(self, level: str, cid: str, msg: str, where: str = "") -> None:
        assert level in LEVELS, level
        f = Finding(level, cid, msg, where)
        if f not in self._cur:  # de-duplicate identical findings within a section
            self._cur.append(f)

    def all(self) -> list[Finding]:
        return [f for _, fs in self.sections for f in fs]

    def counts(self) -> dict[str, int]:
        c = {k: 0 for k in LEVELS}
        for f in self.all():
            c[f.level] += 1
        return c


# --------------------------------------------------------------------------- helpers
def norm_sha(data: bytes) -> str:
    return hashlib.sha256(data.replace(b"\r\n", b"\n")).hexdigest()


def read_text(p: Path) -> str | None:
    try:
        data = p.read_bytes()
    except OSError:
        return None
    if b"\x00" in data[:8192]:
        return None
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1")


def line_no(text: str, idx: int) -> int:
    return text.count("\n", 0, idx) + 1


def rel(root: Path, p: Path) -> str:
    try:
        return p.relative_to(root).as_posix()
    except ValueError:
        return str(p)


def safe_split(s: str) -> list[str]:
    try:
        return shlex.split(s, comments=False, posix=True)
    except ValueError:
        return s.split()


def iter_files(base: Path):
    if not base.exists():
        return
    for p in sorted(base.rglob("*")):
        if p.is_file():
            yield p


def short(s: str, n: int = 110) -> str:
    s = " ".join(s.split())
    return s if len(s) <= n else s[: n - 1] + "…"


def is_text_file(p: Path) -> bool:
    return read_text(p) is not None


# --------------------------------------------------------------------------- intake
def load_submission(src: Path, rep: Report) -> tuple[Path | None, Path | None]:
    rep.section("0. Intake")
    if src.is_dir():
        rep.add("INFO", "S3", f"Folder input: {src}")
        return src, None
    if not src.exists():
        rep.add("FAIL", "S3", f"{src} does not exist")
        return None, None
    if not zipfile.is_zipfile(src):
        rep.add("FAIL", "S3", f"{src} is neither a folder nor a ZIP file")
        return None, None
    tmp = Path(tempfile.mkdtemp(prefix="tprecheck_"))
    backslash_names = []
    with zipfile.ZipFile(src) as zf:
        infos = zf.infolist()
        total = sum(i.file_size for i in infos)
        if len(infos) > 50000 or total > 2 * 1024 ** 3:
            rep.add("FAIL", "E11", f"ZIP is huge ({len(infos)} entries, {total / 2**20:.0f} MiB unpacked) - not extracted")
            return None, tmp
        for info in infos:
            name = info.filename
            if name.startswith("__MACOSX/") or name.endswith(".DS_Store"):
                continue
            if "\\" in name:
                backslash_names.append(name)
            norm = name.replace("\\", "/")
            pp = PurePosixPath(norm)
            if pp.is_absolute() or ".." in pp.parts:
                rep.add("FAIL", "S3", f"Unsafe ZIP entry skipped: {name}")
                continue
            target = tmp / norm
            if info.is_dir() or norm.endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as fsrc, open(target, "wb") as fdst:
                shutil.copyfileobj(fsrc, fdst)
    if backslash_names:
        rep.add("FAIL", "S3", f"{len(backslash_names)} ZIP entries use backslash separators (e.g. {backslash_names[0]!r}). "
                "Linux tools read these as flat filenames, so folders disappear. Re-create the ZIP with a tool that writes '/'")
    if (tmp / "task.toml").exists():
        rep.add("PASS", "S3", "Task files sit at the ZIP root (no enclosing folder)")
        return tmp, tmp
    entries = [e for e in tmp.iterdir() if e.name != "__MACOSX"]
    if len(entries) == 1 and entries[0].is_dir() and (entries[0] / "task.toml").exists():
        rep.add("WARN", "S3", f"ZIP wraps an enclosing folder '{entries[0].name}/'. Authors must ZIP the files, not the "
                "folder (ignore if this ZIP came from a platform download)")
        return entries[0], tmp
    cands = sorted(tmp.glob("**/task.toml"), key=lambda p: len(p.parts))
    if cands:
        rep.add("WARN", "S3", f"task.toml found only at {rel(tmp, cands[0])}; analysing that folder")
        return cands[0].parent, tmp
    rep.add("FAIL", "S1", "No task.toml anywhere in the ZIP")
    return tmp, tmp


# --------------------------------------------------------------------------- 1 structure
def check_structure(root: Path, rep: Report) -> None:
    rep.section("1. Package structure")
    for f in REQUIRED_FILES:
        if (root / f).is_file():
            rep.add("PASS", "S1", f"{f} present")
        else:
            rep.add("FAIL", "S1", f"Missing required file: {f}")
    allowed = {"task.toml", "instruction.md", "environment", "solution", "tests", "rubrics.txt", "README.md"}
    for e in sorted(root.iterdir()):
        if e.name in allowed:
            continue
        if e.name in ("jobs", "data"):
            rep.add("WARN", "S2", f"Leftover top-level '{e.name}/' (Low: clean up; env data belongs in environment/)")
        else:
            rep.add("INFO", "S2", f"Unexpected top-level entry '{e.name}' - is it used? (Low)")
    for f in ("rubrics.txt", "README.md"):
        if (root / f).exists():
            rep.add("INFO", "S2", f"{f} present - Snorkel adds it at packaging; not expected in an author's ZIP")
    # line endings / shebangs of shell scripts
    for p in list(iter_files(root)):
        if p.suffix == ".sh" or p.name in ("Dockerfile",):
            data = p.read_bytes()
            if b"\r\n" in data:
                rep.add("WARN", "E15", "CRLF line endings - shell scripts with CRLF fail with 'bad interpreter'/'$'\\r'' "
                        "errors in Linux containers", rel(root, p))
    # AI scaffolding anywhere
    for p in sorted(root.rglob("*")):
        low = p.name.lower()
        if (p.is_file() and low in SCAFFOLD_FILES) or (p.is_dir() and low in SCAFFOLD_DIRS):
            r = rel(root, p)
            lvl = "FAIL" if r.startswith("environment/") else "WARN"
            rep.add(lvl, "E8", f"AI-framework scaffolding name '{p.name}' - remove it", r)


# --------------------------------------------------------------------------- 2 skeleton leftovers
def check_skeleton(root: Path, rep: Report) -> None:
    rep.section("2. Skeleton leftovers (default-template)")
    unchanged = []
    for relp, h in TEMPLATE_HASHES.items():
        p = root / relp
        if p.is_file() and norm_sha(p.read_bytes()) == h:
            unchanged.append(relp)
    for relp in unchanged:
        if relp in TEMPLATE_OK_UNCHANGED:
            rep.add("INFO", "S4", "Identical to the default-template (canonical shape - fine)", relp)
        else:
            rep.add("WARN", "S4", "Identical to the default-template example - skeleton content left unchanged?", relp)
    example_paths = ["environment/app/src/summarize.py", "solution/src/summarize.py", "tests/holdout/h1"]
    for relp in example_paths:
        if (root / relp).exists() and relp not in unchanged:
            rep.add("INFO", "S4", "Path from the skeleton's example task still present (edited) - intended?", relp)
    markers = [(re.compile(r"\bREPLACE\b"), "REPLACE placeholder"),
               (re.compile(r"NOTE \(skeleton\)"), "skeleton note"),
               (re.compile(r"Replace the whole file for a real task"), "skeleton instruction"),
               (re.compile(r"Replace it with whatever your task ships"), "skeleton instruction")]
    hits = 0
    for p in iter_files(root):
        r = rel(root, p)
        if r == "task.toml":
            continue  # handled in section 3
        t = read_text(p)
        if t is None:
            continue
        for rx, label in markers:
            for m in rx.finditer(t):
                hits += 1
                if hits <= 25:
                    rep.add("WARN", "S4", f"{label} left in file: '{short(t.splitlines()[line_no(t, m.start()) - 1], 90)}'",
                            f"{r}:{line_no(t, m.start())}")
    if not unchanged and hits == 0:
        rep.add("PASS", "S4", "No unchanged skeleton files or placeholder markers")


# --------------------------------------------------------------------------- 3 task.toml
def check_toml(root: Path, rep: Report) -> dict:
    rep.section("3. task.toml")
    p = root / "task.toml"
    if not p.is_file():
        rep.add("FAIL", "M1", "task.toml missing")
        return {}
    text = read_text(p) or ""
    if tomllib is None:
        rep.add("WARN", "M1", "Python has no tomllib/tomli - task.toml not parsed; check it by hand")
        return {}
    try:
        data = tomllib.loads(text)
    except Exception as exc:  # noqa: BLE001
        rep.add("FAIL", "M1", f"task.toml does not parse: {exc}")
        return {}
    meta = data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {}
    ver = data.get("verifier", {}) if isinstance(data.get("verifier"), dict) else {}
    agent = data.get("agent", {}) if isinstance(data.get("agent"), dict) else {}
    env = data.get("environment", {}) if isinstance(data.get("environment"), dict) else {}

    def has_placeholder(v) -> bool:
        if isinstance(v, str):
            return bool(re.search(r"\bREPLACE\b", v))
        if isinstance(v, list):
            return any(has_placeholder(x) for x in v)
        return False

    # artifacts
    arts = data.get("artifacts")
    if "artifacts" in ver:
        rep.add("FAIL", "M1", "artifacts is nested under [verifier] - Harbor silently drops it; it must be top-level")
    if arts is None:
        rep.add("FAIL", "M1", "Top-level 'artifacts' missing - the separate verifier receives nothing")
    elif not isinstance(arts, list) or not arts or not all(isinstance(a, str) for a in arts):
        rep.add("FAIL", "M1", f"'artifacts' must be a non-empty list of paths (got {arts!r})")
    else:
        bad = [a for a in arts if not a.startswith("/")]
        if bad:
            rep.add("FAIL", "M1", f"Artifact paths must be absolute: {bad}")
        else:
            rep.add("PASS", "M1", f"artifacts = {arts}")
    # name
    name = data.get("name", meta.get("name"))
    if not name:
        rep.add("FAIL", "M1", "'name' missing (top level or [metadata])")
    elif has_placeholder(name):
        rep.add("FAIL", "M1", f"name is still a placeholder: {name!r}")
    elif not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", str(name)):
        rep.add("WARN", "M1", f"name {name!r} is not kebab-case")
    else:
        rep.add("PASS", "M1", f"name = {name!r}")
    # metadata fields
    for f in META_FIELDS:
        if f not in meta:
            if f in data:
                rep.add("FAIL", "M1", f"'{f}' is at the top level - descriptive fields must be under [metadata] "
                        "(top-level copies are not counted)")
            else:
                rep.add("FAIL", "M1", f"[metadata].{f} missing")
            continue
        v = meta[f]
        if has_placeholder(v):
            rep.add("FAIL", "M1", f"[metadata].{f} still contains REPLACE")
        elif isinstance(v, str) and not v.strip():
            rep.add("FAIL", "M1", f"[metadata].{f} is empty")
    # tags / languages
    tags = meta.get("tags")
    if isinstance(tags, list):
        if not 3 <= len(tags) <= 6:
            rep.add("FAIL", "M1", f"tags must have 3-6 entries (has {len(tags)})")
        if any(str(t).lower() in SKELETON_TAGS for t in tags):
            rep.add("FAIL", "M1", f"tags still hold skeleton values: {tags}")
        elif 3 <= len(tags) <= 6:
            rep.add("PASS", "M4", f"tags = {tags} (judge relevance)")
    elif tags is not None:
        rep.add("FAIL", "M1", "tags must be a list")
    langs = meta.get("languages")
    if isinstance(langs, list) and langs and not has_placeholder(langs):
        odd = [l for l in langs if str(l).lower() not in TARGET_LANGUAGES]
        if odd:
            rep.add("INFO", "M4", f"languages outside the target list {odd} (allowed; list is not restrictive - judge)")
        else:
            rep.add("PASS", "M4", f"languages = {langs}")
    elif langs is not None and not isinstance(langs, list):
        rep.add("FAIL", "M1", "languages must be a list")
    # category / subcategory
    cat, sub = meta.get("category"), meta.get("subcategory")
    if isinstance(cat, str) and not has_placeholder(cat):
        if cat not in TAXONOMY:
            rep.add("FAIL", "M4", f"category {cat!r} is not one of {sorted(TAXONOMY)} (Title Case, exact)")
        else:
            if isinstance(sub, str) and not has_placeholder(sub):
                if sub in TAXONOMY[cat]:
                    rep.add("PASS", "M4", f"category/subcategory = {cat} / {sub} (judge fit: domain, not 'code')")
                else:
                    other = [c for c, subs in TAXONOMY.items() if sub in subs]
                    hint = f" (it belongs to {other[0]})" if other else ""
                    rep.add("WARN", "M4", f"subcategory {sub!r} is not a listed {cat} subcategory{hint}. Taxonomy doc says "
                            "values must match exactly; the skeleton calls the list open - judge")
    # difficulty
    diff = meta.get("difficulty")
    if isinstance(diff, str) and not has_placeholder(diff):
        d = diff.strip()
        if d.lower() in RETIRED_TIERS:
            rep.add("FAIL", "M3", f"difficulty {diff!r} is a retired tier name - must be frontier/advanced/core/base")
        elif d.lower() not in TIERS:
            rep.add("FAIL", "M3", f"difficulty {diff!r} is not a valid tier")
        elif d != d.lower():
            rep.add("WARN", "M3", f"difficulty {diff!r} - docs use lowercase tier names")
        else:
            rep.add("PASS", "M3", f"difficulty = {d!r} (declared-vs-measured mismatch is NOT a finding)")
    # expert time
    eth = meta.get("expert_time_estimate_hours")
    if eth is not None:
        if not isinstance(eth, (int, float)) or isinstance(eth, bool) or eth <= 0:
            rep.add("FAIL", "M1", f"expert_time_estimate_hours must be a positive number (got {eth!r})")
        else:
            rep.add("INFO", "M5", f"expert_time_estimate_hours = {eth} (judge realism)")
    # prose quality leads
    for f in PROSE_FIELDS:
        v = meta.get(f)
        if isinstance(v, str) and v.strip() and not has_placeholder(v):
            n = len(v.split())
            if n < (12 if f == "relevant_experience" else 25):
                rep.add("WARN", "M6", f"[metadata].{f} is thin ({n} words) - reviewers read it first; generic text fails review")
            if f == "difficulty_explanation" and re.search(r"\d+\s*%|pass(?:ing)? rate|gpt|claude|opus|models? (fail|pass)",
                                                           v, re.I):
                rep.add("WARN", "M6", "difficulty_explanation mentions pass rates/models - it should describe the "
                        "human-expert crux, not a measured rate")
    # verifier
    if ver.get("environment_mode") != "separate":
        if isinstance(ver.get("environment"), dict) and "environment_mode" not in ver:
            rep.add("FAIL", "M1", "[verifier.environment] table without explicit environment_mode = \"separate\" - "
                    "Terminus CI requires the explicit key")
        else:
            rep.add("FAIL", "M1", f"[verifier].environment_mode must be \"separate\" (got {ver.get('environment_mode')!r})")
    else:
        rep.add("PASS", "M1", "[verifier].environment_mode = \"separate\"")
    vt = ver.get("timeout_sec")
    if not isinstance(vt, (int, float)) or isinstance(vt, bool) or vt <= 0:
        rep.add("FAIL", "M1", f"[verifier].timeout_sec missing/invalid ({vt!r})")
    elif vt > 18000:
        rep.add("FAIL", "M5", f"[verifier].timeout_sec {vt} exceeds the 18000 s ceiling")
    else:
        rep.add("INFO", "M5", f"[verifier].timeout_sec = {vt}")
    # agent
    at = agent.get("timeout_sec")
    if not isinstance(at, (int, float)) or isinstance(at, bool):
        rep.add("FAIL", "M1", f"[agent].timeout_sec missing/invalid ({at!r})")
    elif at < 1800:
        rep.add("FAIL", "M1", f"[agent].timeout_sec {at} is below the 1800 s minimum")
    elif at > 18000:
        rep.add("FAIL", "M5", f"[agent].timeout_sec {at} exceeds the 18000 s ceiling")
    else:
        rep.add("PASS", "M5", f"[agent].timeout_sec = {at} (most tasks sit around 3600-5400)")
    # network modes
    for phase, tbl in (("environment", env), ("agent", agent), ("verifier", ver)):
        nm = tbl.get("network_mode")
        if nm is None:
            rep.add("FAIL", "E2", f"[{phase}].network_mode missing - an omitted phase silently inherits the baseline")
        elif phase == "environment" and nm != "public":
            rep.add("FAIL", "E2", f"[environment].network_mode must be \"public\" (got {nm!r}) - the build/harness install needs it")
        elif phase != "environment" and nm not in ("public", "no-network"):
            rep.add("FAIL", "E2", f"[{phase}].network_mode must be \"public\" or \"no-network\" (got {nm!r}; 'allowlist' is unsupported)")
        else:
            rep.add("PASS", "E2", f"[{phase}].network_mode = {nm!r}")
    if "network_mode" in data:
        rep.add("FAIL", "E2", "Top-level network_mode is ignored by Harbor - set it per phase")
    for key in ("allowed_hosts", "allow_internet"):
        if key in data or key in env or key in agent or key in ver:
            rep.add("FAIL", "E2", f"'{key}' is rejected - use per-phase network_mode")
    # environment resources
    for f in ("build_timeout_sec", "cpus", "memory_mb", "storage_mb"):
        if f not in env:
            rep.add("FAIL", "M1", f"[environment].{f} missing")
    limits = {"cpus": 2, "memory_mb": 8192, "storage_mb": 10240}
    for f, lim in limits.items():
        v = env.get(f)
        if isinstance(v, (int, float)) and v > lim:
            rep.add("WARN", "M5", f"[environment].{f} = {v} exceeds the stated compute limit (~{lim}); the oracle must run within limits")
    g = env.get("gpus")
    if isinstance(g, (int, float)) and g > 0:
        rep.add("FAIL", "M5", f"gpus = {g} - Terminus 3 tasks must not require a GPU")
    # multi-container
    imc = meta.get("is_multi_container", data.get("is_multi_container"))
    if "is_multi_container" in data and "is_multi_container" not in meta:
        rep.add("WARN", "M2", "is_multi_container is top-level - it belongs under [metadata]")
    compose = find_compose(root)
    if imc is True and not compose:
        rep.add("WARN", "M2", "is_multi_container = true but no environment/docker-compose.yaml found")
    # unknown top-level keys
    known_top = {"name", "artifacts", "metadata", "verifier", "agent", "environment", "version", "solution"}
    unknown = [k for k in data if k not in known_top and k not in META_FIELDS and k not in
               ("network_mode", "allowed_hosts", "allow_internet", "is_multi_container")]
    if unknown:
        rep.add("INFO", "M1", f"Unrecognised top-level keys (Harbor drops them): {unknown}")
    return data


def find_compose(root: Path) -> Path | None:
    for n in ("docker-compose.yaml", "docker-compose.yml", "compose.yaml", "compose.yml"):
        p = root / "environment" / n
        if p.is_file():
            return p
    return None


# --------------------------------------------------------------------------- 4 instruction
ABS_PATH_RE = re.compile(r"(?<![\w.:/~$-])(/[A-Za-z0-9._~+@-]+(?:/[A-Za-z0-9._~+@-]*)*)")
EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F000-\U0001F2FF\U00002B00-\U00002BFF]")
LLM_PHRASES = ["You are an expert", "You are a ", "Your task is to", "Your goal is to", "In this task",
               "Please ensure", "Make sure to", "It is important", "Ensure that", "delve", "seamless",
               "leverage", "meticulous", "utilize", "comprehensive", "robust"]
NOT_PATHS = {"and/or", "i/o", "tcp/ip", "input/output", "read/write", "client/server", "true/false", "yes/no",
             "on/off", "w/o", "n/a", "km/h", "m/s", "req/s", "ops/s", "stdin/stdout", "stdout/stderr", "a/b"}


def instruction_paths(text: str) -> set[str]:
    out = set()
    for m in ABS_PATH_RE.finditer(text):
        s = m.group(1).rstrip(".,;:)")
        if len(s) > 1:
            out.add(s)
    return out


def check_instruction(root: Path, rep: Report, toml: dict) -> str:
    rep.section("4. instruction.md")
    p = root / "instruction.md"
    text = read_text(p) if p.is_file() else None
    if not text or not text.strip():
        rep.add("FAIL", "S1", "instruction.md missing or empty")
        return ""
    lines = text.splitlines()
    words = len(re.findall(r"\S+", text))
    paras = len([b for b in re.split(r"\n\s*\n", text.strip()) if b.strip()])
    bullets = len([l for l in lines if re.match(r"\s*([-*+]|\d+[.)])\s+", l)])
    heads = len([l for l in lines if re.match(r"\s*#{1,6}\s", l)])
    bold = len(re.findall(r"\*\*[^*]+\*\*|__[^_]+__", text))
    rep.add("INFO", "I1", f"{words} words, {paras} paragraph blocks, {bullets} bullets, {heads} headings, {bold} bold spans "
            "(length is guidance, not a cap - flag only step lists/leaked answers)")
    if heads > 2 or bold > 3:
        rep.add("WARN", "I1", "Heavy markdown styling - instructions should read like a human prompt, not structured docs")
    if EMOJI_RE.search(text):
        rep.add("WARN", "I1", "Emoji in instruction.md - prompts should not use emojis")
    for ph in LLM_PHRASES:
        for m in re.finditer(re.escape(ph), text, re.I):
            rep.add("INFO", "I1", f"LLM-style phrase '{ph}' (instruction.md is screened for AI-generated text)",
                    f"instruction.md:{line_no(text, m.start())}")
            break
    # step-by-step leads
    step_lines = [i + 1 for i, l in enumerate(lines) if re.match(r"\s*(step\s*\d+|first,|then,|next,|finally,)", l, re.I)]
    if step_lines:
        rep.add("WARN", "I4", f"Step-by-step wording on lines {step_lines[:8]} - instructions give the what, not the how")
    # relative path candidates
    cands = []
    for i, l in enumerate(lines, 1):
        for span in re.findall(r"`([^`]+)`", l):
            for tok in span.split():
                t = tok.strip("'\",.;:()[]{}")
                if "/" in t and not t.startswith(("/", "http", "~", "$", "<", "-", "{")) and "://" not in t \
                        and t.lower() not in NOT_PATHS and not re.fullmatch(r"\d+/\d+", t):
                    cands.append((i, t))
        plain = re.sub(r"`[^`]*`", " ", l)
        for m in re.finditer(r"(?<![\w/.:~$@-])((?:\.\.?/)?[A-Za-z0-9_-]+(?:/[A-Za-z0-9_.-]+)+)", plain):
            t = m.group(1)
            if t.lower() in NOT_PATHS:
                continue
            if t.startswith(("./", "../")) or re.search(r"\.[A-Za-z0-9]{1,6}$", t):
                cands.append((i, t))
        for m in re.finditer(r"(?<![\w])~/[\w./-]+", l):
            cands.append((i, m.group(0)))
    if cands:
        for i, t in cands[:15]:
            rep.add("WARN", "I8", f"Possible relative path '{t}' - instructions must use absolute paths", f"instruction.md:{i}")
    else:
        rep.add("PASS", "I8", "No relative-path candidates found")
    # task name
    name = toml.get("name") or (toml.get("metadata") or {}).get("name")
    if isinstance(name, str) and name and "REPLACE" not in name:
        variants = {name.lower(), name.lower().replace("-", " "), name.lower().replace("-", "_")}
        low = text.lower()
        found = [v for v in variants if len(v) > 3 and v in low]
        if found:
            rep.add("FAIL", "I9", f"Task name appears in instruction.md ({found[0]!r}) (Medium)")
        else:
            rep.add("PASS", "I9", "Task name not in instruction.md")
    # canary / placeholders / urls / tools
    if re.search(r"canary", text, re.I):
        rep.add("FAIL", "I10", "Canary string in instruction.md")
    for m in re.finditer(r"https?://\S+", text):
        rep.add("INFO", "I2", f"External URL '{short(m.group(0), 60)}' - must not be needed at runtime or change over time",
                f"instruction.md:{line_no(text, m.start())}")
    for m in re.finditer(r"\b(vim|nano|emacs|vscode)\b", text, re.I):
        rep.add("INFO", "I11", f"Names a tool ('{m.group(1)}') - only OK if its use can be verified",
                f"instruction.md:{line_no(text, m.start())}")
        break
    return text


# --------------------------------------------------------------------------- 5 dockerfiles
HEREDOC_RE = re.compile(r"<<-?\s*(['\"]?)([A-Za-z_][A-Za-z0-9_]*)\1")


@dataclass
class Instr:
    line: int
    kw: str
    args: str
    heredoc: bool
    body: str


def parse_dockerfile(text: str) -> tuple[list[Instr], list[tuple[int, str]]]:
    lines = text.splitlines()
    instrs: list[Instr] = []
    comments: list[tuple[int, str]] = []
    i, n = 0, len(lines)
    while i < n:
        s = lines[i].strip()
        if not s:
            i += 1
            continue
        if s.startswith("#"):
            comments.append((i + 1, s))
            i += 1
            continue
        start = i
        parts = []
        cur = lines[i]
        while True:
            c = cur.rstrip()
            if c.endswith("\\"):
                parts.append(c[:-1])
                i += 1
                while i < n and (lines[i].strip().startswith("#") or not lines[i].strip()):
                    if lines[i].strip().startswith("#"):
                        comments.append((i + 1, lines[i].strip()))
                    i += 1
                if i >= n:
                    break
                cur = lines[i]
                continue
            parts.append(c)
            break
        joined = " ".join(x.strip() for x in parts)
        body_lines = []
        markers = HEREDOC_RE.findall(joined) if not joined.upper().startswith(("FROM", "ARG", "ENV", "LABEL")) else []
        for _q, marker in markers:
            i += 1
            while i < n and lines[i].strip() != marker:
                body_lines.append(lines[i])
                i += 1
        kw, _, args = joined.strip().partition(" ")
        instrs.append(Instr(start + 1, kw.upper(), args.strip(), bool(markers), "\n".join(body_lines)))
        i += 1
    return instrs, comments


def parse_image(ref: str) -> dict:
    digest = None
    nod = ref
    if "@" in ref:
        nod, digest = ref.split("@", 1)
    name, tag = nod, None
    if ":" in nod.rsplit("/", 1)[-1]:
        name, tag = nod.rsplit(":", 1)
    return {"ref": ref, "name": name, "tag": tag, "digest": digest, "base": name.rsplit("/", 1)[-1].lower()}


def shell_segments(cmd: str) -> list[str]:
    out = []
    for piece in re.split(r"\n|&&|\|\||;|(?<!\|)\|(?!\|)", cmd):
        piece = piece.strip()
        if piece:
            out.append(piece)
    return out


def strip_prefix_tokens(toks: list[str]) -> list[str]:
    i = 0
    while i < len(toks) and (re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", toks[i]) or
                             toks[i] in ("sudo", "env", "time", "exec", "command", "nohup", "(", "{")):
        i += 1
    return toks[i:]


PIP_OPTS_WITH_VALUE = {"-r", "--requirement", "-c", "--constraint", "-i", "--index-url", "--extra-index-url",
                       "-f", "--find-links", "-t", "--target", "--prefix", "--root", "--src", "--upgrade-strategy",
                       "--python-version", "--platform", "--implementation", "--abi", "--only-binary", "--no-binary",
                       "--progress-bar", "--trusted-host", "--cache-dir", "--log", "--proxy", "--retries",
                       "--timeout", "--exists-action", "--global-option", "--install-option", "--config-settings",
                       "-C", "--python", "-p", "--report", "--root-user-action", "--index-strategy",
                       "--python-platform", "--prerelease", "--resolution", "--extra", "-e", "--editable",
                       "--index", "--default-index", "--keyring-provider"}


def pip_spec_status(tok: str) -> str:
    t = tok.strip()
    if t in (".", "..") or t.startswith(("./", "../", "/")) or t.endswith((".whl", ".tar.gz", ".zip", ".tgz")):
        return "local"
    if re.match(r"^(git\+|hg\+|svn\+|bzr\+|https?://)", t):
        return "pinned" if re.search(r"@[0-9a-f]{7,40}\b", t) else "url"
    if "$" in t:
        return "var"
    base = t.split(";")[0].strip()
    if re.fullmatch(r"[A-Za-z0-9._-]+(\[[^\]]*\])?\s*===?\s*[A-Za-z0-9.+!_-]+", base) and "*" not in base:
        return "pinned"
    return "unpinned"


def pip_install_args(toks: list[str]) -> list[str] | None:
    """Return the argument tokens after 'install' if this is a pip-style install, else None."""
    for idx, t in enumerate(toks):
        is_pip = bool(re.search(r"(^|/)pip[0-9.]*$", t))
        if t == "-m" and idx + 1 < len(toks) and toks[idx + 1] == "pip":
            is_pip = True
            idx += 1
        if t == "uv" and idx + 1 < len(toks) and toks[idx + 1] == "pip":
            is_pip = True
            idx += 1
        if is_pip:
            rest = toks[idx + 1:]
            if "install" in rest:
                return rest[rest.index("install") + 1:]
            return None
    return None


def check_requirements_file(ctx: Path, fname: str, root: Path, rep: Report, where: str) -> None:
    cands = [ctx / fname.lstrip("/")] + list(ctx.rglob(Path(fname).name))
    f = next((c for c in cands if c.is_file()), None)
    if f is None:
        rep.add("INFO", "E3", f"Could not find requirements file '{fname}' in the build context to verify pins", where)
        return
    t = read_text(f) or ""
    bad = []
    for i, l in enumerate(t.splitlines(), 1):
        s = l.split("#")[0].strip()
        if not s or s.startswith("-") or s.startswith("--hash"):
            continue
        s = s.split("\\")[0].strip()
        if pip_spec_status(s.split()[0]) == "unpinned":
            bad.append(f"{s} (line {i})")
    if bad:
        rep.add("FAIL", "E3", f"Unpinned entries in {rel(root, f)}: {bad[:6]}", where)
    else:
        rep.add("PASS", "E3", f"{rel(root, f)} entries are pinned", where)


def check_dockerfile(root: Path, df: Path, rep: Report, *, is_env: bool, notes: dict) -> None:
    text = read_text(df) or ""
    r = rel(root, df)
    ctx = df.parent
    instrs, comments = parse_dockerfile(text)
    if not instrs:
        rep.add("FAIL", "E15", "Dockerfile is empty or unparsable", r)
        return
    args_before_from = {}
    stages: list[dict] = []
    for ins in instrs:
        if ins.kw == "ARG" and not stages:
            k, _, v = ins.args.partition("=")
            args_before_from[k.strip()] = v.strip().strip("\"'")
        if ins.kw == "FROM":
            a = ins.args
            plat = re.search(r"--platform=(\S+)", a)
            if plat:
                rep.add("FAIL", "E9", f"FROM pins a platform ({plat.group(0)}) - CI blocks platform pinning", f"{r}:{ins.line}")
                a = a.replace(plat.group(0), "").strip()
            m = re.match(r"(\S+)(?:\s+AS\s+(\S+))?", a, re.I)
            ref = m.group(1) if m else a
            alias = m.group(2) if m else None
            for k, v in args_before_from.items():
                ref = ref.replace("${" + k + "}", v).replace("$" + k, v)
            names = {s["alias"].lower() for s in stages if s["alias"]}
            st = {"alias": alias, "ref": ref, "line": ins.line, "instrs": [], "parent": None}
            if ref.lower() in names:
                st["parent"] = ref.lower()
            elif ref == "scratch":
                pass
            elif "$" in ref:
                rep.add("WARN", "E9", f"FROM uses an unresolved variable ({ref}) - cannot verify the digest pin", f"{r}:{ins.line}")
            else:
                img = parse_image(ref)
                if not img["digest"] or not re.fullmatch(r"sha256:[0-9a-f]{64}", img["digest"]):
                    rep.add("FAIL", "E9", f"FROM {ref} is not digest-pinned (@sha256:<64 hex>)", f"{r}:{ins.line}")
                else:
                    rep.add("PASS", "E9", f"FROM {short(ref, 80)} is digest-pinned", f"{r}:{ins.line}")
            stages.append(st)
            continue
        if stages:
            stages[-1]["instrs"].append(ins)
    if not stages:
        rep.add("FAIL", "E15", "No FROM instruction", r)
        return
    stage_names = {s["alias"].lower() for s in stages if s["alias"]}

    # final stage base (follow aliases)
    def root_ref(st: dict) -> str:
        seen = 0
        while st["parent"] and seen < 20:
            parent = next((s for s in stages if s["alias"] and s["alias"].lower() == st["parent"]), None)
            if not parent:
                break
            st = parent
            seen += 1
        return st["ref"]

    final = stages[-1]
    fref = root_ref(final)
    img = parse_image(fref) if fref != "scratch" and "$" not in fref else None
    if img:
        dig = (img["digest"] or "").replace("sha256:", "")
        just = [c for (ln, c) in comments if final["line"] - 8 <= ln < final["line"] + 2 and len(c) > 12]
        if not just:
            just = [c for (_, c) in comments if re.search(r"canonical|justif|because|requires|need", c, re.I)]
        if dig in CANONICAL_IMAGES:
            rep.add("PASS", "E10", f"Final base is canonical: {CANONICAL_IMAGES[dig]}", f"{r}:{final['line']}")
            if not img["name"].startswith("public.ecr.aws/docker/library/"):
                rep.add("INFO", "E10", "Canonical digest but a different registry prefix than the canonical list", f"{r}:{final['line']}")
        elif just:
            lvl = "WARN"
            fam = " (same family as a canonical image, but not the canonical pinned reference)" if img["base"] in CANONICAL_FAMILIES else ""
            rep.add(lvl, "E10", f"Non-canonical final base {short(fref, 70)}{fam}. Judge whether this justification is credible: "
                    f"{short(' | '.join(just), 160)!r}", f"{r}:{final['line']}")
        else:
            rep.add("FAIL", "E10", f"Non-canonical final base {short(fref, 70)} with no justification comment", f"{r}:{final['line']}")

    # walk instructions
    env_has_workdir = False
    apt_update_count: dict[int, int] = {}
    run_texts_by_stage: dict[int, list[str]] = {}
    for si, st in enumerate(stages):
        for ins in st["instrs"]:
            where = f"{r}:{ins.line}"
            full = ins.args + ("\n" + ins.body if ins.body else "")
            if ins.heredoc:
                rep.add("WARN", "E14", "Heredoc in Dockerfile (Low) - store files as files and COPY them", where)
            if ins.kw == "WORKDIR":
                env_has_workdir = env_has_workdir or si == len(stages) - 1
            if is_env and ins.kw in ("RUN", "COPY", "ADD", "VOLUME", "WORKDIR"):
                mres = RESERVED_RE.search(full)
                if mres:
                    rep.add("FAIL", "E7", f"Agent image touches Harbor-reserved path {mres.group(1)}: {short(full, 90)}", where)
            if ins.kw in ("COPY", "ADD"):
                toks = safe_split(ins.args)
                if ins.args.strip().startswith("["):
                    try:
                        toks = json.loads(ins.args)
                    except Exception:  # noqa: BLE001
                        pass
                flags = [t for t in toks if t.startswith("--")]
                paths = [t for t in toks if not t.startswith("--")]
                for fl in flags:
                    if fl.startswith("--chown="):
                        v = fl.split("=", 1)[1]
                        if "$" in v:
                            rep.add("WARN", "E16", f"COPY {fl} uses a variable - the cloud builder needs numeric IDs", where)
                        elif not re.fullmatch(r"\d+(:\d+)?", v):
                            rep.add("FAIL", "E16", f"COPY {fl} uses a named user - cloud builder needs numeric IDs (e.g. 0:0)", where)
                    if fl.startswith("--from="):
                        v = fl.split("=", 1)[1]
                        if v.lower() in stage_names or v.isdigit():
                            continue
                        if "@sha256:" in v:
                            if ":" in v.split("@", 1)[0].rsplit("/", 1)[-1]:
                                rep.add("FAIL", "E16", f"COPY {fl} mixes tag and digest - cloud builder needs digest-only refs", where)
                        else:
                            rep.add("FAIL", "E9", f"COPY {fl} pulls an image that is not digest-pinned", where)
                srcs, dest = (paths[:-1], paths[-1]) if len(paths) >= 2 else (paths, "")
                if ins.kw == "ADD" and any(s.startswith(("http://", "https://")) for s in srcs):
                    rep.add("WARN", "E1", f"ADD downloads from the web: {short(ins.args, 90)}", where)
                for s in srcs:
                    if s.startswith("../") or "/../" in s:
                        rep.add("FAIL", "E4", f"COPY source reaches outside the build context: {s}", where)
                    if ins.kw == "ADD" and s.endswith(ARCHIVE_EXT):
                        rep.add("INFO", "E14", f"ADD of an archive ({s}) - auto-extracts; confirm contents are reviewable", where)
                if is_env and srcs in (["."], ["./"]):
                    notes["env_copy_dot"] = where
                if not is_env:
                    notes.setdefault("tests_copy_dests", []).append((dest, srcs, ins.line))
            if ins.kw == "RUN":
                run_texts_by_stage.setdefault(si, []).append(full)
                if not is_env:
                    notes.setdefault("tests_run_texts", []).append(full)
                if re.search(r"\bnproc\b", full):
                    rep.add("WARN", "E15", "Uses nproc - reports the HOST cpu count in containers (CI flags bare nproc)", where)
                if re.search(r"(curl|wget)[^|\n]*\|\s*(ba|z)?sh\b", full) or "bash <(curl" in full:
                    rep.add("WARN", "E1", "Pipe-to-shell bootstrap - must be version-pinned and checksum-verified", where)
                for m in re.finditer(r"\b(curl|wget)\b[^\n&;|]*?(https?://\S+)", full):
                    verified = bool(re.search(r"sha256sum\s+(-c|--check)|sha512sum\s+(-c|--check)|gpg --verify", full))
                    rep.add("WARN" if not verified else "INFO", "E1",
                            f"Downloads {short(m.group(2), 70)} at build time ({'checksum verified' if verified else 'no checksum check seen'}). "
                            "Only package installs are allowed - confirm this is a pinned tool, not task content", where)
                for m in re.finditer(r"git\s+clone\b[^\n&;]*", full):
                    pinned = bool(re.search(r"git\s+(checkout|reset\s+--hard)\s+[0-9a-f]{7,40}\b", full))
                    rep.add("INFO" if pinned else "WARN", "E1",
                            f"git clone ({'pinned to a commit' if pinned else 'NOT pinned to a commit - newer commits may leak answers'}): "
                            f"{short(m.group(0), 80)}", where)
                for seg in shell_segments(full):
                    toks = strip_prefix_tokens(safe_split(seg))
                    if not toks:
                        continue
                    cmd = toks[0].rsplit("/", 1)[-1]
                    # apt
                    if cmd in ("apt-get", "apt", "aptitude"):
                        sub = next((t for t in toks[1:] if not t.startswith("-")), "")
                        if sub == "update":
                            apt_update_count[si] = apt_update_count.get(si, 0) + 1
                        if sub in ("upgrade", "dist-upgrade", "full-upgrade"):
                            rep.add("WARN", "E12", f"apt {sub} - avoid upgrades (Medium)", where)
                        if sub == "install":
                            pkgs = [t for t in toks[toks.index("install") + 1:] if not t.startswith("-")]
                            pinned = [t for t in pkgs if "=" in t]
                            if pinned:
                                rep.add("FAIL", "E12", f"Pinned apt packages {pinned[:5]} - CI blocks apt version pins", where)
                            if "--no-install-recommends" not in toks:
                                rep.add("WARN", "E12", "apt install without --no-install-recommends (Medium)", where)
                            if not re.search(r"rm\s+-rf\s+/var/lib/apt/lists", full):
                                rep.add("WARN", "E12", "apt lists not removed in the same RUN (rm -rf /var/lib/apt/lists/*)", where)
                            notes.setdefault("apt_pkgs", {}).setdefault(si, []).extend(pkgs)
                    # pip / uv
                    pargs = pip_install_args(toks)
                    if pargs is not None:
                        skip = False
                        unpinned = []
                        for k, t in enumerate(pargs):
                            if skip:
                                skip = False
                                continue
                            if t in ("-r", "--requirement", "-c", "--constraint"):
                                if k + 1 < len(pargs):
                                    check_requirements_file(ctx, pargs[k + 1], root, rep, where)
                                skip = True
                                continue
                            if t.startswith("--requirement=") or t.startswith("-r="):
                                check_requirements_file(ctx, t.split("=", 1)[1], root, rep, where)
                                continue
                            if t in PIP_OPTS_WITH_VALUE:
                                skip = True
                                continue
                            if t.startswith("-"):
                                continue
                            stt = pip_spec_status(t)
                            if stt in ("unpinned", "url"):
                                unpinned.append(t)
                            elif stt == "var":
                                rep.add("WARN", "E3", f"pip spec uses a variable ({t}) - cannot verify the pin", where)
                            if not is_env and re.match(r"pytest(==|$)", t):
                                notes["pytest_pinned"] = stt == "pinned"
                            if not is_env and re.match(r"pytest-json-ctrf", t):
                                notes["ctrf_pinned"] = stt == "pinned"
                        if unpinned:
                            rep.add("FAIL", "E3", f"Unpinned pip installs {unpinned[:6]} - every pip install must pin with ==", where)
                        elif pargs:
                            rep.add("PASS", "E3", "pip install specs pinned", where)
                    if cmd == "uvx" or (cmd == "uv" and len(toks) > 1 and toks[1] == "tool"):
                        withs = [toks[k + 1] for k, t in enumerate(toks[:-1]) if t == "--with"]
                        bad = [w for w in withs if pip_spec_status(w) != "pinned"]
                        if bad:
                            rep.add("FAIL", "E3", f"uvx --with unpinned: {bad}", where)
                    # npm / yarn / pnpm
                    if cmd in ("npm", "yarn", "pnpm") and len(toks) > 1:
                        sub = toks[1]
                        if sub in ("install", "i", "add"):
                            pk = [t for t in toks[2:] if not t.startswith("-")]
                            if not pk:
                                locks = [x for x in ("package-lock.json", "npm-shrinkwrap.json", "yarn.lock", "pnpm-lock.yaml")
                                         if list(ctx.rglob(x))]
                                if not locks:
                                    rep.add("WARN", "E3", f"{cmd} {sub} without a lockfile in the context - versions float", where)
                            else:
                                bad = [t for t in pk if not re.fullmatch(r"(@[\w.-]+/)?[\w.-]+@\d+\.\d+\.\d+([-+][\w.]+)?", t)
                                       and not t.startswith((".", "/", "file:"))]
                                if bad:
                                    rep.add("FAIL", "E3", f"{cmd} packages not pinned to an exact version: {bad[:6]}", where)
                    if cmd == "go" and len(toks) > 2 and toks[1] in ("install", "get"):
                        for t in toks[2:]:
                            if t.startswith("-"):
                                continue
                            if "@" not in t or t.endswith("@latest"):
                                rep.add("FAIL", "E3", f"go {toks[1]} {t} is not pinned to a version", where)
                    if cmd == "cargo" and len(toks) > 1 and toks[1] == "install":
                        if not ("--version" in toks or any("@" in t for t in toks[2:]) or "--path" in toks or "--locked" in toks):
                            rep.add("WARN", "E3", "cargo install without --version/@version", where)
                    if cmd == "gem" and len(toks) > 1 and toks[1] == "install":
                        if not ("-v" in toks or "--version" in toks or any(re.search(r":\d", t) for t in toks)):
                            rep.add("WARN", "E3", "gem install without -v <version>", where)
        # per-stage apt hygiene
        if apt_update_count.get(si, 0) > 1:
            rep.add("WARN", "E12", f"Stage {si + 1} runs apt-get update {apt_update_count[si]} times - use one apt transaction per stage",
                    f"{r}:{st['line']}")
    if is_env:
        # tmux / asciinema must be in the FINAL agent image (follow stage parents)
        chain = []
        st = final
        while st is not None and len(chain) < 20:
            chain.append(st)
            st = next((s for s in stages if s["alias"] and st["parent"] and s["alias"].lower() == st["parent"]), None)
        txt = "\n".join(t for s in chain for t in run_texts_by_stage.get(stages.index(s), []))
        missing = [t for t in ("tmux", "asciinema") if not re.search(rf"\b{t}\b", txt)]
        if missing:
            rep.add("FAIL", "E15", f"Final agent image does not install {missing} - the agent runtime needs both "
                    "(every trial fails with 'Failed to start tmux session' if absent, unless the base image ships them)", r)
        else:
            rep.add("PASS", "E15", "tmux and asciinema installed in the final agent image", r)
        if not env_has_workdir:
            rep.add("INFO", "E15", "No WORKDIR in the final stage (Agent Review warns on this)", r)


def check_dockerfiles(root: Path, rep: Report, notes: dict) -> None:
    rep.section("5. Dockerfiles")
    found = False
    for base, is_env in ((root / "environment", True), (root / "tests", False)):
        for df in sorted(base.rglob("*")) if base.exists() else []:
            if df.is_file() and (df.name == "Dockerfile" or df.name.startswith("Dockerfile.") or df.name.endswith(".Dockerfile")):
                found = True
                check_dockerfile(root, df, rep, is_env=is_env, notes=notes)
    if not found:
        rep.add("FAIL", "S1", "No Dockerfiles found under environment/ or tests/")


# --------------------------------------------------------------------------- 6 compose
def check_compose(root: Path, rep: Report, toml: dict) -> None:
    rep.section("6. docker-compose (multi-container)")
    p = find_compose(root)
    meta = toml.get("metadata", {}) if isinstance(toml.get("metadata"), dict) else {}
    if not p:
        rep.add("PASS", "M2", "No compose file - single-container task (is_multi_container not needed)")
        return
    r = rel(root, p)
    text = read_text(p) or ""
    services = {}
    if yaml is not None:
        try:
            doc = yaml.safe_load(text) or {}
            services = doc.get("services", {}) or {}
        except Exception as exc:  # noqa: BLE001
            rep.add("WARN", "E15", f"Compose file does not parse as YAML: {exc}", r)
    else:
        rep.add("INFO", "E6", "PyYAML unavailable - compose checked with regexes only", r)
        services = {m.group(1): {} for m in re.finditer(r"^  ([A-Za-z0-9_.-]+):\s*$", text, re.M)}
    n = len(services)
    if n > 1 and meta.get("is_multi_container") is not True:
        rep.add("FAIL", "M2", f"{n} services in compose but [metadata].is_multi_container is not true", r)
    elif n > 1:
        rep.add("PASS", "M2", f"{n} services; is_multi_container = true", r)
    for m in re.finditer(r"privileged:\s*true", text):
        rep.add("FAIL", "E6", "privileged: true", f"{r}:{line_no(text, m.start())}")
    for m in re.finditer(r"SYS_ADMIN|NET_ADMIN|SYS_MODULE|cap_add:\s*\n\s*-\s*ALL", text):
        rep.add("FAIL", "E6", f"Dangerous capability {m.group(0).split()[0]}", f"{r}:{line_no(text, m.start())}")
    for m in re.finditer(r"docker\.sock", text):
        rep.add("FAIL", "E6", "Mounts the Docker socket", f"{r}:{line_no(text, m.start())}")
    for m in re.finditer(r"(network_mode|pid|ipc):\s*[\"']?host", text):
        rep.add("WARN", "E6", f"{m.group(0)} - host namespaces break sandboxing", f"{r}:{line_no(text, m.start())}")
    for m in re.finditer(r"context:\s*[\"']?\.\.", text):
        rep.add("FAIL", "E4", "Compose build context points outside environment/", f"{r}:{line_no(text, m.start())}")
    for m in re.finditer(r"^\s*image:\s*[\"']?(\S+?)[\"']?\s*$", text, re.M):
        if "@sha256:" not in m.group(1):
            rep.add("FAIL", "E9", f"Compose image {m.group(1)} is not digest-pinned", f"{r}:{line_no(text, m.start())}")
    for m in re.finditer(r"^\s*-\s*[\"']?([^\s\"']+):(/[^\s\"':]*)", text, re.M):
        src, dst = m.group(1), m.group(2)
        if src.startswith((".", "/", "~")):
            rep.add("FAIL", "E7", f"Host bind mount {src}:{dst} - CI forbids host bind mounts in compose", f"{r}:{line_no(text, m.start())}")
        if RESERVED_RE.search(dst):
            rep.add("FAIL", "E7", f"Mount targets Harbor-reserved path {dst}", f"{r}:{line_no(text, m.start())}")


# --------------------------------------------------------------------------- 7 environment tree
HINT_PATTERNS = [
    (r"\b(TODO|FIXME|XXX|HACK)\b", "TODO/FIXME marker"),
    (r"\bhint\b", "'hint'"),
    (r"\bthe (bug|defect|problem|issue) (is|was|lies)\b", "names the bug"),
    (r"\b(solution|answer|expected[ _-]?(output|result|answer))\b", "solution/answer/expected wording"),
    (r"\bstep \d\b", "step-by-step wording"),
]


def check_env_tree(root: Path, rep: Report, notes: dict) -> None:
    rep.section("7. environment/ contents")
    env = root / "environment"
    if not env.is_dir():
        rep.add("FAIL", "S1", "environment/ missing")
        return
    files = list(iter_files(env))
    total = sum(p.stat().st_size for p in files)
    big = sorted(files, key=lambda p: p.stat().st_size, reverse=True)[:3]
    rep.add("INFO", "E11", f"{len(files)} files, {total / 2**20:.2f} MiB total; largest: " +
            ", ".join(f"{rel(root, p)} ({p.stat().st_size / 2**20:.2f} MiB)" for p in big))
    if total > 100 * 2**20:
        rep.add("FAIL", "E11", f"environment/ is {total / 2**20:.1f} MiB (> 100 MiB)")
    for p in files:
        if p.stat().st_size > 50 * 2**20:
            rep.add("FAIL", "E11", f"File over 50 MiB: {p.stat().st_size / 2**20:.1f} MiB", rel(root, p))
    nontrivial = len(files) > 4 or any(d.is_dir() for d in env.iterdir())
    if not (env / ".dockerignore").exists():
        if nontrivial:
            rep.add("WARN", "E13", "No environment/.dockerignore in a non-trivial environment (Low)")
    else:
        rep.add("PASS", "E13", ".dockerignore present")
    if notes.get("env_copy_dot") and not (env / ".dockerignore").exists():
        rep.add("WARN", "E13", "COPY . with no .dockerignore - may bake clutter/secrets into the image", notes["env_copy_dot"])
    # files identical to solution/ or tests/ content -> answers in the agent image
    ref_hashes = {}
    for base in ("solution", "tests"):
        for p in iter_files(root / base):
            if p.name in ("Dockerfile", "test.sh", "__init__.py", ".dockerignore") or p.stat().st_size < 16:
                continue
            ref_hashes.setdefault(norm_sha(p.read_bytes()), rel(root, p))
    dup = 0
    for p in files:
        if p.stat().st_size < 16:
            continue
        h = norm_sha(p.read_bytes())
        if h in ref_hashes:
            dup += 1
            rep.add("FAIL", "E5", f"Identical to {ref_hashes[h]} - solution/verifier content is visible to the agent", rel(root, p))
    if not dup:
        rep.add("PASS", "E5", "No environment file is a copy of a solution/ or tests/ file")
    for p in files:
        r = rel(root, p)
        low = p.name.lower()
        if re.search(r"(expected|golden|answer|solution|oracle)", low):
            rep.add("WARN", "E5", "Filename suggests ground truth/solution inside the agent image - check it", r)
        if low.endswith(ARCHIVE_EXT):
            rep.add("INFO", "E14", "Opaque archive in the build context - confirm it is extracted at build and hides no answers", r)
        if low in (".env",) or low.endswith((".pem", ".key")) or low in ("id_rsa", "id_ed25519", "credentials"):
            rep.add("WARN", "E15", "Secret-like file in the image (hygiene)", r)
        data = p.read_bytes()[:4]
        if data.startswith((b"\x7fELF", b"MZ", b"\xcf\xfa\xed\xfe", b"\xca\xfe\xba\xbe")) or low.endswith((".pyc", ".so", ".exe", ".dll")):
            rep.add("INFO", "E5", "Binary/compiled file - make sure it hides no answers (and isn't stray build output)", r)
    for d in env.rglob(".git"):
        rep.add("WARN", "E5", "A .git directory in the build context - history can leak answers; also image hygiene", rel(root, d))
    # hidden hints (leads only)
    shown = 0
    for p in files:
        if p.name in (".dockerignore",) or p.name == "Dockerfile" or p.name.startswith("Dockerfile.") or \
                p.name in ("docker-compose.yaml", "docker-compose.yml", "compose.yaml", "compose.yml"):
            continue  # build files are not visible to the agent unless copied in
        t = read_text(p)
        if t is None or p.suffix.lower() in (".csv", ".tsv", ".json", ".jsonl", ".txt") and p.stat().st_size > 200_000:
            continue
        for rx, label in HINT_PATTERNS:
            for m in re.finditer(rx, t, re.I):
                shown += 1
                if shown <= 20:
                    ln = line_no(t, m.start())
                    rep.add("INFO", "I5", f"{label}: '{short(t.splitlines()[ln - 1], 90)}' - hint or walkthrough?", f"{rel(root, p)}:{ln}")
    if shown > 20:
        rep.add("INFO", "I5", f"...{shown - 20} more hint-pattern hits not shown")
    docs = [p for p in files if p.suffix.lower() in (".md", ".rst", ".txt") and p.stat().st_size < 200_000
            and re.search(r"(readme|spec|design|architecture|notes|guide|doc)", p.name, re.I)]
    for p in docs:
        rep.add("INFO", "I6", "Spec/doc file in the environment - must define WHAT (contract), not HOW; no offloaded instructions",
                rel(root, p))


# --------------------------------------------------------------------------- 8 test.sh
def check_test_sh(root: Path, rep: Report, notes: dict) -> None:
    rep.section("8. tests/test.sh")
    p = root / "tests" / "test.sh"
    t = read_text(p) if p.is_file() else None
    if t is None:
        rep.add("FAIL", "S1", "tests/test.sh missing")
        return
    r = "tests/test.sh"
    lines = t.splitlines()
    if not lines or not lines[0].startswith("#!"):
        rep.add("WARN", "V1", "No shebang line", r)
    code = [(i + 1, l) for i, l in enumerate(lines) if l.strip() and not l.strip().startswith("#")]
    for i, l in code:
        m = re.match(r"\s*set\s+(-o\s+errexit|-[A-Za-z]+)", l)
        if m and ("errexit" in m.group(1) or "e" in m.group(1).lstrip("-")):
            rep.add("FAIL", "V1", f"'{l.strip()}' - no set -e in test.sh: a failing pytest must still reach the reward write", f"{r}:{i}")
    body = "\n".join(l for _, l in code)
    if not re.search(r"(-m\s+pytest|\bpytest\b|py\.test)", body):
        rep.add("FAIL", "V14", "test.sh does not run pytest - verifiers must be Python pytest", r)
    for fw in (r"\bjest\b", r"\bgo\s+test\b", r"\bcargo\s+test\b", r"\bmvn\s+test\b", r"\bjunit\b", r"\bnpm\s+test\b", r"\bmocha\b"):
        mm = re.search(fw, body)
        if mm:
            rep.add("FAIL", "V14", f"Runs another test framework ({mm.group(0)}) - drive it from Python pytest instead", r)
    if "--ctrf" not in body or "/logs/verifier/ctrf.json" not in body:
        rep.add("FAIL", "V14", "pytest must run with --ctrf /logs/verifier/ctrf.json (CI ctrf_reporting)", r)
    else:
        rep.add("PASS", "V14", "--ctrf /logs/verifier/ctrf.json present", r)
    w1 = re.search(r"(echo|printf)\s+[\"']?1[\"']?\s*>\s*[\"']?/logs/verifier/reward\.txt", body)
    w0 = re.search(r"(echo|printf)\s+[\"']?0[\"']?\s*>\s*[\"']?/logs/verifier/reward\.txt", body)
    if w1 and w0:
        rep.add("PASS", "V1", "Writes 1 and 0 to /logs/verifier/reward.txt", r)
    else:
        rep.add("FAIL", "V1", "Does not write both 1 (pass) and 0 (fail) to /logs/verifier/reward.txt", r)
    for i, l in code:
        if re.search(r"reward\.(txt|json)", l) and not re.search(r"(echo|printf)\s+[\"']?[01][\"']?\s*>", l) \
                and re.search(r">|tee|write", l):
            rep.add("FAIL", "V4", f"Non-binary reward write? '{short(l)}' - reward must be exactly 0 or 1", f"{r}:{i}")
    for i, l in code:
        if NET_CMD_RE.search(l):
            rep.add("FAIL", "V3", f"Network/install at grade time: '{short(l)}' - bake verifier deps into tests/Dockerfile", f"{r}:{i}")
    if re.search(r"/oracle|/solution|ORACLE|IS_ORACLE", body):
        rep.add("FAIL", "V2", "test.sh references oracle/solution - grading must be identical for oracle and agent", r)
    # exits
    last_fi = max((i for i, l in code if re.match(r"\s*fi\b", l)), default=0)
    first_reward = min((i for i, l in code if "reward.txt" in l), default=10 ** 9)
    for i, l in code:
        m = re.match(r"\s*exit\b\s*(\S*)", l)
        if not m:
            continue
        arg = m.group(1)
        if i > last_fi and last_fi:
            if arg in ("", "0"):
                rep.add("INFO", "V1", f"Trailing '{l.strip()}' after the reward block - NOT a finding by itself "
                        "(the skeleton ends on 'fi'; an exit 0 can only mask a failed reward write)", f"{r}:{i}")
            else:
                rep.add("FAIL", "V1", f"Trailing '{l.strip()}' propagates the test status - check_test_sh rejects this; end on 'fi'", f"{r}:{i}")
        elif i < first_reward:
            rep.add("WARN", "V1", f"'{l.strip()}' before any reward write - make sure every path writes reward.txt first", f"{r}:{i}")
    if re.search(r"\$\{?TEST_DIR\b(?!:-)", body) and not re.search(r"TEST_DIR=\"?\$\{TEST_DIR:-", body):
        rep.add("WARN", "V14", "$TEST_DIR used without a default (use ${TEST_DIR:-/tests})", r)
    if re.search(r"\bnproc\b", body):
        rep.add("WARN", "E15", "Uses nproc (host CPU count inside containers)", r)
    if re.search(r"(/usr)?/bin/bash", body) and re.search(r"chmod", body):
        rep.add("WARN", "V14", "Changes interpreter permissions - see the verifier_interpreter_permissions preflight", r)
    mt = re.search(r"(\S+)\s+-m\s+pytest|(\S*pytest)\s", body)
    if mt:
        notes["pytest_interp"] = mt.group(1) or mt.group(2)
    tgt = re.findall(r"(\S+/test[^\s/]*\.py)", body)
    notes["test_targets"] = tgt


# --------------------------------------------------------------------------- 9 tests python
def resolve_paths(tree: ast.AST) -> set[str]:
    env: dict[str, str] = {}

    def ev(node):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.Name):
            return env.get(node.id)
        if isinstance(node, ast.Call):
            fn = node.func
            fname = fn.id if isinstance(fn, ast.Name) else (fn.attr if isinstance(fn, ast.Attribute) else None)
            if fname in ("Path", "PurePath", "PosixPath", "PurePosixPath") and len(node.args) == 1:
                return ev(node.args[0])
            if fname == "join" and node.args:
                parts = [ev(a) for a in node.args]
                if all(isinstance(x, str) for x in parts):
                    return posixpath.join(*parts)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
            a, b = ev(node.left), ev(node.right)
            if isinstance(a, str) and isinstance(b, str):
                return posixpath.join(a, b)
        return None

    for node in getattr(tree, "body", []):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            v = ev(node.value)
            if isinstance(v, str):
                env[node.targets[0].id] = v
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.value is not None:
            v = ev(node.value)
            if isinstance(v, str):
                env[node.target.id] = v
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Constant, ast.BinOp, ast.Call)):
            v = ev(node)
            if isinstance(v, str) and v.startswith("/") and len(v) > 1 and not re.search(r"\s", v) and len(v) < 200:
                found.add(v.rstrip("/") or "/")
    return found


VERIFIER_INTERNAL = ("/tests", "/work", "/logs", "/tmp", "/venv", "/usr", "/bin", "/sbin", "/proc", "/dev", "/etc",
                     "/opt/venv", "/root", "/var", "/sys", "/lib", "/run")


def check_tests_py(root: Path, rep: Report, notes: dict) -> None:
    rep.section("9. tests/*.py (verifier logic)")
    tdir = root / "tests"
    pys = [p for p in iter_files(tdir) if p.suffix == ".py"] if tdir.exists() else []
    if not pys:
        rep.add("FAIL", "S1", "No Python test files in tests/")
        return
    all_paths: set[str] = set()
    n_tests_total = 0
    for p in pys:
        r = rel(root, p)
        t = read_text(p) or ""
        try:
            tree = ast.parse(t)
        except SyntaxError as exc:
            rep.add("FAIL", "V14", f"Python syntax error: {exc}", r)
            continue
        all_paths |= resolve_paths(tree)
        tests = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
                tests.append(node)
        n_tests_total += len(tests)
        if p.name.startswith("test") and not tests:
            rep.add("FAIL", "V14", "No test functions in this test file", r)
        missing_doc, thin_doc, vacuous, skipped = [], [], [], []
        for fn in tests:
            doc = ast.get_docstring(fn)
            if not doc:
                missing_doc.append(fn.name)
            elif len(doc.strip()) < 20:
                thin_doc.append(fn.name)
            has_assert = False
            for sub in ast.walk(fn):
                if isinstance(sub, ast.Assert):
                    has_assert = True
                    if isinstance(sub.test, ast.Constant) and sub.test.value:
                        vacuous.append(f"{fn.name} (assert {sub.test.value!r})")
                if isinstance(sub, ast.Call):
                    f = sub.func
                    nm = f.attr if isinstance(f, ast.Attribute) else (f.id if isinstance(f, ast.Name) else "")
                    if nm in ("raises", "fail", "approx") or re.search(r"assert|check|verify|expect|compare|validate", nm, re.I):
                        has_assert = True
            if not has_assert:
                vacuous.append(f"{fn.name} (no assert)")
            for dec in fn.decorator_list:
                s = ast.unparse(dec) if hasattr(ast, "unparse") else ""
                if "skip" in s or "xfail" in s:
                    skipped.append(fn.name)
        if missing_doc:
            rep.add("FAIL", "V14", f"Tests without docstrings (CI informative_test_docstrings): {missing_doc[:8]}", r)
        elif tests:
            rep.add("PASS", "V14", f"All {len(tests)} tests have docstrings", r)
        if thin_doc:
            rep.add("WARN", "V14", f"Very short docstrings: {thin_doc[:8]}", r)
        if vacuous:
            rep.add("WARN", "V10", f"Possibly vacuous tests: {vacuous[:8]}", r)
        if skipped:
            rep.add("WARN", "V10", f"Skipped/xfail tests never grade anything: {skipped}", r)
        if re.search(r"\bglobal\s+\w", t):
            rep.add("WARN", "V14", "Uses 'global' - tests may depend on execution order", r)
        # determinism / latency / network
        pats = [
            (r"\brandom\.(random|randint|choice|shuffle|sample|uniform)\(", r"random\.seed\(|Random\(\s*\d", "Unseeded random in the verifier", "O1"),
            (r"np\.random\.(rand|randn|randint|choice|shuffle|normal)\(", r"np\.random\.seed\(|default_rng\(\s*\d", "Unseeded numpy random", "O1"),
            (r"\b(datetime\.now|datetime\.utcnow|date\.today|time\.time)\(", None, "Wall-clock read - can the verdict change with the date/time?", "O1"),
            (r"\b(latency|p50|p95|p99|throughput|perf_counter|timeit|elapsed)\b", None, "Timing/performance measure - latency-based tests are hardware-dependent", "O1"),
            (r"requests\.(get|post)\(\s*[\"']https?://(?!localhost|127\.0\.0\.1)", None, "External network call in the verifier", "V3"),
            (r"urllib\.request\.urlopen\(\s*[\"']https?://(?!localhost|127\.0\.0\.1)", None, "External network call in the verifier", "V3"),
        ]
        for rx, seed_rx, label, cid in pats:
            m = re.search(rx, t)
            if m and not (seed_rx and re.search(seed_rx, t)):
                rep.add("WARN", cid, label, f"{r}:{line_no(t, m.start())}")
        m = re.search(r"time\.sleep\(", t)
        if m:
            rep.add("INFO", "O1", "time.sleep - fixed sleeps are flaky; prefer a readiness condition", f"{r}:{line_no(t, m.start())}")
        if re.search(r"/oracle\b|IS_ORACLE|EVAL_IS_ORACLE|/solution\b", t):
            rep.add("FAIL", "V2", "Verifier references the oracle/solution - grading must be identical for oracle and agent", r)
        m = re.search(r"copytree\(", t)
        if m and "symlinks=True" not in t:
            rep.add("WARN", "V10", "shutil.copytree follows symlinks by default - agent symlinks can expose verifier goldens",
                    f"{r}:{line_no(t, m.start())}")
        # agent code executed inside the verifier?
        runs_agent = bool(re.search(r"subprocess\.(run|Popen|call|check_call|check_output)|os\.system\(", t)) and "/app" in t
        drops = bool(re.search(r"setpriv|runuser|\bgosu\b|os\.setuid|preexec_fn|user\s*=\s*[\"'\d]|\bsu\s+-", t))
        if runs_agent and not drops:
            rep.add("WARN", "V10", "Runs agent code (subprocess on /app paths) without dropping privileges - that process can "
                    "read verifier goldens and /logs/verifier. Drop uid before exec and probe it", r)
        elif runs_agent and drops:
            rep.add("INFO", "V10", "Drops privileges before running agent code - check a test PROBES that the dropped uid "
                    "cannot read goldens or /logs/verifier (and cannot regain privilege)", r)
        if re.search(r"sys\.path\.(insert|append)\([^)]*/app|importlib.*?/app", t):
            rep.add("INFO", "V14", "Imports agent code into the verifier process - fixed expectations must be set before agent "
                    "code loads, and agent code must not be able to redefine what is graded", r)
        # source-grepping (implementation testing)
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
                src = ast.get_source_segment(t, node) or ""
                if re.search(r"[\"'][^\"']+(" + "|".join(re.escape(e) for e in CODE_EXT) + r")[\"']", src) and \
                        re.search(r"\.read(_text)?\(\)", src) and re.search(r"\bin\b\s+\w*(src|source|code|text|content)", src):
                    rep.add("WARN", "V5", f"{node.name} may grep source code (tests should run the code, not parse it)",
                            f"{r}:{node.lineno}")
        # solver-in-tests lead
        for node in tree.body if isinstance(tree, ast.Module) else []:
            if isinstance(node, ast.FunctionDef) and not node.name.startswith("test"):
                length = (getattr(node, "end_lineno", node.lineno) or node.lineno) - node.lineno
                loader = bool(re.match(r"(load|read|get|open|fetch)_", node.name))
                solverish = not loader and bool(
                    re.match(r"(compute|calc|solve|reference|expected|generate|build_expected|make_expected)", node.name)
                    or re.search(r"solve|expected|reference", node.name))
                if length >= 35 or solverish:
                    rep.add("WARN" if (length >= 35 or (solverish and length >= 8)) else "INFO", "V8",
                            f"Helper '{node.name}' ({length} lines) - is this a solver that maps inputs to the full expected "
                            "artifact? (rule of thumb: delete solution/ - could tests still compute the answer?)", f"{r}:{node.lineno}")
        tol = re.findall(r"(?:rel|abs|rtol|atol|rel_tol|abs_tol)\s*=\s*([0-9.eE+-]+)|<=?\s*([0-9]+(?:\.[0-9]+)?[eE]-?[0-9]+)", t)
        tols = sorted({a or b for a, b in tol})
        if tols:
            rep.add("INFO", "V12", f"Numeric tolerances in tests: {tols} - must equal the band stated in instruction.md", r)
        if re.search(r"sha256|hashlib", t):
            rep.add("INFO", "V7", "Golden-hash comparison present (byte-exact) - fine only if the instruction pins the exact format", r)
    if n_tests_total > 20:
        rep.add("INFO", "V14", f"{n_tests_total} tests - long test files for simple tasks are a smell (Review Guidelines)")
    notes["test_paths"] = all_paths


# --------------------------------------------------------------------------- 10 solution
def check_solution(root: Path, rep: Report, toml: dict) -> None:
    rep.section("10. solution/")
    p = root / "solution" / "solve.sh"
    t = read_text(p) if p.is_file() else None
    if t is None:
        rep.add("FAIL", "S1", "solution/solve.sh missing")
        return
    r = "solution/solve.sh"
    lines = t.splitlines()
    if not lines or not lines[0].startswith("#!"):
        rep.add("WARN", "O1", "No shebang", r)
    if not re.search(r"^\s*set\s+-[a-z]*e", t, re.M):
        rep.add("INFO", "O1", "No 'set -e'/'set -euo pipefail' - fail-fast is recommended in solve.sh", r)
    agent_nm = ((toml.get("agent") or {}).get("network_mode")) if isinstance(toml.get("agent"), dict) else None
    sol_files = list(iter_files(root / "solution"))
    for sp in sol_files:
        st = read_text(sp)
        if st is None:
            continue
        for i, l in enumerate(st.splitlines(), 1):
            if l.strip().startswith("#"):
                continue
            if NET_CMD_RE.search(l) or re.search(r"urlopen\(|requests\.(get|post)\(", l):
                lvl = "FAIL" if agent_nm == "no-network" else "INFO"
                rep.add(lvl, "O2", f"Network use in the oracle with [agent].network_mode={agent_nm!r}: '{short(l)}'",
                        f"{rel(root, sp)}:{i}")
            if re.search(r"\$RANDOM|\bshuf\b|\bdate\b\s*[+(]|\buuidgen\b", l):
                rep.add("WARN", "O1", f"Nondeterministic command in the oracle: '{short(l)}'", f"{rel(root, sp)}:{i}")
            if re.search(r"\bnproc\b", l):
                rep.add("WARN", "E15", "Uses nproc (host CPU count inside containers)", f"{rel(root, sp)}:{i}")
            if re.search(r"(?<![\w./-])/tests(?![\w-])", l):
                rep.add("WARN", "O3", f"Oracle touches /tests - the solution must not depend on the verifier: '{short(l)}'",
                        f"{rel(root, sp)}:{i}")
    code_lines = [l for l in lines if l.strip() and not l.strip().startswith("#")]
    writes = [l for l in code_lines if re.search(r"^\s*(echo|printf|cat)\b.*>", l)]
    runs = [l for l in code_lines if re.search(r"\b(python3?|node|gcc|g\+\+|clang|make|cmake|cargo|go|java|javac|mvn|"
                                                 r"dotnet|bash|sh|ruby|npm|npx|tsc|rustc|sqlite3|psql|cp|sed|awk|patch|git)\b", l)]
    if writes and not runs:
        rep.add("WARN", "O3", "solve.sh only writes output with echo/printf/cat - looks like a hardcoded answer, not a derivation", r)
    helper = [rel(root, x) for x in sol_files if x.name != "solve.sh"]
    rep.add("INFO", "O3", f"solve.sh has {len(code_lines)} code lines; helper files: {helper[:10] if helper else 'none'}")


# --------------------------------------------------------------------------- 11 cross checks
def covered(path: str, arts: list[str]) -> bool:
    for a in arts:
        a2 = a.rstrip("/")
        if path == a2 or path.startswith(a2 + "/") or (a.endswith("/") and path == a2):
            return True
    return False


def check_cross(root: Path, rep: Report, toml: dict, instr: str, notes: dict) -> None:
    rep.section("11. Cross-checks (instruction / artifacts / tests / verifier image)")
    arts = [a for a in (toml.get("artifacts") or []) if isinstance(a, str)]
    tpaths = sorted(notes.get("test_paths", set()))
    agent_paths = [p for p in tpaths if not p.startswith(VERIFIER_INTERNAL)]
    ipaths = instruction_paths(instr) if instr else set()
    if agent_paths:
        rep.add("INFO", "V6", f"Agent-side paths the tests use: {agent_paths[:15]}")
    for pth in agent_paths:
        if arts and not covered(pth, arts):
            rep.add("WARN", "V6", f"Tests use {pth} but no declared artifact covers it - in separate mode the verifier only "
                    "receives declared artifacts")
        mentioned = pth in ipaths or any(
            ip.rstrip("/") == pth
            or ip.startswith(pth + "/")  # instruction names something inside this directory
            or (pth.startswith(ip.rstrip("/") + "/") and ip.count("/") >= 2)
            for ip in ipaths)
        if instr and not mentioned and pth.count("/") >= 2:
            rep.add("WARN", "V6", f"Tests use {pth} but instruction.md never mentions it (CI: every file tests read/write must be "
                    "described)")
    unused = [ip for ip in sorted(ipaths) if not any(tp == ip.rstrip("/") or tp.startswith(ip.rstrip("/") + "/") or
                                                    ip.rstrip("/").startswith(tp + "/") for tp in tpaths)]
    if unused:
        rep.add("INFO", "V7", f"Paths named in instruction.md that no test references: {unused[:12]} - inputs are fine; a required "
                "OUTPUT with no test is a req-gap")
    # artifact landing directories in the verifier image
    tdf = root / "tests" / "Dockerfile"
    tdf_text = read_text(tdf) or ""
    for a in arts:
        land = a.rstrip("/") if a.endswith("/") else posixpath.dirname(a)
        if land in ("", "/"):
            continue
        ok = re.search(r"mkdir\s+(-p\s+)?[^\n]*" + re.escape(land) + r"(/|\s|$)", tdf_text) or \
            re.search(r"WORKDIR\s+" + re.escape(land), tdf_text) or \
            re.search(r"(COPY|ADD)\s+[^\n]*\s" + re.escape(land) + r"/?\s*$", tdf_text, re.M)
        if ok:
            rep.add("PASS", "V6", f"Verifier image creates artifact landing dir {land}", "tests/Dockerfile")
        else:
            rep.add("WARN", "V6", f"Can't see tests/Dockerfile create {land} for artifact {a} - uploads fail if the landing dir is missing",
                    "tests/Dockerfile")
    # test.sh targets exist in the verifier image
    dests = [d for d, _s, _l in notes.get("tests_copy_dests", [])]
    for tgt in notes.get("test_targets", []):
        d = posixpath.dirname(tgt)
        if not any(x.rstrip("/") == d or x.rstrip("/") == tgt for x in dests):
            rep.add("WARN", "V3", f"test.sh runs {tgt} but no COPY in tests/Dockerfile targets {d}/ - separate mode does not "
                    "upload tests/", "tests/Dockerfile")
        else:
            rep.add("PASS", "V3", f"{tgt} is copied into the verifier image", "tests/Dockerfile")
    # /tests fixtures referenced by tests exist in the package
    for pth in tpaths:
        if pth.startswith("/tests/"):
            local = root / "tests" / pth[len("/tests/"):]
            if not local.exists():
                rep.add("WARN", "V3", f"Tests reference {pth} but tests/{pth[len('/tests/'):]} is not in the package "
                        "(generated at build?)")
    # verifier tooling
    runs = "\n".join(notes.get("tests_run_texts", []))
    if not re.search(r"pytest", runs + "\n" + "\n".join(str(p) for p in (root / "tests").glob("*.txt"))):
        rep.add("WARN", "V3", "Can't see pytest installed in tests/Dockerfile - verifier deps must be baked into the image",
                "tests/Dockerfile")
    else:
        if "pytest-json-ctrf" not in runs and not list((root / "tests").glob("*requirements*")):
            rep.add("WARN", "V3", "pytest-json-ctrf not seen in tests/Dockerfile - --ctrf needs it", "tests/Dockerfile")
        elif notes.get("ctrf_pinned") is False:
            rep.add("FAIL", "V3", "pytest-json-ctrf installed without an exact pin", "tests/Dockerfile")
    interp = notes.get("pytest_interp")
    if interp and interp.startswith("/"):
        prefix = "/" + interp.strip("/").split("/")[0]
        if prefix not in tdf_text:
            rep.add("WARN", "V3", f"test.sh calls {interp} but tests/Dockerfile never mentions {prefix}", "tests/Dockerfile")


# --------------------------------------------------------------------------- 12 rubric
def check_rubric(root: Path, rep: Report, rubric_path: str | None) -> None:
    rep.section("12. Rubric")
    p = Path(rubric_path) if rubric_path else None
    if p is None:
        for n in ("rubrics.txt", "rubric.txt"):
            if (root / n).is_file():
                p = root / n
    if p is None or not p.is_file():
        rep.add("INFO", "R5", "No rubric supplied - paste the platform rubric into a file and pass --rubric to check R1-R11")
        return
    t = read_text(p) or ""
    r = p.name
    lines = [(i, l.rstrip()) for i, l in enumerate(t.splitlines(), 1) if l.strip()]
    pos_total, negs, seen = 0, 0, set()
    for i, l in lines:
        where = f"{r}:{i}"
        s = l.strip().lstrip("-*• ").strip() if l.strip()[:1] in "-*•" else l.strip()
        if s != l.strip():
            rep.add("WARN", "R5", "Bullet marker before 'Agent' - use a flat list of plain criterion lines", where)
        if not s.startswith("Agent"):
            rep.add("FAIL", "R5", f"Line does not start with 'Agent': '{short(s, 80)}'", where)
        m = re.search(r",\s*([+-]?)(\d+)\s*$", s)
        if not m:
            rep.add("FAIL", "R5", f"Line does not end with ', <score>': '{short(s, 80)}'", where)
            continue
        if not re.search(r", [+-]\d+$", s):
            rep.add("WARN", "R5", "Score should be written exactly as ', +N' / ', -N' (comma, space, signed score)", where)
        sign, val = m.group(1), int(m.group(2))
        if val not in (1, 2, 3, 5):
            rep.add("FAIL", "R3", f"Score {sign}{val} not allowed - only ±1, ±2, ±3, ±5 (never 4)", where)
        if sign == "":
            rep.add("FAIL", "R4", f"Positive score without an explicit '+' ({val})", where)
        if sign == "-":
            negs += 1
        else:
            pos_total += val
        body = s[: m.start()]
        if re.search(r"\b(pytest|test_outputs|unit tests?|test suite|/tests\b|tests/|test\.sh|verifier|reward\.txt)\b", body, re.I):
            rep.add("WARN", "R1", f"Mentions tests/verifier - rubrics grade the trace, not the tests: '{short(body, 80)}'", where)
        if re.search(r"(instruction\.md|instructions?\b|task\.toml|task\.yaml|metadata)", body, re.I):
            rep.add("WARN", "R2", f"Mentions instructions/task files - the agent doesn't know they exist: '{short(body, 80)}'", where)
        if re.search(r"\b(oracle|nop)\b", body, re.I):
            rep.add("FAIL", "R10", f"Mentions oracle/NOP runs: '{short(body, 80)}'", where)
        if re.search(r"\b(does not|doesn't|do not|don't|never|fails to|avoids?|refrains? from)\b", body, re.I):
            rep.add("WARN", "R9", f"Negatively phrased - state the behaviour as a fact and let the sign carry the value: "
                    f"'{short(body, 80)}'", where)
        if re.search(r"\b(correctly|properly|appropriately|handles edge cases|good|well)\b", body, re.I):
            rep.add("INFO", "R6", f"Possibly vague wording: '{short(body, 80)}'", where)
        key = body.lower().strip()
        if key in seen:
            rep.add("WARN", "R6", "Duplicate criterion", where)
        seen.add(key)
    if negs == 0:
        rep.add("FAIL", "R7", "No negative criterion - at least one is required (Medium)")
    else:
        rep.add("PASS", "R7", f"{negs} negative criteria")
    if not 10 <= pos_total <= 40:
        rep.add("WARN", "R11", f"Maximum cumulative score (sum of positives) is {pos_total} - should be 10-40 (Low)")
    else:
        rep.add("PASS", "R11", f"Maximum cumulative score = {pos_total}")


# --------------------------------------------------------------------------- 13 global
def check_global(root: Path, rep: Report) -> None:
    rep.section("13. Whole-package scans")
    hits = 0
    for p in iter_files(root):
        t = read_text(p)
        if t is None:
            continue
        for m in re.finditer(r"canary", t, re.I):
            hits += 1
            rep.add("FAIL", "I10", "Canary string - must not appear in any component", f"{rel(root, p)}:{line_no(t, m.start())}")
            break
    if not hits:
        rep.add("PASS", "I10", "No canary strings")


# --------------------------------------------------------------------------- output
def render(rep: Report, src: str, root: Path | None, name: str, quiet: bool) -> str:
    c = rep.counts()
    out = [f"TERMINUS 3 PRECHECK v{VERSION} - {name}",
           f"Source: {src}" + (f"   (analysed root: {root})" if root else ""),
           f"Result: {c['FAIL']} FAIL · {c['WARN']} WARN · {c['INFO']} INFO · {c['PASS']} PASS",
           "These are LEADS. Confirm each FAIL/WARN in the cited file before it goes into a review;",
           "items CI already enforces should also be checked against the CI report.", ""]
    for title, fs in rep.sections:
        show = [f for f in fs if not (quiet and f.level in ("PASS", "INFO"))]
        if not show:
            continue
        out.append(f"== {title} ==")
        for f in sorted(show, key=lambda x: LEVELS.index(x.level)):
            loc = f"  <{f.where}>" if f.where else ""
            out.append(f"  {f.level:<4} [{f.cid}] {f.msg}{loc}")
        out.append("")
    bad = {}
    for f in rep.all():
        if f.level in ("FAIL", "WARN"):
            bad.setdefault(f.cid, {"FAIL": 0, "WARN": 0})[f.level] += 1
    if bad:
        out.append("== FAIL/WARN by criterion ==")
        for cid in sorted(bad, key=lambda k: (k[0], int(re.sub(r"\D", "", k) or 0))):
            out.append(f"  {cid:<4} FAIL x{bad[cid]['FAIL']}  WARN x{bad[cid]['WARN']}")
    return "\n".join(out)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Static pre-check for a Terminus 3 task submission (leads, not verdicts).")
    ap.add_argument("submission", help="submission ZIP or unpacked task folder")
    ap.add_argument("--rubric", help="text file holding the rubric from the platform (one criterion per line)")
    ap.add_argument("--json", help="also write findings as JSON to this path")
    ap.add_argument("--quiet", action="store_true", help="hide PASS and INFO lines")
    a = ap.parse_args(argv)
    rep = Report()
    src = Path(a.submission)
    root, tmp = load_submission(src, rep)
    name = src.name
    try:
        if root is not None:
            notes: dict = {}
            steps = [
                lambda: check_structure(root, rep),
                lambda: check_skeleton(root, rep),
            ]
            for s in steps:
                s()
            toml = {}
            try:
                toml = check_toml(root, rep)
            except Exception as exc:  # noqa: BLE001
                rep.add("WARN", "M1", f"task.toml check crashed: {exc!r} - check by hand")
            name = str(toml.get("name") or (toml.get("metadata") or {}).get("name") or name)
            instr = ""
            for fn in (lambda: check_instruction(root, rep, toml),):
                try:
                    instr = fn() or ""
                except Exception as exc:  # noqa: BLE001
                    rep.add("WARN", "I2", f"instruction check crashed: {exc!r} - check by hand")
            for label, fn in (
                ("Dockerfiles", lambda: check_dockerfiles(root, rep, notes)),
                ("compose", lambda: check_compose(root, rep, toml)),
                ("environment", lambda: check_env_tree(root, rep, notes)),
                ("test.sh", lambda: check_test_sh(root, rep, notes)),
                ("tests py", lambda: check_tests_py(root, rep, notes)),
                ("solution", lambda: check_solution(root, rep, toml)),
                ("cross", lambda: check_cross(root, rep, toml, instr, notes)),
                ("rubric", lambda: check_rubric(root, rep, a.rubric)),
                ("global", lambda: check_global(root, rep)),
            ):
                try:
                    fn()
                except Exception as exc:  # noqa: BLE001
                    rep.section(f"{label} (check crashed)")
                    rep.add("WARN", "S1", f"{label} check crashed: {exc!r} - review this area by hand")
        print(render(rep, str(src), root, name, a.quiet))
        if a.json:
            Path(a.json).write_text(json.dumps([asdict(f) | {"section": t} for t, fs in rep.sections for f in fs], indent=2))
    finally:
        if tmp is not None:
            shutil.rmtree(tmp, ignore_errors=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
