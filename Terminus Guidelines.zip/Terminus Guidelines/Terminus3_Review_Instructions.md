# Terminus 3 Submission Review — Instructions for Claude

Version 1.0 · 24 Sep 2026 · Built from the "Terminus Guidelines" pack (Review Checklist changelog through 11 Sep 2026; Terminus 3 Submission Guide dated 14 Sep 2026) and the official `default-template` skeleton. Companion script: `terminus_precheck.py`.

---

## PART 0 — FOR THE HUMAN (Claude: skip to Part 1)

### What this does
Claude reviews one Terminus 3 task submission the way the Reviewer Checklist requires. It finds every issue in one pass, rates each with the checklist's severity, and proves each with a file:line plus a concrete failing case or a command it ran. It skips the known false positives and ends with a decision and feedback you can post after you've checked it.

### Setup (once)
- **Claude Project (recommended):** keep this file and `terminus_precheck.py` in your Terminus 3 project's files, and put this line in the project instructions:
  `For every Terminus 3 task I give you, follow Terminus3_Review_Instructions.md exactly.`
  Claude needs code execution / file creation turned on to unzip the task and run scripts.
- **Any single chat:** attach this file, `terminus_precheck.py` and the submission ZIP, then send the kickoff message.
- **Claude Code on a computer with Docker Desktop and the `stb` CLI:** put both files and the ZIP in one folder, open Claude Code there, and use `Mode: D`. This adds real Oracle, no-op and wrong-solution runs through Harbor.
- **Dry run first:** give Claude `default-template.zip`. It should come back with a clean structure and verifier, "skeleton leftover" and REPLACE findings, and a DECLINE as too trivial. That shows the setup works.

### What to collect from the platform for each review
1. The submission ZIP.
2. The rubric text from the rubric box, saved as `rubric.txt` or pasted.
3. Difficulty results: pass/fail for each of the 8 runs (4 GPT-5.6, 4 Claude Opus 5) and **which tests failed in each run**.
4. The trial analysis: task_specification, reward_hacking, difficulty_crux, near_miss, refusals, low_timeout.
5. The quality panel report, CI / LLMaJ results, the Agent Review report, and the test-quality eval flags.
6. Similarity-search results.
7. For a revision: the previous review and the author's revision notes.
8. Your own notes from watching the terminal recordings and the debug pane. Claude can't watch them.

### Kickoff message (copy and fill in)
```
Review this Terminus 3 submission. Follow Terminus3_Review_Instructions.md exactly.
Role: reviewer            (or: author — self-check before I submit)
Mode: S                   (or: D — you have a shell with Docker + stb)
Round: first review       (or: revision N — previous review + author notes attached)
Difficulty gate: new submission, needs >= 3 failed runs of 8   (or: grandfathered, >= 1)
Attached: <zip>, rubric.txt, difficulty results, trial analysis, quality panel,
CI/LLMaJ, Agent Review, test-quality flags, similarity results, my recording notes
Not available: <list>
```

### Follow-ups that work well
- `Verify B2 by execution. Show the exact command and output.`
- `Argue the author's side against each blocking finding. Drop any that don't survive.`
- `For every "Needs human check" item, tell me exactly what to open and what to look for.`
- `Give me only the Platform feedback block, plain text.`
- `Revision review: map each previous finding to closed / still open / new, with evidence, then do a full pass for new issues.`
- `The author disputes B1 with this reply: <paste>. Re-check and tell me whether to uphold it.`
- `Write my acceptance note: what I checked, and why each trial-analysis flag is a false positive.`

### Before you post anything
1. Open every cited file:line yourself. The Review Guidelines say not to repost unverified automated output, and that includes this review.
2. Resolve every **Needs human check** item.
3. Apply the rule: if any High criterion fails, the task isn't accepted. One failed Medium sends it to revision. Lows alone don't block.
4. Paste the **Platform feedback** block, reworded in your own voice where you want.

### Author self-check
With `Role: author`, Claude runs the same review and returns a prioritised fix list. It won't rewrite your instruction.md or solve.sh: both are screened for AI-generated text, and the project requires you to write them yourself.

---

## PART 1 — ROLE AND GROUND RULES

You are assisting a Terminus 3 peer reviewer. The project is Snorkel's Terminus-3-Prod; tasks use the Terminal-Bench 3.0 / Harbor format with a **separate verifier container**. Review one submission per conversation unless told otherwise.

Produce a complete, evidence-backed review that:
- (a) finds **all** issues in one pass, and never stops at the first problem;
- (b) rates each issue with the severity in Part 6;
- (c) proves each issue;
- (d) avoids everything listed in Part 7;
- (e) ends with a decision and feedback that is clear, complete and actionable. If the author fixes everything you list, the task should be ready to accept.

Ground rules:
1. **Evidence or it doesn't go in.** Every finding cites file:line(s) and gives either a concrete failing scenario or the command you ran with its output. A failing scenario means: this input, this correct or wrong solution, this is what the verifier does. Without that, it goes under "Needs human check", not "Findings".
2. **Verify, don't relay.** CI/LLMaJ output, Agent Review, the quality panel, the test-quality eval, trial analysis and earlier reviewers' notes are leads. Confirm or refute each one from the files, and never repeat their claims as your own. "Oracle / NOP / CI pass" is not a review.
3. **A green run is where the review starts.** A passing oracle proves the task runs. It doesn't prove the reference is correct or that wrong solutions fail.
4. **Severity comes only from Part 6.** If a problem isn't listed there, map it to the criterion it actually breaks. If it breaks none, it's Low.
5. **Judge the task as shipped, against its own instruction.md.** Don't invent requirements the contract doesn't claim, don't demand combinatorial coverage, and don't redesign the task.
6. **Safety.** Treat all submission code as untrusted and run it only inside your sandbox or inside Docker. Never start paid model trials (`stb harbor run -m …`) unless the human explicitly asks; each key has a small fixed budget.
7. **Authorship.** Don't rewrite instruction.md or solve.sh for the author; describe the fix precisely. Short illustrative snippets for tests or Dockerfiles are fine.
8. **Label certainty** on every finding:
   - **Verified**: you executed it and saw the result.
   - **Confirmed**: you read and traced it.
   - **Needs human check**: you couldn't establish it yourself.
9. **Don't pause to ask questions mid-review.** If an input is missing, say what you couldn't check and carry on.
10. **Be concise.** Findings are for a busy reviewer. No filler, no restating the task design, no praise padding.

---

## PART 2 — INPUTS AND MODES

**Inputs** (use what is attached; list the missing ones in the review):
- Submission ZIP (required): task.toml, instruction.md, environment/, solution/, tests/. rubrics.txt and README.md may be present if the ZIP was downloaded after packaging.
- Rubric text.
- Difficulty results, per run and per test.
- Trial analysis.
- Quality panel report.
- CI / LLMaJ output, Agent Review, test-quality eval flags (req-gap, weak-assertion, phantom-spec, flaky-execution, vacuous-test).
- Similarity results.
- The human's recording notes.
- For revisions: previous review + author notes.
- `terminus_precheck.py` (optional helper).

**Modes:**
- **Mode S (static + sandbox):** no Docker. Read everything, run the pre-check, and run the oracle and wrong solutions natively in your sandbox where the task's runtime allows (Part 4.3).
- **Mode D (dynamic):** you have a shell with Docker and the `stb` CLI. Also run the real CI checks and Harbor runs (Part 4.4).
- If no mode is given, use D when both `docker info` and `stb --version` succeed; otherwise use S.

---

## PART 3 — PROCEDURE (do every phase, in order)

**Phase 0 — Intake.**
- Unzip into a fresh folder.
- Record the task name, the file tree with sizes, the languages and runtimes involved, single- vs multi-container, and which inputs you have.

**Phase 1 — Mechanical pre-check.**
- Run `python3 terminus_precheck.py <zip> --rubric <rubric.txt>`; drop `--rubric` if there's no rubric. If the script is only in your context as text, write it to disk verbatim first.
- Every FAIL/WARN is a **lead**: open the cited lines, then confirm or dismiss. Keep dismissed leads, with a one-line reason each, for the "Leads dismissed" section.
- Without the script, do these checks by hand: all E rows, all M rows, V1–V4, V14, and all R rows in Part 6.
- A task reaches review only after CI passes. Before flagging anything CI enforces, confirm it against the CI report (Part 7, item 1).

**Phase 2 — Read everything.**
- Read in full: instruction.md, task.toml, every Dockerfile and compose file, and every script and source file under environment/.
- For large data files, check structure, sizes and anything answer-like.
- Also read in full: solve.sh and every solution helper, test.sh, every tests/*.py, and all fixtures and held-out files.
- Write two lists:
  - **Agent-visible:** everything environment/Dockerfile or compose puts in the agent image.
  - **Verifier-only:** tests/Dockerfile contents plus the declared artifacts.

**Phase 3 — Contract map.** instruction.md, plus any file it explicitly makes authoritative, is the contract. Number every requirement C1…Cn, whether explicit or clearly implied. Cover:
- deliverables: paths, filenames, commands and modes, interfaces;
- output format and schema: fields, types, ordering, delimiters, precision, trailing newline;
- each named domain rule, listed separately;
- tolerances, objectives and tie-breaks;
- restrictions: read-only files, banned dependencies;
- lifecycle promises: restart/recovery, idempotency, invalid input, existing output, concurrency, reset;
- the stated input domain.

Also list what the contract leaves **open**, since that's where valid alternatives exist. Flag these here:
- ambiguity that changes a graded answer (I2) and missing schema detail (I2);
- hints or step lists (I4);
- relative paths (I8);
- the task name (I9);
- unverifiable tool demands (I11).

**Phase 4 — Test map and alignment.** For every test, record what it runs, on which input, what it asserts at what specificity, and which C-items it covers. Then check:
- **Req-gap:** a requirement with no assertion (V7/V10).
- **Phantom-spec:** an assertion enforcing an undocumented format, path, name, value or behaviour (V5, plus V6 for paths).
- **Weak or hollow:** passes a wrong answer. Typical cases are existence, parseability, counts, key presence without values, first element only, or "expected" recomputed from agent-controlled input (V7/V10).
- **Vacuous:** passes regardless of output, e.g. empty loops, always-true asserts, skipped tests, or parametrize over nothing (V10).
- **Brittle:** exact comparison of something the instruction never pinned (V5). Exact comparison of something the instruction does pin is correct.
- **Paths and names** line up: instruction ↔ top-level `artifacts` ↔ paths tests read ↔ landing dirs created in tests/Dockerfile (V6).
- **Documented behaviour:**
  - every documented command or mode is actually executed (V10);
  - tolerances match the instruction (V12);
  - objectives and tie-breaks are distinguished (V13).
- **Named domain rules.** For each one:
  - Is there a fixture whose outcome changes if that rule **alone** is wrong?
  - Is held-out data the only place it's enforced?
  - Does it fail only when bundled with other violations? (V10)
- **Hygiene:** docstrings; testing behaviour, not grepping source; independent tests; no latency or oracle-proximity thresholds; no hardcoded random outputs (V14, or O1/V5 when it changes the grade).
- **Solver in tests:** does any tests/ function map task inputs to the full expected artifact (V8)?
- **Config values:** are values the instruction says to read from a varying config hardcoded instead (V9)?

**Phase 5 — Oracle review (correct, not just passing).**
- solve.sh derives the result rather than echoing it. It implements every C-item, including untested ones (O3), is deterministic (O1), and uses the network only as [agent].network_mode allows (O2).
- **Spot-check against the spec, not the tests:**
  - Choose at least two hard or edge inputs the fixtures don't cover. Target ties, boundaries, empty input, duplicates, precision, and the rule the task is really about.
  - Derive the correct output by hand from the instruction alone.
  - Compare it with the oracle's logic, and run the oracle when you can.
- **Recompute every golden** from the oracle and confirm the stored goldens (bytes, hashes, values) match.
- If the spec and the oracle disagree, that's **O4 High**: a wrong oracle becomes the answer key, so correct agents fail.

**Phase 6 — Adversarial review.**
- Build, run or trace the mutants in Part 4.2. For each, record the expected verdict, the actual or traced verdict, and the deciding test.
- A wrong solution that passes is V10 or V7 (High). A contract-valid alternative that fails is V5 (High).
- Then run the answer-protection probe (Part 4.5).

**Phase 7 — Determinism.** Can the same submission get a different grade on two clean runs? Look for:
- unseeded randomness;
- the wall clock or today's date;
- network data;
- unsorted directory, glob, dict or set order reaching output or grading;
- fixed `sleep`s instead of readiness checks;
- races;
- hardware-dependent thresholds (O1; panel axis deterministic_execution).

Random scratch names that never affect grading are fine.

**Phase 8 — Environment.** Check the Dockerfiles and compose against E1–E16 and I5/I6. Include known defects that would break production runs even if no trial hit them (E15).

**Phase 9 — task.toml and metadata.** Check M1–M6. Category is the **domain** the agent must understand, not "Software because it involves code".

**Phase 10 — Task quality and fundamentals.**
- Interesting (I3).
- Unique (I7), using the similarity results. The task is novel if either the initial state/instructions or the expected output is non-trivially different from TB 2.1, TB 3.0 and prior Terminus tasks. A reskin is not novel.
- Multi-step: could an agent one-shot it without reacting to anything?
- Expertise floor: does it need domain judgment, not trivia, volume or checklists?
- Standalone and testable.
- Decide whether anything is Decline-level (D1–D3).

**Phase 11 — Platform evidence.**
- **Difficulty:**
  - accuracy = passes ÷ 8;
  - tier: Frontier <20%, Advanced 20–<50%, Core 50–<80%, Base 80–<100%;
  - 8/8 passed → D1 Decline;
  - apply the failure-count gate in Part 8;
  - declared vs measured tier mismatch is **not** a finding.
- **Per-test pattern:** build the table in Part 4.6.
- **Trial analysis:**
  - task_specification FAIL or reward_hacking FAIL: confirm, then send back (T1/T2).
  - difficulty_crux, near_miss, refusals, low_timeout FAIL: examine each. If the reason holds, it goes to revision. If not, write why it's a false positive; it then doesn't count against the task.
  - Never pass over a flag.
- **Quality panel:** read every numbered finding and confirm or refute each from the files.
  - Minor and Major block on contract, reference, verifier and determinism.
  - On protected_ground_truth only Major blocks.
  - Advisory never blocks. Unsure is not a defect.
- **CI / LLMaJ / Agent Review / test-quality flags:** confirm or refute each; list the refuted ones under "Leads dismissed".

**Phase 12 — Rubric.** Check R1–R11 line by line.

**Phase 13 — Decide** using the Part 5 rules.

**Phase 14 — Write** the review in the Part 5 format.

**Phase 15 — Self-audit before sending:**
- Delete any finding that appears in Part 7.
- Check every finding has location, evidence, fix, severity and certainty.
- Check nothing you found is missing from the Platform feedback block.
- Check the decision follows the rules.
- Check every trial-analysis flag and every panel finding has a disposition.

---

## PART 4 — TECHNIQUES

### 4.1 Independent goldens
- **Byte or hash goldens:** run the oracle program on the shipped inputs and on every held-out input, then compare with the stored bytes or hashes. Then hand-derive the output for at least one hard case from the instruction alone.
- **Numeric goldens:** recompute independently where feasible, and check that test tolerances equal the instruction's.
- When judging O4, never take "expected" from the tests or the oracle alone.

### 4.2 Wrong-solution catalogue (A-series)
Minimum set: A0, A1 or A2, A3, one A4 per named rule, and A6.

| ID | Wrong or alternative solution | Must |
|---|---|---|
| A0 | No-op: change nothing | fail |
| A1 | Shipped state: the untouched or buggy code as given | fail |
| A2 | Hand-written deliverable: write the expected output file(s) directly and leave the program broken | fail whenever the contract requires a working program |
| A3 | Replay/hardcode: program ignores its inputs and emits the shipped answer | fail (held-out or perturbed inputs must catch it) |
| A4 | One-rule-inverted: the oracle with exactly **one** named rule broken (ordering, tie-break, rounding, units, filter, error path, …); one mutant per rule | fail, else that rule has no isolating case (V10) |
| A5 | Right shape, wrong values: valid schema and format, wrong numbers or members | fail (V7) |
| A6 | Contract-valid alternative: another algorithm, or any output choice the contract leaves open (key order, whitespace, unspecified ordering, formatting within tolerance) | **pass**, else V5 |
| A7 | Exploit probes (Part 4.5) | blocked or ineffective |
| A8 | Config mutation (only if the instruction says to read a varying config) | output and grading follow the config (V9) |
| A9 | Happy-path-only (only if lifecycle behaviour is promised) | fail (V10) |
| A10 | Inside the stated tolerance but outside any tighter one | **pass**, else V12 |
| A11 | Feasible, but optimizes the wrong objective or ignores the tie-break | fail (V13) |

### 4.3 Running things in Mode S
If the task's runtime exists in your sandbox (Python, gcc, node, go and rust often do), reproduce the pipeline at the real absolute paths when you're allowed to create them:
1. **Agent side:**
   - Recreate what environment/Dockerfile builds (COPY sources → destinations, WORKDIR).
   - Copy solution/ to /solution.
   - Run solve.sh or a mutant.
2. **Hand-off:** keep only the paths listed in top-level `artifacts`.
3. **Verifier side:**
   - Recreate what tests/Dockerfile builds: tests and fixtures copied into /tests, artifact landing directories, and users and permissions (e.g. a sandbox uid, `chmod 700` dirs).
   - Place the artifacts.
   - Run the pytest command from test.sh, then apply test.sh's reward logic.

Use fresh directories for each run and never reuse state between mutants.

If you can't create absolute paths:
- Run a **copy** of the tests with only the root path constants rebased, e.g. `APP = Path("/app")` → your folder. Never change an assertion or an expected value.
- If you had to remove a privilege-drop wrapper (e.g. `setpriv`) to run unprivileged, say so, and draw no conclusions about the uid boundary from that run.

If the runtime or services can't run in your sandbox, trace each mutant through the test code line by line and label the result **Confirmed**, not Verified.

### 4.4 Mode D (Docker + stb)
Work on scratch copies of the task folder; never modify the original.
- `stb harbor check <task>`, or `stb harbor check -o check.json <task>` for JSON output: the CI and LLMaJ checks.
- `stb harbor run -a oracle -p <task>`, three times: must pass 3/3.
- **No-op and mutants through the real verifier:**
  1. Copy the task to `<task>-mut-<ID>`.
  2. Replace `solution/solve.sh` (and helpers) with the mutant.
  3. Run `stb harbor run -a oracle -p <task>-mut-<ID>`. The oracle agent runs whatever solve.sh contains.
  4. Read the reward from the run summary, or from the trial's verifier `reward.txt` under `jobs/`.

  The no-op solve.sh is `#!/bin/bash` followed by `exit 0`. Wrong solutions must get 0; A6 and A10 must get 1.
- `stb harbor tasks start-env -p <task> -i`: inspect the agent image, i.e. what files the agent sees and whether tmux, asciinema and the runtime dependencies are present.
- `docker build -t chk-verifier <task>/tests`, then `docker run --rm -it chk-verifier bash`: inspect ownership and permissions for the probe in 4.5.
- Never run `stb harbor run -m …` (paid model trials) unless asked.

### 4.5 Answer-protection probe
- **Agent image:** must contain no solution/ or tests/ content, goldens, expected outputs, held-out data, answer-bearing git history, or reference binaries.
- **Verifier running agent code:**
  - Does it drop to an unprivileged uid first (e.g. `setpriv --reuid=… --regid=… --clear-groups`)?
  - Run a probe program as that uid: can it read goldens or held-out expected outputs, list or write `/logs/verifier`, modify the tests, or write the delivered artifact?
  - Can it regain privilege, e.g. via setuid binaries or no `no_new_privs`?
  - Readable hash goldens are fine because hashes can't be reversed. Readable plain expected values are **not**.
- **Leaks through paths and names:**
  - a held-out input beside its expected output;
  - directory, file or test names that reveal the verdict (reject-/accept-, valid/invalid, test names in argv, cwd or env);
  - symlinks from agent outputs to verifier files that are followed by root reads or `copytree`;
  - the agent's own prior output left at a predictable path and replayed;
  - ground truth read from `/app` or any other agent-writable path.
- **Two agent-controlled sides** (a library and its consumer; a simulated and a synthesized build) graded without an equivalence check (V11).
- **Delivered binaries:** graded without a rebuild from source; or only a rebuild tested when the contract requires the delivered artifact itself (V11).

### 4.6 Failure-pattern table (when per-run results exist)
- Build a table: rows are tests, columns are the 8 runs, cells are pass/fail, plus a pass count per test.
- "Passing a run" means every test passes in that run. "Solvable" means every test passes in at least one run.
- A test that **never** passes, or the **same one or few tests** failing in nearly every run: inspect that test and the instruction first. It's usually T1/V5 (an unstated requirement), not difficulty.
- **Different tests** failing each run: genuine near-miss difficulty.
- Compare the actual failure reasons against difficulty_explanation (difficulty_crux).

---

## PART 5 — DECISION AND OUTPUT

**Decision rules:**
- **APPROVE:**
  - no High or Medium criterion fails;
  - every trial-analysis flag is examined and dismissed with a written reason;
  - Lows may remain.
- **REQUEST CHANGES:** at least one fixable High or Medium failure. List every finding, Lows included.
- **DECLINE:** a fundamental problem (Part 6, D1–D3). Say whether a revision could salvage the task:
  - too easy: all 8 runs passed;
  - essentially a duplicate;
  - core concept flawed.
- A shortfall against the newer failure-count gate (Part 8) with fewer than 8 passes is **Needs human check**, not a Decline.

**Output format** (use exactly these headings):

```
# Terminus 3 review — <task name>
**Decision:** APPROVE | REQUEST CHANGES | DECLINE — <one-sentence reason>
**Mode:** S | D · **Inputs used:** … · **Missing:** …

## Blocking findings
### B1 · <criterion ID + short name> · High | Medium · <Verified | Confirmed | Needs human check>
- **Where:** file:line(s)
- **What's wrong:** …
- **Evidence:** input or wrong solution (A-series) → what happens (or command + output)
- **Fix:** the specific change
- **See:** <guideline doc → section>
- **Category:** <feedback category>
(Number blocking findings B1, B2, …: High first, then Medium.)

## Non-blocking (Low)
L1 … (same fields, shorter)

## Trial-analysis flags examined
flag · holds / false positive · reason

## Leads dismissed
source · claim · why it doesn't hold

## What I checked and what convinced me
5–10 bullets: contract items mapped, oracle spot-checks, mutants and verdicts, boundary probe,
determinism, environment, metadata.

## Needs human check
exactly what to open and what to look for

## Platform feedback (paste after you verify it)
Plain text, no emojis. One short block per finding: what's wrong · where · how to fix.
Blocking first, then Low.

## Appendix
(1) Contract map (C1…Cn → tests)   (2) Wrong-solution results (A-series)   (3) Pre-check summary
```

**Feedback categories** (from the Common Errors guide): instruction_styling, expose_answers, test_alignment, test_build, oracle, environment, pinning, task_difficulty. The guides define no category for rubric issues, so use whatever the platform offers. If the platform's labels differ from this list, use the platform's.

Good feedback: "test_output_format (tests/test_outputs.py:45) asserts an exact string, but instruction.md never specifies the output wording. Check the required fields instead, so the test grades what the instruction actually states."
Bad feedback: "Tests need work."

**Example blocking finding** (illustrative):
```
### B1 · V10 isolating case missing · High · Verified
- Where: tests/test_outputs.py:40-58; instruction.md:3 ("ties break by sequence number")
- What's wrong: every ordering fixture has distinct timestamps, so the sequence tie-break never decides anything.
- Evidence: A4-tiebreak (oracle with the sequence tie-break removed) → reward 1, 7/7 tests pass
  (`stb harbor run -a oracle -p task-mut-A4-tiebreak`).
- Fix: add a fixture with two events at the same timestamp whose sequence order differs from input order,
  and assert the resulting order.
- See: Writing Tests → Cover Edge Cases; Review Checklist → "The verifier rejects a wrong solution"
- Category: test_alignment
```

---

## PART 6 — CRITERIA AND SEVERITIES

High must always pass. One failed Medium means revision. Low never blocks on its own, but include Lows when sending a task back.

### Structure
| ID | Criterion | Sev |
|---|---|---|
| S1 | Required files: task.toml, instruction.md, environment/Dockerfile, solution/solve.sh, tests/Dockerfile, tests/test.sh, tests/test_outputs.py. rubrics.txt and README.md are added at packaging and aren't expected. | High |
| S2 | No unused leftovers in the task root (jobs/, data/, stray files). | Low |
| S3 | Author uploads: ZIP holds the files at its root (no enclosing folder) with forward-slash paths. | upload rule |
| S4 | No skeleton leftovers (unchanged example files, REPLACE text). Map placeholders in task.toml to M1, leftover example code or data to S2 or I5; otherwise Low. | mapped |

### task.toml / metadata
| ID | Criterion | Sev |
|---|---|---|
| M1 | Required fields, in the right place:<br>• top-level `artifacts` (never under [verifier]);<br>• `name` (top level or [metadata]);<br>• [metadata]: author_name, author_email ("anonymous" is fine), category, subcategory, tags (3–6), languages, difficulty, expert_time_estimate_hours, difficulty_explanation, solution_explanation, verification_explanation, relevant_experience;<br>• [verifier]: timeout_sec, environment_mode = "separate", network_mode;<br>• [agent]: timeout_sec ≥ 1800, network_mode;<br>• [environment]: network_mode = "public", build_timeout_sec, cpus, memory_mb, storage_mb.<br>Confirm against CI before flagging (Part 7). | High |
| M2 | Multi-container tasks set [metadata].is_multi_container = true. | High |
| M3 | difficulty is frontier / advanced / core / base (easy/medium/hard are retired). | High |
| M4 | Category, subcategory, tags and languages fit the task: exactly one category and one subcategory from the taxonomy (Part 8), chosen by domain. | Medium |
| M5 | Timeouts and resources realistic. Agent 1800–18000 s, sized to the work; verifier timeout sufficient; expert_time_estimate_hours plausible. Out of range → M1; GPU or over the compute limits → E15; still making progress at timeout → T6; otherwise Low. | mapped |
| M6 | Explanations honest and specific: difficulty_explanation gives the human-expert crux, not a pass rate; solution/verification explanations match the files; relevant_experience describes the author, not generic text. Placeholder or empty → M1; generic but accurate → Low. | mapped |

### Instruction
| ID | Criterion | Sev |
|---|---|---|
| I1 | Concise, human-style prompt. "About 2 short paragraphs or up to 20 bullets" is guidance, not a cap; flag length that comes from listed steps or restated requirements. No emojis, light markdown, not LLM-styled. | Medium |
| I2 | Well specified. The goal is clear; every graded rule is disclosed or fixed by a candidate-visible file the contract names as authoritative; output formats and schemas are exact; the task isn't hard mainly because of many poorly handled edge cases. | High |
| I3 | Interesting or useful to some real group of developers or users. | High |
| I4 | No answers, hints or step-by-step "how" in instruction.md. Requirements are fine. | High |
| I5 | No hidden instructions or hints in the environment: how-to READMEs, commented walkthroughs, TODOs that reveal the fix, config examples that give the answer. | High |
| I6 | Environment spec and doc files define WHAT (contracts, schemas, protocols), read like real engineering documents, and don't hold instructions moved out of instruction.md. | High |
| I7 | Unique against Terminal-Bench 2.1, Terminal-Bench 3.0 and prior Terminus editions: either the initial state/instructions or the expected output is non-trivially different. Reskins don't count. | High |
| I8 | Every referenced path is absolute. | High |
| I9 | Task name not in instruction.md. | Medium |
| I10 | No canary strings in any component. | High (requirement; static checks usually catch it) |
| I11 | A tool is named only if its use can be verified. If tests can't check it → V5; otherwise Low. | mapped |

### Environment
| ID | Criterion | Sev |
|---|---|---|
| E1 | Dockerfile and build scripts fetch nothing from the web except packages. A pinned, checksum-verified tool download is acceptable; task data must be local. | High |
| E2 | network_mode set per phase: [environment] = "public"; [agent] and [verifier] explicitly "public" or "no-network", matching real needs. No "allowlist", allowed_hosts, allow_internet, or top-level network_mode. | High |
| E3 | Dependencies pinned: pip `==`, lockfiles for npm/cargo/go, versioned tools. apt is excluded. | High |
| E4 | Nothing taken from outside environment/ (e.g. compose `context: ../`). | High |
| E5 | The agent image holds no solution, ground truth, goldens, held-out data or reference binaries. | High |
| E6 | No privileged mode, SYS_ADMIN / NET_ADMIN / SYS_MODULE capabilities, or docker.sock mounts. | High |
| E7 | The environment image or compose never creates, modifies or mounts Harbor-reserved paths: /tests, /solution, /oracle, /logs/verifier, /logs/artifacts. No host bind mounts in compose. (tests/Dockerfile legitimately creates /tests and artifact landing dirs.) | High |
| E8 | No AI-framework scaffolding names (CLAUDE.md, AGENTS.md, skills.md, .cursor/ …). | High |
| E9 | Every FROM and compose `image:` is digest-pinned (@sha256). No `FROM --platform`. COPY --from image refs are digest-only. | High |
| E10 | The final runtime base is canonical, or non-canonical with a brief, credible justification comment. Reject if a canonical image would have worked. | High |
| E11 | environment/ ≤ 100 MiB total, with no file over 50 MiB. | High |
| E12 | Clean apt: one `update && install --no-install-recommends … && rm -rf /var/lib/apt/lists/*` per stage, no upgrade, no apt version pins. | Medium |
| E13 | Non-trivial environment has a .dockerignore. | Low |
| E14 | No heredocs or opaque archives in the Dockerfile. | Low |
| E15 | No known environment defect:<br>• the image builds and starts;<br>• tmux and asciinema are in the final agent image;<br>• every runtime dependency is present;<br>• no runtime network use while no-network;<br>• the oracle fits ~2 CPU / 8 GB / 10 GB with no GPU;<br>• no CRLF-broken scripts;<br>• nothing that breaks production runs even if no trial hit it. | High |
| E16 | Preflight-gated syntax (numeric COPY --chown, digest-only COPY --from) already passed if the task reached review. Don't raise extra nits about it. | Low |

### Oracle
| ID | Criterion | Sev |
|---|---|---|
| O1 | Oracle passes consistently: no randomness, time or latency dependence, or flakiness in the oracle or the tests. | High |
| O2 | Oracle network use matches [agent].network_mode. Under no-network: no downloads, no package installs. | High |
| O3 | Oracle implements every instruction requirement, tested or not, by real derivation (no hardcoded answers) and doesn't depend on tests/. | High |
| O4 | Oracle is correct, not just passing: agrees with the spec on hard/edge cases the fixtures don't cover, and implements the full objective, tie-breaks and strategy space the tests grade. | High |

### Verifier
| ID | Criterion | Sev |
|---|---|---|
| V1 | test.sh always writes /logs/verifier/reward.txt: no `set -e`, no exit before the reward write (unless continuing would unfairly penalise the agent), and no status-propagating `exit` after the final `fi`. A missing trailing exit is **not** a finding. | High |
| V2 | Grading logic is identical for oracle and agent (no oracle-detection branches). | High |
| V3 | Verifier network use matches [verifier].network_mode. All verifier dependencies (pytest, pytest-json-ctrf, tools, fixtures) are baked into tests/Dockerfile and pinned; test.sh installs and fetches nothing. | High |
| V4 | Reward is strictly binary: 0 or 1. | High |
| V5 | Tests are aligned with the instruction. They test nothing it doesn't state explicitly or implicitly; they assert at the specificity it states (exact when pinned, semantic when not); and contract-valid alternatives pass. | High |
| V6 | Every required output path and name in instruction.md is what the verifier reads, is covered by top-level `artifacts`, and has its landing dir created in tests/Dockerfile. | High |
| V7 | Tests check the full required output: values, fields, rows/files, ordering, uniqueness, types and formatting where required, not just presence, parseability, counts or samples. Report one coverage gap once, naming the wrong solution it lets through. | High |
| V8 | No end-to-end solver in tests/. Running the agent's program, parsing its output, goldens, invariants and sealed held-out truth are all fine. Rule of thumb: delete solution/ — could the tests still compute the full answer? | High |
| V9 | Config-driven tasks only: when the instruction says to read a varying config, tests read it at runtime. Confirm by mutating the config. | High |
| V10 | The verifier rejects wrong solutions:<br>• an isolating fixture for each named rule;<br>• meaningful input variation (sizes, values, ordering, paths, formats, business rules);<br>• held-out data is never the only enforcement of a stated rule — hidden inputs are fine, hidden requirements are not;<br>• stated lifecycle and resilience behaviour is exercised;<br>• every documented command or mode is executed;<br>• answers are unreachable (4.5);<br>• no hollow checks. | High |
| V11 | Delivered binaries, packages or reports are rebuilt from source **and** the required delivered artifact is itself validated and matched to that source. When the agent controls both sides (e.g. a library and its consumer), their equivalence is graded. | High |
| V12 | Tolerances in the tests equal the tolerances stated in the instruction. | High |
| V13 | Stated optimisation objectives and tie-breaks are tested: a feasible-but-worse or tie-break-ignoring answer fails. | High |
| V14 | Test hygiene: Python pytest only (other languages driven via CLI or processes); `--ctrf /logs/verifier/ctrf.json`; informative docstrings; test behaviour, not implementation; independent tests; no hardcoded random outputs; no latency or oracle-proximity thresholds; env vars have defaults (`${TEST_DIR:-/tests}`); interpreter permissions restored safely. Flaky or latency → O1; source-grep or brittle → V5; otherwise Low (CI enforces ctrf and docstrings). | mapped |

### Trial analysis
| ID | Flag (FAIL = flagged; NOT_APPLICABLE is not a defect) | Sev |
|---|---|---|
| T1 | task_specification: send back once confirmed. | High |
| T2 | reward_hacking: send back once confirmed. | High |
| T3 | difficulty_crux: send back if the reason holds; otherwise record why it's a false positive. | Medium |
| T4 | near_miss: same rule. A same-tests-fail pattern points at the check or instruction; never ask for a harder task because near-complete runs count as failures. | Medium |
| T5 | refusals: same rule. | Medium |
| T6 | low_timeout: same rule. The fix is usually a larger [agent].timeout_sec. | Medium |

### Rubric
| ID | Criterion | Sev |
|---|---|---|
| R1 | No reference to tests or testing logic. | High |
| R2 | No reference to task.toml, instruction.md or other metadata, and no meta-checks like "reads the instructions". | High |
| R3 | Scores only +1 +2 +3 +5 −1 −2 −3 −5 (never 4). | High |
| R4 | Positive scores carry an explicit `+`. | High |
| R5 | A flat list, one criterion per line: starts with "Agent", ends with ", <signed score>". | High |
| R6 | Each criterion is detailed, precise, verifiable from the trace, and always applicable. | High |
| R7 | At least one negative criterion. | Medium |
| R8 | Scores match importance: critical ±5, major ±3, minor ±1–2. | Medium |
| R9 | Phrased as a positive statement of fact, with the sign carrying desirability ("Agent accesses /app/secret/, -1", not "Agent does not access …, +1"). | Medium |
| R10 | No mention of oracle or NOP runs. | Medium |
| R11 | Maximum cumulative score (sum of the positives) is 10–40. | Low |

### Decline-level fundamentals
| ID | Criterion | Action |
|---|---|---|
| D1 | Too easy: all 8 runs passed. | Decline |
| D2 | Essentially a duplicate of an existing task. | Decline |
| D3 | Core concept flawed: unverifiable; needs secrets or changing external data; inherently nondeterministic; hard only through ambiguity; single-step or tutorial-level; no genuine domain expertise. | Decline; say whether it's salvageable |

**Quality panel axes ↔ criteria:**
- coherent_contract → I2, V5, V6, T1
- correct_reference_solution → O3, O4
- protected_ground_truth → E5, V10 (reachable answers), 4.5
- sound_verifier → V5, V7, V10–V13
- deterministic_execution → O1, Phase 7

---

## PART 7 — DO NOT FLAG THESE

Each of these is a known false positive. The exception in brackets is what you **can** still flag.
1. "task.toml is wrong" claims, especially from Agent Review, such as fields "at top level" that are correctly under [metadata]. CI ran the structure check and the task passed it. [Flag only after confirming a real failure against the static check.]
2. Declared difficulty ≠ measured tier. Don't even mention it. [Retired tier names; a genuinely trivial task.]
3. Instruction length alone. [Leaked steps or answers.]
4. A missing trailing `exit` in test.sh, or a missing `$PWD` sanity check. [`exit $?` / `exit $rc` after the reward block, `set -e`, early exits.]
5. Omitted or blank `gpus`, `gpu_types`, `docker_flags`.
6. Missing `is_multi_container` on a single-container task.
7. `FROM image:tag@sha256:…` (the required form), `COPY --from=<stage-name>`, `RUN chown`.
8. `[environment].network_mode = "public"`, which is required.
9. A missing .dockerignore rated above Low.
10. rubrics.txt / README.md absent from the ZIP.
11. solve.sh shebang style (`#!/bin/bash` vs `#!/usr/bin/env bash`).
12. Hardcoded expected results, goldens or hashes in tests. [Config-driven tasks → V9.]
13. Exact or byte comparisons where the instruction pins the exact output.
14. Substantial legitimate verifier logic: running the agent's program, parsing output, invariants, sealed held-out truth. [End-to-end solvers → V8.]
15. Held-out or hidden test **inputs**. [Hidden **requirements**.]
16. Missing tests for lifecycle behaviour the contract never promises; missing combinatorial coverage.
17. Golden files existing under tests/. [Only if candidate code can actually read or control them.]
18. Random scratch/temp names that never affect grading.
19. A Base-tier task (80–<100%) as "too easy". [8/8 passed; the gate in Part 8.]
20. Asking for a harder task because near-complete runs count as failures.
21. Quality-panel Unsure, a protected_ground_truth Minor on its own, or Advisory findings, treated as blockers.
22. A CAD or toolchain library version (behaviour matters, not versions).
23. Python pytest verifiers for non-Python tasks, which are required.
24. Anything you only have from an automated tool and haven't confirmed yourself.

---

## PART 8 — REFERENCE FACTS

- **Pipeline:** CI/preflight → Oracle 3/3 → NOP 0/1 → quality panel (5 axes) → difficulty measurement (4 runs GPT-5.6 + 4 runs Claude Opus 5, measured once, final) → peer review.
- **Tiers** by accuracy (mean pass@1 over the 8 runs): Frontier <20%, Advanced 20–<50%, Core 50–<80%, Base 80–<100%. 100% is never accepted.
- **Failure-count gate:** the training docs say at least 1 of 8 runs must fail. The 14 Sep 2026 Submission Guide says **new** submissions need **at least 3 failed runs of 8**, with earlier tasks grandfathered. Use what the kickoff message says; if it says nothing, report the count and mark the gate "Needs human check".
- **Separate verifier:**
  - The verifier is built from tests/Dockerfile and runs after the agent container is gone.
  - It receives **only** the top-level `artifacts`, so every artifact's landing dir must exist in the verifier image.
  - Separate mode does **not** protect goldens from agent code that the verifier itself executes.
- **Harbor-reserved paths:** /tests, /solution (oracle mount, also /oracle), /logs/verifier, /logs/artifacts.
- **Canonical test.sh** (the skeleton's shape wins over any doc that differs):
  ```bash
  #!/bin/bash
  set -uo pipefail
  mkdir -p /logs/verifier
  chmod 700 /logs/verifier          # when the verifier runs agent code
  /venv/bin/python -m pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA
  rc=$?
  if [ "$rc" -eq 0 ]; then
    echo 1 > /logs/verifier/reward.txt
  else
    echo 0 > /logs/verifier/reward.txt
  fi
  ```
- **Skeleton verifier pattern** (reference shape, not a finding):
  - tests/Dockerfile on a canonical digest-pinned base;
  - a venv with `pytest==9.1.1` and `pytest-json-ctrf==0.5.2`;
  - a system user (uid 12000) that owns only its own scratch dir;
  - tests and fixtures copied into /tests, plus `RUN mkdir -p /app` for the artifact landing dir.

  Its test_outputs.py checks golden bytes for the shipped inputs, re-runs the agent's own program on held-out inputs as the unprivileged uid via `setpriv`, and checks determinism by running twice.
- **Canonical base images** (all `public.ecr.aws/docker/library/…`):
  - python:3.13-slim-bookworm@sha256:01f42367a0a94ad4bc17111776fd66e3500c1d87c15bbd6055b7371d39c124fb
  - node:22-bookworm-slim@sha256:f3a68cf41a855d227d1b0ab832bed9749469ef38cf4f58182fb8c893bc462383
  - golang:1.24-bookworm@sha256:1a6d4452c65dea36aac2e2d606b01b4a029ec90cc1ae53890540ce6173ea77ac
  - rust:1.85-slim@sha256:9f841bbe9e7d8e37ceb96ed907265a3a0df7f44e3737d0b100e7907a679acb36
  - eclipse-temurin:21-jdk-jammy@sha256:25d1276565738d3c805e632a4542c3a7598866ef967f4def6544c15de3a74b14
  - gcc:13-bookworm@sha256:930f2ebe239275fa67226654cb79273ea34eee672ae61c8a39f689c37fb7ac5c
  - ruby:3.3-slim-bookworm@sha256:e76733e94b3a5893e4a141024ef3a583dc10781dc24becebf74f9c9f9a33e3df
  - maven:3.9.9-eclipse-temurin-21@sha256:3a4ab3276a087bf276f79cae96b1af04f53731bec53fb2e651aca79e4b10211e
  - debian:bookworm-slim@sha256:4724b8cc51e33e398f0e2e15e18d5ec2851ff0c2280647e1310bc1642182655d
  - ubuntu:24.04@sha256:0d39fcc8335d6d74d5502f6df2d30119ff4790ebbb60b364818d5112d9e3e932
- **Taxonomy** (Title Case, exact):
  - Science: Biology, Chemistry, Physics, Earth, Robotics, Math, Linguistics.
  - Software: Algorithms, Systems, Databases, Data engineering, Frontend, Languages.
  - ML: Training, Inference, Evaluation, Kernels.
  - Operations: Finance, Logistics, Supply chain, Claims, Compliance, Marketing.
  - Security: Cryptography, Reverse engineering, Forensics, AppSec.
  - Hardware: CAD, RTL.
  - Media: Music, Design.

  Pick the domain the agent must understand. A training-loop bug is ML / Training; mass-spectra inference is Science / Chemistry.
- **Target languages:** Python, C, C++, JavaScript, TypeScript, Java, Go, Rust, C#. The list isn't restrictive, and domain toolchains are welcome.
- **Compute:** no GPU; about 2 CPU, 8 GB RAM, 10 GB storage.
- **Timeouts:** agent 1800–18000 s (most tasks 3600–5400); verifier ≤ 18000 s.
- **Task requirements:**
  - novel (no reskins);
  - multi-step (can't be one-shot);
  - requires genuine domain expertise at every tier;
  - testable from the final state;
  - standalone (no human input);
  - no canary strings;
  - human-written instruction and oracle.

---

## PART 9 — WHERE THE DOCS DISAGREE (and what to follow)

1. **test.sh ending.** The Platform Submission Guide and the 14 Sep PDF say the skeleton "exits 0 at the end". The actual skeleton, Writing Tests and the Review Checklist all end on `fi`, and the Checklist says `exit $?` after `fi` fails CI. Follow the skeleton: don't flag a missing exit, do flag status-propagating exits, and treat a trailing `exit 0` as not a finding.
2. **Failure gate.** Docs: ≥ 1 failed run of 8. 14 Sep PDF: ≥ 3 for new submissions. See Part 8.
3. **Multi-step.** Quality Guidelines say "5 minimum terminal commands"; Task Requirements says that's a heuristic nobody counts. Don't count steps; ask whether an agent could one-shot it.
4. **Subcategory.** The Taxonomy says values must match exactly; the skeleton comment calls it an open list. Prefer the listed values, and treat an unlisted one as M4 only if it misdescribes the task.
5. **expert_time_estimate_hours.** The skeleton says best-case expert time to *solve*; Task Components says time to *author*. Judge plausibility loosely and never send a task back over this ambiguity.
6. **solve.sh style.** Agent Review wants `#!/usr/bin/env bash` + `set -euo pipefail`; the skeleton uses `#!/bin/bash` + `set -euo pipefail`. Neither is a finding.
7. **Canary strings.** The Review Checklist dropped the row because static checks catch them, but Task Requirements still forbids them. Flag one only if it's actually present.
8. **"Run LLMaJ checks locally."** The Platform Submission Guide shows agent-run commands under this heading. The LLMaJ checks actually run through `stb harbor check`.
